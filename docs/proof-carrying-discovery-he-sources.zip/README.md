# Proof-Carrying Discovery · Hebrew reading editions

Six complete Hebrew editions, with Noto Sans Hebrew. Each directory is a standalone source package with its own build instructions. The original papers and verification evidence are unchanged. These editions do not represent a new run of the Lean or Python artifacts.

1. Observe, Change Representation, or Act, v2.6.1 (corrected)
2. Goal-Relative Information Sufficiency and the Research Repair Atom, v1.3
3. Meta-Synset and Invariant, v2.5
4. Hypothesis Languages and Proof-Carrying Representation Escalation, Gate 11–12 v12.3
5. Hypothesis Languages and Evidence-Scoped Identification, Gate 4B–5
6. Cumulative Search in a Fixed Engine, v1.1 (clean-reading edition)

[Canonical research editions and their sources](https://github.com/Dnarts/proof-carrying-discovery/blob/main/docs/PREPRINT_LANGUAGES.md).
