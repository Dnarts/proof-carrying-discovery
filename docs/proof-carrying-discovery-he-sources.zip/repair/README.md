# Goal-Relative Information Sufficiency and the Research Repair Atom · Hebrew edition

Hebrew reading edition of Aleksandr Strand’s v1.3 preprint, checked against the [canonical Russian text](https://github.com/Dnarts/proof-carrying-discovery/blob/main/papers/repair-budget-atom/v1.3/repair_budget_atom_preprint_v1_3.tex) and the [published English translation](https://github.com/Dnarts/proof-carrying-discovery/blob/main/papers/repair-budget-atom/v1.3/repair_budget_atom_preprint_v1_3_en.tex). The explicit protocol, audit, and implementation scope notes from the English edition are retained. The formal results, declaration names, data and mathematical statements are unchanged. The original Lean/Python verification was not rerun for this translation.

Build with XeLaTeX on TeX Live with Polyglossia, bidi, the packages named in the source, and the Latin/code fonts Liberation Serif and DejaVu Sans Mono. The two Noto Sans Hebrew font instances are included with their SIL Open Font License.

    xelatex -halt-on-error -interaction=nonstopmode repair_budget_atom_preprint_v1_3_he.tex
    xelatex -halt-on-error -interaction=nonstopmode repair_budget_atom_preprint_v1_3_he.tex
