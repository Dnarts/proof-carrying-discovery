# Meta-Synset and Invariant v2.5 — Hebrew edition

Complete Hebrew translation of the preprint, maintaining the structure, mathematics, theorem and evidence status, and figure captions. The supplied English vector diagrams and Lean code listings are reproduced unchanged. Technical names and references retain their original spelling. This is a translation; Lean was not rerun.

Canonical inputs:
- Russian v2.5 PDF: https://github.com/Dnarts/proof-carrying-discovery/blob/main/papers/hypothesis-language/meta-synset-v2.5/meta_synset_invariant_preprint_v2_5.pdf
- Matched English v2.5 source: https://github.com/Dnarts/proof-carrying-discovery/blob/main/papers/hypothesis-language/meta-synset-v2.5/meta_synset_v2_5_english_source.zip

Build with XeLaTeX twice from this directory (TeX Live with Polyglossia, bidi, fvextra, xurl, and the standard LaTeX graphics and table packages). Noto Sans Hebrew is bundled under its included SIL Open Font License. The Latin body and code use Liberation Serif and DejaVu Sans Mono respectively.

    xelatex -interaction=nonstopmode -halt-on-error meta_synset_invariant_preprint_v2_5_he.tex
    xelatex -interaction=nonstopmode -halt-on-error meta_synset_invariant_preprint_v2_5_he.tex
