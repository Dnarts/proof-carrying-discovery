from pathlib import Path
import subprocess,re

md=Path('CUMULATIVE_SEARCH.he.md').read_text()
first,rest=md.split('\n\n',1)
sub,rest=rest.split('\n\n',1)
byline,rest=rest.split('\n\n',1)
title=first[2:]
sub=sub.strip('*')
assert rest.startswith('## תקציר\n\n')
rest=rest.removeprefix('## תקציר\n\n')
abstract,body=rest.split('\n\n## 1.',1)
body='## 1.'+body
body,refs=body.split('\n## מקורות\n')
table_data=[x.strip('|').split('|') for x in body.splitlines() if x.startswith('|')]
assert len(table_data)==6
head=[x.strip() for x in table_data[0]]
rows=[[x.strip() for x in row] for row in table_data[2:]]
body=re.sub(r'(?m)(^\|[^\n]+\|\n)+','CUMULATIVEHEBREWTABLE\n',body)
def pandoc(s):
    return subprocess.check_output(['pandoc','--no-highlight','--wrap=none','-f','markdown+tex_math_dollars+raw_tex+autolink_bare_uris','-t','latex'],input=s,text=True)
a,b,r=[pandoc(x) for x in [abstract,body,refs]]
def rtl_prose(s):
    s=re.sub(r'\\texttt\{([^{}]+)\}',r'\\textenglish{\\texttt{\1}}',s)
    s=re.sub(r'(?<![\w])(?:1-DCA|AND3|NAND|DFA|XOR|Python|Lean|T1|T2|AND|OR|JSON|Angluin|DreamCoder|babble|utility problem)(?![\w])',
             lambda m:r'\textenglish{'+m.group()+'}',s)
    s=s.replace(r'\begin{verbatim}',r'\begin{english}'+'\n'+r'\begin{verbatim}').replace(r'\end{verbatim}',r'\end{verbatim}'+'\n'+r'\end{english}')
    return s
a,b=rtl_prose(a),rtl_prose(b)
b=re.sub(r'\\subsection\{([1-8])\. (.*?)\}\\label\{[^{}]+\}',r'\\section{\2}',b)
b=re.sub(r'\\subsubsection\{[45]\.[1-3]\. (.*?)\}\\label\{[^{}]+\}',r'\\subsection{\1}',b)
def val(x):
    bold=x.startswith('**')
    core=x.strip('*').replace('−','-')
    return (r'\textbf{' if bold else '')+r'\textenglish{'+core+'}'+('}' if bold else '')
def h(x):
    z=re.match(r'`([^\x60]+)`, (.+)',x)
    if z:
        return r'\shortstack{\textenglish{\texttt{'+z[1].replace('_',r'\_')+'}}\\\\ '+z[2]+'}'
    return x
cells=[list(map(h,head))]+[[r'\textenglish{AND3}' if row[0]=='AND3' else row[0],*(val(x) for x in row[1:])] for row in rows]
lines=[' & '.join(row)+r' \\' for row in cells]
# The label column is first in reading order and physically rightmost under bidi.
tbl='\n'.join([r'\begin{center}',r'\small\setlength{\tabcolsep}{4pt}',
  r'\begin{tabular}{@{}p{.27\linewidth}rrrr@{}}',r'\toprule',lines[0],r'\midrule',*lines[1:],r'\bottomrule',r'\end{tabular}',r'\end{center}'])
b=b.replace('CUMULATIVEHEBREWTABLE',tbl)
assert 'CUMULATIVEHEBREW' not in b
header=r'''\documentclass[11pt,a4paper]{article}
\input{common-he}
\pdfstringdefDisableCommands{\def\textenglish#1{#1}}
\providecommand{\tightlist}{\setlength{\itemsep}{3pt}\setlength{\parskip}{0pt}}
\title{TITLE}
\author{אלכסנדר סטרנד}
\date{22 בנובמבר 2026}
\hypersetup{pdftitle={TITLE}}
\begin{document}
\maketitle
\begin{center}\small\emph{SUBTITLE}\end{center}
\begin{abstract}
'''.replace('SUBTITLE',sub).replace('TITLE',title)
end=r'''\Needspace{16\baselineskip}
\section*{מקורות}
\begin{english}
\small
'''
Path('CUMULATIVE_SEARCH.he.tex').write_text(header+a+'\\end{abstract}\n'+b+'\n'+end+r+'\\end{english}\n\\end{document}\n')
