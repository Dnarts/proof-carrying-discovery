#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 assemble.py
xelatex -interaction=nonstopmode -halt-on-error CUMULATIVE_SEARCH.he.tex
xelatex -interaction=nonstopmode -halt-on-error CUMULATIVE_SEARCH.he.tex
