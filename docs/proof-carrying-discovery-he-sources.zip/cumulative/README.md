# Cumulative Search v1.1 · Hebrew clean-reading edition

Full Hebrew translation of the [English clean-reading edition](https://github.com/Dnarts/proof-carrying-discovery/blob/a416bb1058b74bb21a57f7b66157e0725944ffa1/papers/cumulative-search/CUMULATIVE_SEARCH.en.md), cross-checked against the [Russian edition](https://github.com/Dnarts/proof-carrying-discovery/blob/main/papers/cumulative-search/CUMULATIVE_SEARCH.ru.md). This is the clean-reading Markdown edition, not a facsimile of the historical release PDF. The Russian edition's clarification in §3 about the `attempts` field is retained. The exact SHA-256 of the English source is `ed949f3aa362c7293d36320a2dc01f2f702627a45887a6316331a2ded3996ef3`.

## Build

Run `sh build.sh` with Python 3, Pandoc, XeLaTeX, Polyglossia, bidi, and the packages imported in `common-he.tex`. The build regenerates the included TeX from the editable Hebrew Markdown and runs XeLaTeX twice. The bundled Noto Sans Hebrew regular and bold fonts are distributed under the accompanying SIL Open Font License; the Latin fonts are Liberation Serif and DejaVu Sans Mono.

The translation preserves the scope of all claims. The article's original experiment was not rerun for this translation.
