# Observe, Change Representation, or Act · Hebrew v2.6.1

Full Hebrew reading edition of the corrected release, based on the [canonical
corrected English LaTeX](https://github.com/Dnarts/proof-carrying-discovery/blob/08336d7e2b487a9cef55fa86227ae9328eaac997/papers/certified-strategy-selection/v2.6.1/certified_strategy_selection_preprint_v2_6_1_en.tex)
and [editorial corrections](https://github.com/Dnarts/proof-carrying-discovery/blob/08336d7e2b487a9cef55fa86227ae9328eaac997/papers/certified-strategy-selection/v2.6.1/CORRECTION.md).
The translation does not modify or reverify the scientific release.

Requires XeLaTeX, Polyglossia and bidi, Liberation Serif, DejaVu Sans Mono,
and Latin Modern Math. Noto Sans Hebrew regular and bold are bundled under OFL.
Run twice from the source directory:

```sh
xelatex -halt-on-error -interaction=nonstopmode certified_strategy_selection_preprint_v2_6_1_he.tex
xelatex -halt-on-error -interaction=nonstopmode certified_strategy_selection_preprint_v2_6_1_he.tex
```
