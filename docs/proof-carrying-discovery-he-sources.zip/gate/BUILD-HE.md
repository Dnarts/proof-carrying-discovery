# Hypothesis Languages and Proof-Carrying Representation Escalation — Hebrew edition

Hebrew rendering of Gate 11–12 v12.3 by Aleksandr Strand, aligned with the
repository's Russian manuscript and its typeset English edition. Formulas,
tables, reference labels, theorem scope, bibliographic entries, and the
distinction between finite observations and Lean theorems are preserved.
The proof artifacts and experimental data were not changed.

Build in this directory with XeLaTeX and a current LaTeX distribution with
polyglossia, bidi, mathtools, TikZ, bookmark and the other packages listed in
the source. Install Liberation Serif, Liberation Sans and DejaVu Sans Mono
as system fonts. Noto Sans Hebrew is included under the enclosed OFL license.

    xelatex -interaction=nonstopmode -halt-on-error hypothesis_language_gate12_he.tex
    xelatex -interaction=nonstopmode -halt-on-error hypothesis_language_gate12_he.tex

Source editions:
- [Canonical Russian LaTeX](https://github.com/Dnarts/proof-carrying-discovery/blob/08336d7e2b487a9cef55fa86227ae9328eaac997/papers/hypothesis-language/gate11-gate12-v12.3/src/hypothesis_language_gate12_ru.tex)
- [English LaTeX](https://github.com/Dnarts/proof-carrying-discovery/blob/08336d7e2b487a9cef55fa86227ae9328eaac997/papers/hypothesis-language/translations/gate11-gate12-v12.3/hypothesis_language_gate12_en.tex)
