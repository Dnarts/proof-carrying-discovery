# Hypothesis Languages and Evidence-Scoped Identification · Hebrew

Hebrew translation of [the English Gate 4B–5 manuscript](https://github.com/Dnarts/proof-carrying-discovery/blob/main/papers/hypothesis-language/HYPOTHESIS_LANGUAGE.en.md), checked against [the parallel Russian manuscript](https://github.com/Dnarts/proof-carrying-discovery/blob/main/papers/hypothesis-language/HYPOTHESIS_LANGUAGE.ru.md). The paragraph on the historical, unproved five-state memory lower bound is translated from the Russian edition and labeled as such in section 6. This edition does not independently rerun the Lean verification.

## Build

Use XeLaTeX with Polyglossia, bidi, AMS math, booktabs, needspace and hyperref. The Hebrew font is bundled (Noto Sans Hebrew, OFL); the Latin text uses Liberation Serif. Build from this directory:

    xelatex -halt-on-error -interaction=nonstopmode HYPOTHESIS_LANGUAGE.he.tex
    xelatex -halt-on-error -interaction=nonstopmode HYPOTHESIS_LANGUAGE.he.tex
