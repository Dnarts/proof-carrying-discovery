#!/usr/bin/env python3
"""Replay supplied CRTT T19–T32 evidence with standard Python 3.9+.

Usage: python3 replay_evidence.py --output ../CRTT-evidence-replay
The output directory must be outside this archive and empty or absent.
This runs the pinned Python auditors and finite CLI reference; it never runs Lean.
Compiler exits are read from the supplied journal, not observed in a new process.

Adapted from the executed review retained at
  evidence/reconciliation/prior_review/replay_logs.py
Original SHA-256:
  de1044ee93c8687f304974f7798e5b3306185c7d83f1698bc394d0215749d21d
The original script and historical command records remain distinct evidence.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import argparse,hashlib,json,os,re,subprocess,sys

ROOT=None
SRC=None
LOG=None
OUT=None
ERRORS=[]
REPORT={}


def configure():
    global ROOT,SRC,LOG,OUT,REPORT
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent,
                        help='Unpacked CRTT architecture root; defaults to this script directory.')
    parser.add_argument('--output',type=Path,required=True,
                        help='Empty or absent output directory outside the archive.')
    args=parser.parse_args()
    ROOT=args.root.expanduser().resolve()
    OUT=args.output.expanduser().resolve()
    if not ROOT.is_dir():parser.error('--root is not a directory')
    if OUT==ROOT or ROOT in OUT.parents:
        parser.error('--output must be outside the archive root')
    if OUT.exists() and (not OUT.is_dir() or any(OUT.iterdir())):
        parser.error('--output must be an empty or absent directory')
    SRC=ROOT/'canonical';LOG=ROOT/'evidence/local_verification'
    for required in [SRC/'run_verify.sh',SRC/'SHA256SUMS.txt',LOG/'RUNNER_FULL.log',
                     LOG/'ALL_LEAN_LOGS.log',ROOT/'evidence/freeze/T32-KERNEL_CHECK.log']:
        if not required.is_file():parser.error('Missing required file: '+str(required))
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'commands').mkdir()
    REPORT={'schema':'crtt-portable-log-review-v2',
        'started_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'Current source pins, exact supplied module log views and CLI/reference replay.',
        'path_conventions':{'input_paths':'relative to archive root',
                            'output_paths':'relative to this report directory',
                            'execution_context':'historical absolute argv and locations of this run'},
        'execution_context':{'input_root':str(ROOT),'output_root':str(OUT),'python':sys.executable},
        'replay_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'lean_executed_locally':False,'errors':ERRORS}



def sha(data):return hashlib.sha256(data).hexdigest()
def digest(p):return sha(p.read_bytes())
def need(condition,message):
    if not condition:ERRORS.append(message)
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def snapshot():
    return {str(p.relative_to(ROOT)):digest(p) for p in [*SRC.glob('*.lean'),*SRC.glob('*.py'),SRC/'run_verify.sh',SRC/'SHA256SUMS.txt',ROOT/'evidence/freeze/T32-KERNEL_CHECK.log',*LOG.rglob('*.log')]}


def command(job):
    label,args=job
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env.pop('PYTHONOPTIMIZE',None);env.pop('PYTHONPATH',None)
    started=datetime.now(timezone.utc).isoformat()
    try:
        result=subprocess.run(args,cwd=SRC,env=env,capture_output=True,timeout=60)
        output,error,exit_code,timed_out=result.stdout,result.stderr,result.returncode,False
    except subprocess.TimeoutExpired as exc:
        output,error,exit_code,timed_out=exc.stdout or b'',exc.stderr or b'',None,True
    stdout=OUT/'commands'/f'{label}.stdout.log';stderr=OUT/'commands'/f'{label}.stderr.log'
    stdout.write_bytes(output);stderr.write_bytes(error)
    row={'id':label,'argv':args,'cwd':str(SRC),'started_utc':started,
        'finished_utc':datetime.now(timezone.utc).isoformat(),'exit_code':exit_code,'timed_out':timed_out,
        'stdout_sha256':sha(output),'stderr_sha256':sha(error),
        'stdout':stdout.relative_to(OUT).as_posix(),'stderr':stderr.relative_to(OUT).as_posix(),'mode':'local Python replay of supplied outputs, not new Lean execution'}
    save(OUT/'commands'/f'{label}.json',row)
    return row


def main():
    before=snapshot()
    REPORT['input_snapshot_before']=before
    runner=(LOG/'RUNNER_FULL.log').read_bytes()
    aggregate=(LOG/'ALL_LEAN_LOGS.log').read_bytes()
    frozen=(ROOT/'evidence/freeze/T32-KERNEL_CHECK.log').read_bytes()
    REPORT['input_digests']={str(p.relative_to(ROOT)):{'sha256':digest(p),'bytes':p.stat().st_size}
        for p in [LOG/'ALL_LEAN_LOGS.log',LOG/'RUNNER_FULL.log',ROOT/'evidence/freeze/T32-KERNEL_CHECK.log']}
    REPORT['runner_is_byte_identical_to_frozen_witness']=runner==frozen
    manifest_rows=[line.split(maxsplit=1) for line in (SRC/'SHA256SUMS.txt').read_text().splitlines()]
    source_manifest={name:h for h,name in manifest_rows}
    need(len(source_manifest)==len(manifest_rows),'Duplicate paths in canonical source manifest')
    for name in ['run_verify.sh','audit_lean.py','audit_names.py','check_release.py','lean-toolchain']:
        need(digest(SRC/name)==source_manifest.get(name),'Executable/toolchain pin mismatch '+name)
    need((SRC/'lean-toolchain').read_text().strip()=='leanprover/lean4:v4.36.0','Unexpected pinned Lean toolchain')
    version=b'Lean (version 4.36.0, arm64-apple-darwin24.6.0, commit 611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9, Release)'
    need(version in runner and version in aggregate,'Supplied toolchain version/commit mismatch')
    if ERRORS:raise ValueError('Canonical execution pin or toolchain verification failed')
    runner_source=(SRC/'run_verify.sh').read_text()
    expected_order=re.search(r'^for src in (.+); do$',runner_source,re.M).group(1).split()
    need(len(expected_order)==len(set(expected_order))==21,'Expected source order must contain 21 distinct modules')
    need(all(re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*\.lean',name) for name in expected_order),'Unsafe module name')
    need({p.name for p in SRC.glob('*.lean')}==set(expected_order),'Canonical Lean file set differs from runner source order')
    if ERRORS:raise ValueError('Invalid expected module set')
    lines=runner.splitlines(keepends=True);offsets=[0]
    for line in lines:offsets.append(offsets[-1]+len(line))
    positions=[(i,re.fullmatch(rb'=== LEAN: (\S+\.lean) ===\r?\n?',line).group(1).decode())
        for i,line in enumerate(lines) if re.fullmatch(rb'=== LEAN: (\S+\.lean) ===\r?\n?',line)]
    need([n for i,n in positions]==expected_order,'Runner source order differs from current run_verify.sh')
    need(len(positions)==len({name for _,name in positions})==21,'Runner must contain 21 distinct module sections')
    need(len(list((LOG/'per_module').glob('*.log')))==21,'Expected exactly 21 per-module logs')
    need({p.stem+'.lean' for p in (LOG/'per_module').glob('*.log')}==set(expected_order),'Per-module log file set differs from current source set')
    am=list(re.finditer(rb'(?m)^={80}\r?\n=== MODULE: (\S+\.lean) ===\r?\n={80}\r?\n',aggregate))
    need([m.group(1).decode() for m in am]==expected_order,'Aggregate module order differs from current runner')
    aggregate_sections={m.group(1).decode():aggregate[m.end():am[i+1].start() if i+1<len(am) else len(aggregate)] for i,m in enumerate(am)}
    if ERRORS:raise ValueError('Supplied module section inventory mismatch')
    rows=[];jobs=[];expected_all=Counter();actual_all=Counter()
    axiom_counts=Counter()
    report_pattern=re.compile(r"^'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)[ \t]*$",re.M)
    for index,name in positions:
        source=SRC/name;path=LOG/'per_module'/(source.stem+'.log');data=path.read_bytes()
        footer=next(j for j in range(index+1,len(lines)) if lines[j].startswith(('AUDIT '+name+':').encode()))
        match=re.fullmatch(rb'AUDIT (\S+): (\d+)/(\d+) axiom reports; Lean exit=(-?\d+); dependencies=(.*)\r?\n?',lines[footer])
        if not match:raise ValueError('Cannot parse runner audit footer '+name)
        supplied_exit=int(match.group(4));raw=b''.join(lines[index+1:footer])
        requested=re.findall(r'^#print axioms\s+(\S+)',source.read_text(),re.M)
        expected=Counter('CRTT.'+source.stem+'.'+n for n in requested)
        reports=report_pattern.findall(data.decode());actual=Counter(n for n,deps in reports)
        for n,deps in reports:
            for a in {a.strip() for a in deps.split(',') if a.strip()}:axiom_counts[a]+=1
        expected_all.update(expected);actual_all.update(actual)
        aggregate_body=aggregate_sections.get(name,b'')
        aggregate_match=aggregate_body.startswith(data) and not aggregate_body[len(data):].strip(b'\r\n')
        record={'source':str(source.relative_to(ROOT)),'source_sha256':digest(source),
            'source_matches_current_manifest':digest(source)==source_manifest[name],
            'per_module_log':str(path.relative_to(ROOT)),'log_sha256':sha(data),'log_bytes':len(data),
            'requested_reports':len(requested),'actual_reports':len(reports),
            'exact_qualified_names_match':expected==actual,'duplicate_report_names':[n for n,c in actual.items() if c>1],
            'per_module_bytes_equal_runner_raw_segment':data==raw,
            'runner_segment_byte_start':offsets[index+1],'runner_segment_byte_end':offsets[footer],
            'runner_footer_lean_exit':supplied_exit,
            'exit_provenance':'Value read from supplied RUNNER_FULL footer; not an independently observed compiler exit.',
            'aggregate_body_equals_log_plus_only_blank_separators':aggregate_match,
            'aggregate_extra_separator_bytes':len(aggregate_body)-len(data)}
        rows.append(record)
        need(record['source_matches_current_manifest'],'Current source pin mismatch '+name)
        need(expected==actual,'Exact audit-name mismatch '+name)
        need(not record['duplicate_report_names'],'Duplicate audit reports '+name)
        need(int(match.group(2))==len(reports) and int(match.group(3))==len(requested),
             'Runner footer audit counts differ from source and raw reports '+name)
        need(data==raw,'Per-module and runner raw segment mismatch '+name)
        need(aggregate_match,'Aggregate body differs from per-module log '+name)
        need(supplied_exit==0,'Supplied compiler status is nonzero '+name)
        jobs += [(source.stem+'_audit',[sys.executable,'-B',str(SRC/'audit_lean.py'),str(source),str(path),str(supplied_exit)]),
                 (source.stem+'_names',[sys.executable,'-B',str(SRC/'audit_names.py'),str(source),str(path)])]
    aggregate_reports=Counter(n for n,deps in report_pattern.findall(aggregate.decode()))
    need(expected_all==actual_all==aggregate_reports,'Global 542-name multiset mismatch')
    need(sum(expected_all.values())==542,'Current source audit request count differs from 542')
    need(set(axiom_counts)<={'propext','Quot.sound'},'Unexpected axiom dependencies')
    cli_positions=[i for i,line in enumerate(lines) if line.strip()==b'=== T32 CLI: ACTUAL LEAN EXECUTION ===']
    need(len(cli_positions)==1,'Expected exactly one actual CLI section')
    if len(cli_positions)!=1:raise ValueError('CLI section count is not one')
    ci=cli_positions[0]
    ce=next(i for i in range(ci+1,len(lines)) if lines[i].startswith(b'AUDIT ReleaseMain.lean:'))
    cli=b''.join(lines[ci+1:ce]);cli_status=int(re.search(rb'Lean exit=(-?\d+)',lines[ce]).group(1))
    need(cli_status==0,'Supplied CLI compiler/runtime status is nonzero')
    cli_path=OUT/'runner_cli.raw.log';cli_path.write_bytes(cli)
    REPORT['cli_segment']={'sha256':sha(cli),'bytes':len(cli),'byte_start':offsets[ci+1],'byte_end':offsets[ce],
        'supplied_lean_exit':cli_status,'source_journal_sha256':sha(runner),'output_path':'runner_cli.raw.log'}
    jobs += [('cli_audit',[sys.executable,'-B',str(SRC/'audit_lean.py'),str(SRC/'ReleaseMain.lean'),str(cli_path),str(cli_status)]),
             ('cli_names',[sys.executable,'-B',str(SRC/'audit_names.py'),str(SRC/'ReleaseMain.lean'),str(cli_path)]),
             ('cli_reference',[sys.executable,'-B',str(SRC/'check_release.py'),'--lean-log',str(cli_path)])]
    with ThreadPoolExecutor(max_workers=3) as pool:
        commands=list(pool.map(command,jobs))
    need(len(commands)==45,'Expected exactly 45 strict replay/reference commands')
    need(all(c['exit_code']==0 for c in commands),'A strict replay or reference comparison failed')
    REPORT['per_module']=rows;REPORT['commands']=commands
    REPORT['diagnostics']={kind:{pattern:len(re.findall(pattern,data.decode(),re.I))
        for pattern in [r'\bwarning:',r'\berror:',r'\bsorryAx\b',r'\bClassical\.choice\b']}
        for kind,data in [('aggregate',aggregate),('runner',runner)]}
    need(all(v==0 for row in REPORT['diagnostics'].values() for v in row.values()),'Forbidden diagnostic pattern in supplied log')
    header=aggregate[:am[0].start()].decode() if am else aggregate.decode()
    REPORT['provenance']={'aggregate_header':header,
        'module_logs_have_separate_exit_records':False,
        'module_logs_are_exact_runner_segments':all(r['per_module_bytes_equal_runner_raw_segment'] for r in rows),
        'aggregate_date_is_textual_metadata':True,
        'separate_outer_runner_process_exit_receipt_present_in_new_log_directory':False,
        'new_log_directory_files':sorted(str(p.relative_to(LOG)) for p in LOG.rglob('*') if p.is_file()),
        'runner_has_final_success_marker':b'PASS: T32 complete manifest, Lean compilation, 542 audited reports, finite checks and actual CLI/reference agreement.' in runner,
        'freshness_conclusion':'The supplied output is consistent with successful current-source verification. Byte equality with a prior deterministic output neither proves nor disproves a later run. No separate new process receipt is included; the new timestamp is a header assertion. Fresh independent execution is not established by this replay.',
        'historical_exit_127':'The previously observed exit 127 belongs to that earlier local environment; it does not rule out a later run elsewhere and is not erased by adding a new timestamp.'}
    need(REPORT['provenance']['runner_has_final_success_marker'],'Runner has no final success marker')
    need(runner.rstrip().endswith(b'PASS: T32 complete manifest, Lean compilation, 542 audited reports, finite checks and actual CLI/reference agreement.'),
         'Runner final success marker is not the last nonempty line')
    REPORT['scope_inputs_unchanged']=snapshot()==before
    need(REPORT['scope_inputs_unchanged'],'Input files changed during log review')
    REPORT['summary']={'content_replay_status':'PASS' if not ERRORS else 'FAIL','module_logs':len(rows),
        'current_source_pins_matched':sum(r['source_matches_current_manifest'] for r in rows),
        'exact_audit_reports':sum(actual_all.values()),'audit_requests':sum(expected_all.values()),
        'per_module_strict_parser_calls':2*len(rows),'cli_strict_parser_calls':2,
        'cli_reference_cases':9 if commands[-1]['exit_code']==0 else None,
        'total_python_commands':len(commands),'all_python_commands_exit_zero':all(c['exit_code']==0 for c in commands),
        'axiom_dependency_occurrences':dict(axiom_counts),'new_independent_lean_execution_established':False,
        'replay_is_not_fresh_compilation':True}
    REPORT['finished_utc']=datetime.now(timezone.utc).isoformat()
    save(OUT/'log_review.json',REPORT)
    print(json.dumps({'summary':REPORT['summary'],'errors':ERRORS},ensure_ascii=False,indent=2))
    return 0 if not ERRORS else 1


if __name__=='__main__':
    configure()
    try:
        code=main()
    except Exception as exc:
        ERRORS.append(type(exc).__name__+': '+str(exc))
        REPORT['finished_utc']=datetime.now(timezone.utc).isoformat()
        REPORT['summary']={'content_replay_status':'FAIL','lean_executed_locally':False}
        save(OUT/'log_review.json',REPORT)
        print(json.dumps({'summary':REPORT['summary'],'errors':ERRORS},ensure_ascii=False,indent=2))
        code=1
    raise SystemExit(code)
