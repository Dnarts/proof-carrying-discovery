import Std
import Lean

/-!
CRTT online extension, independent of the frozen v0.2 sources.
Target: Lean 4.36.0. This is an uncompiled source draft.

T17a: one method per task, empty initial library, known common tariffs,
first task accepts every method, all later tasks require one hidden method.
The tail counts tasks after the second. No speculative acquisition.

T17b: one homogeneous task stream, local cost L, first generic use D,
later generic use R, 0 <= R < L < D. The reduced coordinates are
r = L - R and B = D - R. The cost functions assume no extra overhead,
no eviction, and a generic method valid on every task in this stream.
-/

namespace CRTT.Online

section HiddenMethod
variable {A : Type} [DecidableEq A]

def hiddenCost (D R tail : Nat) (first required : A) : Nat :=
  D + (if first = required then R else D) + tail * R

def clairvoyantCost (D R tail : Nat) : Nat := D + R + tail * R

/-- Choosing the hidden method first minimizes the cost on this stream. -/
theorem clairvoyant_optimal (D R tail : Nat) (h : R ≤ D)
    (first required : A) :
    clairvoyantCost D R tail ≤ hiddenCost D R tail first required := by
  by_cases heq : first = required
  · simp [hiddenCost, clairvoyantCost, heq]
  · simp only [hiddenCost, clairvoyantCost, if_neg heq]
    omega

/-- With the correct initial method the lower bound is attained. -/
theorem clairvoyant_attained (D R tail : Nat) (required : A) :
    hiddenCost D R tail required required = clairvoyantCost D R tail := by
  simp [hiddenCost, clairvoyantCost]

/-- Exact regret on a stream whose second task requires a different method. -/
theorem miss_regret (D R tail : Nat) (h : R ≤ D)
    (first required : A) (miss : first ≠ required) :
    hiddenCost D R tail first required = clairvoyantCost D R tail + (D - R) := by
  simp only [hiddenCost, clairvoyantCost, if_neg miss]
  omega

/-- The adversary needs just two distinct possible methods. -/
theorem adversarial_regret (D R tail : Nat) (h : R ≤ D)
    (a b first : A) (distinct : a ≠ b) :
    ∃ required : A, first ≠ required ∧
      hiddenCost D R tail first required = clairvoyantCost D R tail + (D - R) := by
  by_cases ha : first = a
  · have hb : first ≠ b := fun hEq => distinct (ha.symm.trans hEq)
    exact ⟨b, hb, miss_regret D R tail h first b hb⟩
  · exact ⟨a, ha, miss_regret D R tail h first a ha⟩

/-- For a two-task miss the costs are precisely 2D and D+R.
    No division is needed to state the competitive-ratio witness. -/
theorem two_task_ratio_witness (D R : Nat) (first required : A)
    (miss : first ≠ required) :
    hiddenCost D R 0 first required = 2 * D ∧
    clairvoyantCost D R 0 = D + R := by
  simp only [hiddenCost, clairvoyantCost, if_neg miss, Nat.zero_mul, Nat.add_zero]
  omega

end HiddenMethod

section Rental

/-- Baseline cost TR plus the cheaper of renting and purchasing. -/
def offlineCost (R r B T : Nat) : Nat := T * R + min (T * r) B

/-- Buy on task k if it arrives, after k-1 local tasks. k is one-based. -/
def thresholdCost (R r B k T : Nat) : Nat :=
  T * R + if T < k then T * r else B + (k - 1) * r

/-- First positive task number for which cumulative rental premium reaches B.
    Meaningful for positive B and r. -/
def buyAt (B r : Nat) : Nat := (B - 1) / r + 1

/-- The integer threshold straddles the break-even point. -/
theorem buyAt_spec (B r : Nat) (hB : 0 < B) (hr : 0 < r) :
    0 < buyAt B r ∧ (buyAt B r - 1) * r < B ∧ B ≤ buyAt B r * r := by
  have hdiv : r * ((B - 1) / r) + (B - 1) % r = B - 1 :=
    Nat.div_add_mod (B - 1) r
  have heq : ((B - 1) / r) * r + (B - 1) % r = B - 1 := by
    rw [Nat.mul_comm ((B - 1) / r) r]
    exact hdiv
  have hmod : (B - 1) % r < r := Nat.mod_lt _ hr
  have hprev : buyAt B r - 1 = (B - 1) / r := by
    unfold buyAt
    omega
  have hnext : buyAt B r * r = ((B - 1) / r) * r + r := by
    unfold buyAt
    rw [Nat.add_mul, Nat.one_mul]
  have hpos : 0 < buyAt B r := by
    unfold buyAt
    omega
  refine ⟨hpos, ?_, ?_⟩
  · rw [hprev]
    omega
  · rw [hnext]
    omega

/-- The offline formula is a lower bound on every positive threshold. -/
theorem offline_le_threshold (R r B k T : Nat) :
    offlineCost R r B T ≤ thresholdCost R r B k T := by
  by_cases hT : T < k
  · have hm : min (T * r) B ≤ T * r := Nat.min_le_left _ _
    simp only [offlineCost, thresholdCost, if_pos hT]
    omega
  · have hm : min (T * r) B ≤ B := Nat.min_le_right _ _
    simp only [offlineCost, thresholdCost, if_neg hT]
    omega

/-- The offline optimum is attained by renting throughout or buying at once. -/
theorem offline_attained (R r B T : Nat) :
    ∃ k : Nat, 0 < k ∧ thresholdCost R r B k T = offlineCost R r B T := by
  by_cases h : T * r ≤ B
  · refine ⟨T + 1, by omega, ?_⟩
    have hT : T < T + 1 := by omega
    simp [thresholdCost, offlineCost, hT, Nat.min_eq_left h]
  · have hmin : B ≤ T * r := by omega
    by_cases hz : T = 0
    · subst T
      exact ⟨1, by decide, by simp [thresholdCost, offlineCost]⟩
    · have hT : ¬ T < 1 := by omega
      refine ⟨1, by decide, ?_⟩
      simp [thresholdCost, offlineCost, hT, Nat.min_eq_right hmin]

/-- Any threshold straddling break-even is optimal on shorter streams. -/
theorem before_threshold (R r B k T : Nat)
    (hlow : (k - 1) * r < B) (hT : T < k) :
    thresholdCost R r B k T = offlineCost R r B T := by
  have hidx : T ≤ k - 1 := by omega
  have hmul := Nat.mul_le_mul_right r hidx
  have hmin : T * r ≤ B := by omega
  simp [thresholdCost, offlineCost, hT, Nat.min_eq_left hmin]

/-- After purchase, the sole extra cost is the pre-purchase rental premium. -/
theorem after_threshold (R r B k T : Nat)
    (hup : B ≤ k * r) (hT : k ≤ T) :
    thresholdCost R r B k T = offlineCost R r B T + (k - 1) * r := by
  have hmul := Nat.mul_le_mul_right r hT
  have hmin : B ≤ T * r := by omega
  have hn : ¬ T < k := by omega
  simp only [thresholdCost, offlineCost, if_neg hn, Nat.min_eq_right hmin]
  omega

/-- Universal 2-competitive guarantee, with exact equality before buying. -/
theorem threshold_two_competitive (R r B k T : Nat)
    (hlow : (k - 1) * r < B) (hup : B ≤ k * r) :
    thresholdCost R r B k T ≤ 2 * offlineCost R r B T := by
  by_cases hT : T < k
  · rw [before_threshold R r B k T hlow hT]
    omega
  · have hidx : k ≤ T := by omega
    have hmul := Nat.mul_le_mul_right r hidx
    have hmin : B ≤ T * r := by omega
    rw [after_threshold R r B k T hup hidx]
    unfold offlineCost
    rw [Nat.min_eq_right hmin]
    omega

/-- T17b: the computable ceiling threshold satisfies the guarantee. -/
theorem buyAt_two_competitive (R r B T : Nat) (hB : 0 < B) (hr : 0 < r) :
    thresholdCost R r B (buyAt B r) T ≤ 2 * offlineCost R r B T := by
  obtain ⟨_, hlow, hup⟩ := buyAt_spec B r hB hr
  exact threshold_two_competitive R r B (buyAt B r) T hlow hup

/-- Counterexample to identifying break-even with minimax optimality.
    D=5, L=4, R=1, so B=4 and r=3. Buying on task 1 costs
    5 on a one-task stream, while buying on task 2 costs 9 on a two-task
    stream. Their exact worst ratios are established analytically in README;
    the examples here certify the cost witnesses, not that global claim. -/
example : buyAt 4 3 = 2 := by decide
example : thresholdCost 1 3 4 1 1 = 5 := by decide
example : offlineCost 1 3 4 1 = 4 := by decide
example : thresholdCost 1 3 4 2 2 = 9 := by decide
example : offlineCost 1 3 4 2 = 6 := by decide

end Rental
end CRTT.Online

#print axioms CRTT.Online.adversarial_regret
#print axioms CRTT.Online.clairvoyant_optimal
#print axioms CRTT.Online.offline_le_threshold
#print axioms CRTT.Online.offline_attained
#print axioms CRTT.Online.buyAt_spec
#print axioms CRTT.Online.before_threshold
#print axioms CRTT.Online.after_threshold
#print axioms CRTT.Online.buyAt_two_competitive
