import Std
import Lean

/-!
CRTT T18: finite deterministic minimax observation value.
An independent Lean 4 source draft (target 4.36.0).
Natural-number losses give an executable specialization of the real-valued
finite theorem. Lists are explicit domains, not samples of a larger domain.
No choice axiom is used to compute the policy. A nonempty action list is
represented by its head (base) and remaining candidates (actions).
-/
namespace CRTT.Observation
universe u v w t

/-- Empty maxima are zero for nonnegative losses. -/
def worst {X : Type u} (score : X → Nat) : List X → Nat
  | [] => 0
  | x :: xs => max (score x) (worst score xs)

theorem mem_le_worst {X : Type u} (score : X → Nat)
    (xs : List X) (x : X) (hx : x ∈ xs) : score x ≤ worst score xs := by
  induction xs with
  | nil => simp at hx
  | cons y ys ih =>
    rcases List.mem_cons.mp hx with heq | hm
    · subst x
      simp only [worst]
      exact Nat.le_max_left _ _
    · simp only [worst]
      exact Nat.le_trans (ih hm) (Nat.le_max_right _ _)

theorem worst_le {X : Type u} (score : X → Nat) (xs : List X) (b : Nat)
    (h : ∀ x, x ∈ xs → score x ≤ b) : worst score xs ≤ b := by
  induction xs with
  | nil => simp [worst]
  | cons x xs ih =>
    have hx := h x (List.mem_cons.mpr (Or.inl rfl))
    have ht := ih (fun y hy => h y (List.mem_cons.mpr (Or.inr hy)))
    simp only [worst]
    omega

/-- A computable argmin, with deterministic tie-breaking. -/
def pick {A : Type u} (score : A → Nat) (base : A) : List A → A
  | [] => base
  | a :: rest =>
    let b := pick score base rest
    if score a ≤ score b then a else b

theorem pick_allowed {A : Type u} (score : A → Nat) (base : A) (xs : List A) :
    pick score base xs = base ∨ pick score base xs ∈ xs := by
  induction xs with
  | nil => exact Or.inl rfl
  | cons a rest ih =>
    by_cases h : score a ≤ score (pick score base rest)
    · simp only [pick, if_pos h]
      exact Or.inr (List.mem_cons.mpr (Or.inl rfl))
    · simp only [pick, if_neg h]
      rcases ih with hb | hm
      · exact Or.inl hb
      · exact Or.inr (List.mem_cons.mpr (Or.inr hm))

theorem pick_le {A : Type u} (score : A → Nat) (base : A) (xs : List A)
    (a : A) (ha : a = base ∨ a ∈ xs) : score (pick score base xs) ≤ score a := by
  induction xs with
  | nil =>
    have h : a = base := by simpa using ha
    subst a
    simp [pick]
  | cons b bs ih =>
    have hc : a = b ∨ (a = base ∨ a ∈ bs) := by
      rcases ha with heq | hm
      · exact Or.inr (Or.inl heq)
      · rcases List.mem_cons.mp hm with heq | hmem
        · exact Or.inl heq
        · exact Or.inr (Or.inr hmem)
    by_cases h : score b ≤ score (pick score base bs)
    · simp only [pick, if_pos h]
      rcases hc with heq | hm
      · subst a
        exact Nat.le_refl _
      · exact Nat.le_trans h (ih hm)
    · simp only [pick, if_neg h]
      rcases hc with heq | hm
      · subst a
        omega
      · exact ih hm

/-- Scenario-wise offline optimum and regret, defined without choice. -/
def oracleCost {X : Type u} {A : Type v} (cost : A → X → Nat)
    (base : A) (actions : List A) (x : X) : Nat :=
  cost (pick (fun a => cost a x) base actions) x

def regret {X : Type u} {A : Type v} (cost : A → X → Nat)
    (base : A) (actions : List A) (a : A) (x : X) : Nat :=
  cost a x - oracleCost cost base actions x

theorem oracle_le {X : Type u} {A : Type v} (cost : A → X → Nat)
    (base : A) (actions : List A) (a : A) (x : X)
    (ha : a = base ∨ a ∈ actions) : oracleCost cost base actions x ≤ cost a x :=
  pick_le (fun a => cost a x) base actions a ha

theorem regret_zero_iff {X : Type u} {A : Type v} (cost : A → X → Nat)
    (base : A) (actions : List A) (a : A) (x : X)
    (ha : a = base ∨ a ∈ actions) :
    regret cost base actions a x = 0 ↔ cost a x = oracleCost cost base actions x := by
  have h := oracle_le cost base actions a x ha
  unfold regret
  omega

section Ports
variable {X : Type u} {A : Type v} {Z : Type w} [DecidableEq Z]

/-- Loss on an observed fibre. Scenarios outside it contribute zero. -/
def fiberWorst (obs : X → Z) (loss : A → X → Nat) (worlds : List X)
    (z : Z) (a : A) : Nat :=
  worst (fun x => if obs x = z then loss a x else 0) worlds

theorem fiber_mem_le (obs : X → Z) (loss : A → X → Nat) (worlds : List X)
    (z : Z) (a : A) (x : X) (hx : x ∈ worlds) (hz : obs x = z) :
    loss a x ≤ fiberWorst obs loss worlds z a := by
  unfold fiberWorst
  simpa only [if_pos hz] using
    (mem_le_worst (fun y => if obs y = z then loss a y else 0) worlds x hx)

theorem fiber_le (obs : X → Z) (loss : A → X → Nat) (worlds : List X)
    (z : Z) (a : A) (b : Nat)
    (h : ∀ x, x ∈ worlds → obs x = z → loss a x ≤ b) :
    fiberWorst obs loss worlds z a ≤ b := by
  unfold fiberWorst
  apply worst_le
  intro x hx
  by_cases hz : obs x = z
  · simpa only [if_pos hz] using h x hx hz
  · simp [hz]

/-- Independent minimization on each fibre. -/
def policy (obs : X → Z) (loss : A → X → Nat) (worlds : List X)
    (base : A) (actions : List A) (z : Z) : A :=
  pick (fiberWorst obs loss worlds z) base actions

def policyRisk (obs : X → Z) (loss : A → X → Nat) (worlds : List X)
    (pi : Z → A) : Nat :=
  worst (fun x => loss (pi (obs x)) x) worlds

/-- Max of fibre minima, indexed by worlds to avoid enumerating Z. -/
def value (obs : X → Z) (loss : A → X → Nat) (worlds : List X)
    (base : A) (actions : List A) : Nat :=
  worst (fun x => fiberWorst obs loss worlds (obs x)
    (policy obs loss worlds base actions (obs x))) worlds

theorem policy_allowed (obs : X → Z) (loss : A → X → Nat) (worlds : List X)
    (base : A) (actions : List A) (z : Z) :
    policy obs loss worlds base actions z = base ∨
      policy obs loss worlds base actions z ∈ actions :=
  pick_allowed (fiberWorst obs loss worlds z) base actions

/-- T18.1, lower bound: every admissible policy has at least this risk. -/
theorem value_le_policy (obs : X → Z) (loss : A → X → Nat) (worlds : List X)
    (base : A) (actions : List A) (pi : Z → A)
    (allowed : ∀ z, pi z = base ∨ pi z ∈ actions) :
    value obs loss worlds base actions ≤ policyRisk obs loss worlds pi := by
  unfold value
  apply worst_le
  intro x hx
  apply Nat.le_trans (pick_le (fiberWorst obs loss worlds (obs x)) base actions
    (pi (obs x)) (allowed (obs x)))
  apply fiber_le
  intro y hy hobs
  unfold policyRisk
  rw [← hobs]
  exact mem_le_worst (fun y => loss (pi (obs y)) y) worlds y hy

/-- T18.1, attainment by a computable deterministic fibre policy. -/
theorem policy_attains (obs : X → Z) (loss : A → X → Nat) (worlds : List X)
    (base : A) (actions : List A) :
    policyRisk obs loss worlds (policy obs loss worlds base actions) =
      value obs loss worlds base actions := by
  apply Nat.le_antisymm
  · unfold policyRisk
    apply worst_le
    intro x hx
    apply Nat.le_trans (fiber_mem_le obs loss worlds (obs x)
      (policy obs loss worlds base actions (obs x)) x hx rfl)
    exact mem_le_worst (fun y => fiberWorst obs loss worlds (obs y)
      (policy obs loss worlds base actions (obs y))) worlds x hx
  · exact value_le_policy obs loss worlds base actions _
      (policy_allowed obs loss worlds base actions)

/-- T18.6: bounded minimax risk iff every realized fibre has a common
    action satisfying the bound. T18.2 is epsilon = 0 for regret. -/
theorem epsilon_sufficient_iff (obs : X → Z) (loss : A → X → Nat)
    (worlds : List X) (base : A) (actions : List A) (eps : Nat) :
    value obs loss worlds base actions ≤ eps ↔
    ∀ x, x ∈ worlds → ∃ a : A, (a = base ∨ a ∈ actions) ∧
      ∀ y, y ∈ worlds → obs y = obs x → loss a y ≤ eps := by
  constructor
  · intro hv x hx
    let a := policy obs loss worlds base actions (obs x)
    refine ⟨a, policy_allowed obs loss worlds base actions (obs x), ?_⟩
    intro y hy hz
    apply Nat.le_trans (fiber_mem_le obs loss worlds (obs x) a y hy hz)
    exact Nat.le_trans (mem_le_worst (fun z => fiberWorst obs loss worlds (obs z)
      (policy obs loss worlds base actions (obs z))) worlds x hx) hv
  · intro h
    unfold value
    apply worst_le
    intro x hx
    obtain ⟨a, ha, hbound⟩ := h x hx
    exact Nat.le_trans (pick_le (fiberWorst obs loss worlds (obs x)) base actions a ha)
      (fiber_le obs loss worlds (obs x) a eps hbound)

/-- T18.3: an explicit decoder witnesses a refinement on this domain. -/
theorem refinement_monotone {Z' : Type t} [DecidableEq Z']
    (old : X → Z) (new : X → Z') (decode : Z' → Z)
    (loss : A → X → Nat) (worlds : List X) (base : A) (actions : List A)
    (hdecode : ∀ x, x ∈ worlds → old x = decode (new x)) :
    value new loss worlds base actions ≤ value old loss worlds base actions := by
  let pi := fun z => policy old loss worlds base actions (decode z)
  have ha : ∀ z, pi z = base ∨ pi z ∈ actions := by
    intro z
    exact policy_allowed old loss worlds base actions (decode z)
  apply Nat.le_trans (value_le_policy new loss worlds base actions pi ha)
  rw [← policy_attains old loss worlds base actions]
  unfold policyRisk
  apply worst_le
  intro x hx
  change loss (policy old loss worlds base actions (decode (new x))) x ≤ _
  rw [← hdecode x hx]
  exact mem_le_worst (fun y => loss (policy old loss worlds base actions (old y)) y)
    worlds x hx

end Ports

/-- T18.4: paid observation is strictly worthwhile exactly below its value. -/
theorem paid_strict_iff (old new price : Nat) :
    price + new < old ↔ price < old - new := by omega

section Witnesses

def bits : List (Bool × Bool) :=
  [(false,false), (false,true), (true,false), (true,true)]

def parity (x : Bool × Bool) : Bool := if x.1 then !x.2 else x.2

def parityLoss (a : Bool) (x : Bool × Bool) : Nat := if a = parity x then 0 else 1

/-- T18.5: the two observations have zero separate but positive joint value. -/
theorem xor_synergy :
    value (fun _ : Bool × Bool => ()) parityLoss bits false [true] = 1 ∧
    value (fun x : Bool × Bool => x.1) parityLoss bits false [true] = 1 ∧
    value (fun x : Bool × Bool => x.2) parityLoss bits false [true] = 1 ∧
    value (fun x : Bool × Bool => x) parityLoss bits false [true] = 0 := by decide

/-- T19 witness: three bits, one selector and two possible payloads. -/
def triples : List (Bool × Bool × Bool) :=
  [(false,false,false), (false,false,true), (false,true,false), (false,true,true),
   (true,false,false), (true,false,true), (true,true,false), (true,true,true)]

def mux (x : Bool × Bool × Bool) : Bool := if x.1 then x.2.2 else x.2.1

def muxLoss (a : Bool) (x : Bool × Bool × Bool) : Nat := if a = mux x then 0 else 4

def probe (i : Nat) (x : Bool × Bool × Bool) : Bool :=
  if i = 0 then x.1 else if i = 1 then x.2.1 else x.2.2

def fixedCost (qs : List Nat) : Nat :=
  qs.length + value (fun x => qs.map (fun q => probe q x)) muxLoss triples false [true]

def fixedSubsets : List (List Nat) := [[],[0],[1],[2],[0,1],[0,2],[1,2],[0,1,2]]

def adaptiveRead (x : Bool × Bool × Bool) : Bool :=
  if probe 0 x then probe 2 x else probe 1 x

def adaptiveRisk : Nat := worst (fun x => 2 + muxLoss (adaptiveRead x) x) triples

/-- A finite witness: paying for two conditional reads beats every fixed subset.
    The read cost is one, and incorrect action costs four. -/
theorem adaptive_beats_fixed : adaptiveRisk = 2 ∧
    fixedCost (pick fixedCost [] fixedSubsets) = 3 := by decide

end Witnesses
end CRTT.Observation

#print axioms CRTT.Observation.policy_attains
#print axioms CRTT.Observation.epsilon_sufficient_iff
#print axioms CRTT.Observation.refinement_monotone
#print axioms CRTT.Observation.paid_strict_iff
#print axioms CRTT.Observation.xor_synergy
#print axioms CRTT.Observation.adaptive_beats_fixed
