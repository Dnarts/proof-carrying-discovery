# CRTT-T21 v0.1.1 — VERIFIED

Evidence: the user's local Lean 4.36.0 report for v0.1 identifies four root
recursive-call type errors (original lines 77, 81, 86, 99), six failed
constructor reductions, five blocked `decide` witnesses, and transitive
`sorryAx` dependencies. The original source and archives are preserved.
The report is not a new execution of this revision.

## Root correction

`TransferPath S T` is an indexed family. `S` is its fixed parameter; `T` is
an index that changes when recursing on the `prior` of a `step`. The original
equation functions mentioned `T` outside the recursive telescope, causing
recursive calls to expect the original destination. This revision puts the
implicit destination in the function-type telescope in each of `pathOverhead`,
`collapse`, `executePath`, `appendPath`. The latter varies the destination of
its second path, preserving the first path. A `termination_by structural`
annotation requests structural recursion; it is not a well-founded fallback.

The typed ADT, operational meaning, expense accounting and all original
statements are retained. No path is replaced by an untyped list, no proofs are
weakened, and no placeholder or classical/noncomputable definition is added.
`choose_mem` also specifies the target and the base option explicitly.

## New proof gates (in the module, not yet kernel-checked)

- `overhead_single`, `overhead_step`
- `collapse_single`, `collapse_step`
- `execute_single`, `execute_step`
- `append_single`, `append_step`

All eight use `rfl`, so they require actual definitional equality. In
`Witnesses.two_edge_computes`, a translated source tree is followed by a
priced identity edge; `decide` must compute the overhead (3) and execution
(0). The existing single-edge witnesses and all original proof obligations
remain unchanged. These gates are intended to distinguish fixing the root
computational semantics from merely repairing a downstream tactic.

`run_verify.sh` invokes `audit_lean.py` even if Lean exits unsuccessfully.
The audit reports received and missing declarations, disallowed axioms,
warnings and errors; a nonzero compiler status always prevents progress to
downstream modules. It does not label unprinted reports as clean. Synthetic
fixtures exercise the audit parser. The original Python model is unchanged.

References for the structural recursion design (not a compiler execution):
https://lean-lang.org/doc/reference/latest/Definitions/Recursive-Definitions/

## Status

**VERIFIED on Lean 4.36.0** (`Lean (version 4.36.0, arm64-apple-darwin24.6.0,
commit 611c117)`). `run_verify.sh` exits 0 on a fresh extraction:

- both manifests verify (8 entries plus 2 upstream entries);
- all three modules compile with zero diagnostics — no `warning:`, no `error:`;
- 22 + 22 + 51 = 95 axiom reports received, matching the 95 `#print axioms`
  commands, with `propext` and `Quot.sound` the only permitted dependencies;
- no `sorryAx`, no `Classical.choice` anywhere in the audited declarations;
- all 10 synthetic audit-parser fixtures pass;
- the independent finite Python cross-check passes.

The root correction was accepted by the kernel: the four recursive-call type
errors at the original lines 77, 81, 86, 99 are gone, the six constructor
reductions succeed, and the five blocked `decide` witnesses now compute. The
eight new `rfl` gates (`overhead_single`/`_step`, `collapse_single`/`_step`,
`execute_single`/`_step`, `append_single`/`_step`) hold by definitional
equality as intended, and `Witnesses.two_edge_computes` computes overhead 3 and
execution 0.

This revision is promoted from `REPAIR_CANDIDATE` to `VERIFIED` on the strength
of that run. Consumers must still rerun the script themselves and read the
`#print axioms` output; a recorded PASS is not a substitute for kernel
acceptance on their machine.
