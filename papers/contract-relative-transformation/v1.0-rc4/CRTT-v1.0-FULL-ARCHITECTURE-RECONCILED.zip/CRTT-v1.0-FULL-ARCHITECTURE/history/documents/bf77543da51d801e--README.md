# CRTT — T03 / T19, source repair v0.1.1

**Status: repair candidate. Independent finite checks PASS. Lean kernel status for v0.1.1: UNTESTED.**

Parent v0.1: the user reported successful T03 compilation with 10 constructor-name warnings, but T19 failed elaboration (8 diagnostics and downstream `sorryAx`). This revision retains the problem definitions, solver, theorem statements and witness instances. It specializes the maximum and argmin lemmas, replaces the ambiguous rewrite in `bellman` by explicit function/list equalities, and proves the terminal case of `capped_cost` directly. It renames local variables in T03 rather than changing constructors. The previous T03 audit reported `coarsest_exists_iff`, `path_no_coarsest` and `triangle_no_coarsest` depending on `Classical.choice`; `coarsest_unique` and `exact_target_coarsest` had no axiom dependencies. The classical dependencies are permitted for T03; the repair does not remove them. No proof obligations are weakened or removed.

The original v0.1 archive was checked against its six manifest entries and left unchanged. The new revision has not been compiled because Lean is not installed in the authoring environment and compiler retrieval failed. Run the strict verification script on Lean 4.36.0 to establish the new status.
Target Lean: 4.36.0 (Std only). The existing verified CRTT-v0.2/T17/T18 archives are not changed. This package contains standalone new modules in separate namespaces. A proof script is not a kernel certificate until Lean has accepted it. There is no intended `sorry`, `admit`, custom `axiom` or `native_decide` in the new modules. Actual transitive axiom dependencies must be read from the kernel output.

## SufficientPartitions.lean — T03

Model: a state type X, an action type A, a predicate `valid : X → A → Prop`. A partition is represented by an equivalence relation. A sufficient partition has an action common to all members of each equivalence class. Refinement is relation inclusion; a greatest sufficient relation is the coarsest sufficient partition (not merely a maximal one).

Main statements:

- `coarsest_exists_iff`: a coarsest sufficient partition exists iff pairwise compatibility itself is an equivalence relation and is sufficient. The theorem is phrased for arbitrary types; the proof derives pointwise feasibility from existence of a sufficient partition and uses classical case distinction when constructing a pair merge. It does not assert an executable search on arbitrary types. No globally indexed choice function is needed in this argument; check actual axiom dependencies in Lean.
- `coarsest_contains_compatible`: a greatest sufficient partition must merge every compatible pair.
- `coarsest_unique`: uniqueness of the resulting relation, not of its encoding.
- `exact_target_coarsest`: for an exact function target, its kernel is the coarsest sufficient relation.
- `path_no_coarsest`: three feasible states with nontransitive pairwise compatibility.
- `triangle_no_coarsest`: all pairs are compatible, compatibility is an equivalence, but there is no common action for the class. Hence transitivity alone is insufficient.

This result concerns all equivalence relations, not a restricted observation language. It makes no efficiency claim for observation or decision computation.

## AdaptiveObservation.lean — T19

Model: finite explicit lists of possible worlds, available ports and actions; one fixed world per run; deterministic, noiseless binary observations; nonnegative natural-number observation costs and action losses. The action list contains a designated default plus alternatives. Use terminal regret as `loss` when instantiating T18. The solver receives the list of possible worlds, not the actual world. The allowed class consists of finite observation trees of depth at most n, without repeating a port along a branch. Empty branches have worst cost zero; the Bellman identity with added observation price is stated for nonempty belief lists.

`solve` constructs a tree by choosing between an optimal immediate action and every allowed first observation, with recursively optimized subtrees. `runCost` charges only the realized path. `Legal` checks the horizon, allowed actions and available ports. The solver uses explicit finite search; no complexity or performance guarantee is claimed. For a full no-repeat problem choose n equal to the number of available ports (or at least their number of distinct elements).

Theorem map:

| Gate | Declarations |
|---|---|
| T19.1 Operational semantics | `runCost`, `worst_observe`, `runCost_split`, `solve_legal` |
| T19.2 Bellman recursion and universal lower bound | `bellman`, `value_zero`, `value_empty`, `value_no_ports`, `solve_optimal` |
| T19.3 Attainment | `solve` together with `solve_legal` and `solve_optimal`, `cost_feasible_iff` |
| T19.4 Static comparison | `fixedSolve_follows`, `fixed_optimal`, `schedules_complete`, `schedules_sound`, `bestSchedule_legal`, `static_optimal`, `adaptive_le_static` |
| T19.5 Multiplexer | `Witnesses.mux_tree_legal`, `mux_tree_cost`, `mux_adaptive_value`, `mux_static_value`, `mux_adaptive_beats_static`, `mux_lower_bound`, `mux_static_lower_bound` |
| T19.6 Greedy failure | `Witnesses.xor_greedy_failure` |
| T19.7 Hard tolerance | `epsilon_budget_iff`, `Witnesses.mux_exact_observation_budget` |

Static policies may choose their final action as a function of all purchased observations, but the port schedule is fixed in advance. `schedules` enumerates all legal ordered no-repeat schedules up to n. This deliberately allows the full class of fixed policies, not just a fixed constant answer. An adaptive tree may stop early and choose different ports in different branches.

T19.7 does not conflate the observation budget with a penalty-weighted terminal objective. For a fixed observation budget B and terminal-loss tolerance eps, replace the terminal loss by zero if it is within eps and B+1 otherwise. The exact feasibility equivalence follows because observation costs are nonnegative. This decides feasibility, and by checking budgets it supports a search for the minimum feasible budget; a separate global minimum-budget algorithm is not claimed. If there is no feasible policy at any budget, the decision remains negative.

The multiplexer and XOR numerical statements are defined from actual domain and tree semantics. They are not declarations of unconnected numerical constants. The Python check independently enumerates all trees for small problems and computes the larger witness by a Bellman recurrence and all fixed subsets.

## Verification

```bash
bash run_verify.sh
```

This checks the manifest, runs Lean on both standalone modules, rejects warnings and placeholder dependencies, requires the audited T19 declarations to be free of `Classical.choice`, then runs the Python cross-check. It fails immediately if a step fails; do not interpret a missing compiler or the Python result as kernel verification. Record the full stdout/stderr and exit status on the target machine. `#print axioms` commands in each module expose the core proof dependencies. A proof with `sorryAx` must be rejected. Classical decidability in T03 may introduce classical axiom dependencies; this is distinct from the intended constructive finite solver in T19.

For Python-only verification:

```bash
python3 check_finite.py
```

The included FINITE_CHECK.log is a real Python run on the authoring container. Exhaustive finite checks support the mathematical statement and algorithm but do not establish Lean elaboration or kernel acceptance.

## Scope not covered

The previously audited T18 global `argminPolicy` bridge is not changed in this package. T20 (transfer of investigation trees), noisy observations, randomized policies, continuous outcomes, efficient memoization, and nonstationary worlds remain separate work. T03 and T19 proofs are source candidates for the declared semantics; no claim of literature novelty is made.
