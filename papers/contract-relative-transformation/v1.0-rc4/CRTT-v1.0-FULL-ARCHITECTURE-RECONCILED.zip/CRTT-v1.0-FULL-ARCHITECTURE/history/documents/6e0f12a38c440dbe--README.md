# CRTT-T21-v0.1.1 — Certified Investigation Library

Status: **REPAIR_CANDIDATE / LEAN_KERNEL_UNTESTED**.

A standalone research package extending the verified T19/T20 interface, with no
LLM, Mathlib, or new model assumptions. The two imported Lean files are exact
copies from `CRTT-T20-v0.1.2-verified.zip`; `UPSTREAM_SHA256.txt` records their
original checksums. The original v0.1 failed the supplied local Lean 4.36.0 audit. This repair
revision has not been compiled in the authoring environment. See
`REPAIR_NOTES.md` for the root-cause analysis and new obligations. The supplied Python checks are independent finite
cross-checks, not Lean proofs. The `#print axioms` statements are obligations
for the local audit, not advance claims of its outcome.

## Semantic contract

`ResearchTask` packages the heterogeneous world, port and action carrier types,
`TaskSpec`, and the actual port equality decision procedure. `Tree`, `taskLegal`,
`taskCost`, `taskOptimum`, `taskOptimizer` reuse the verified T19/T20 semantics.

`LibraryEntry` contains an actual legal tree and proof of its own hard observation
budget and terminal tolerance. The provenance string is descriptive metadata;
it does not prove historical authenticity. The library is not restricted to
optimal trees. `TransferCandidate` combines a source entry and an already
provided, certified `TransferPath` to a specified target. The path retains each
edge and its declared expense; `collapse` composes only the T20 certificates.

All tariffs are nonnegative natural numbers in a common unit. They are external
cost-model inputs, not measurements or formal running-time bounds of Lean code.
`EdgeExpense` includes route-specific access, validation and translation fees.
Shared search, enumeration, ranking, rejected-candidate evaluation and other
mandatory expenses must be separately charged, once, with `afterSearch` or in
`UseCost.overhead`. No successful theorem about model costs establishes that a
real implementation is faster than fresh synthesis.

### T21.1 — economically rational reuse

Let D be the full fresh synthesis/validation charge, V the optimal execution
cost, H the transfer overhead and E the actual transferred execution cost.
Candidate legality and T19 optimality entail V <= E. Compare H+E < D+V first.
`paid_candidate_iff` derives H+(E-V) < D; truncated subtraction is sound because
V <= E. The scalar proof uses explicit Nat inequalities and a small arithmetic
`omega` proof, rather than assuming nonnegative excess. For a completed search
with an additional common fee F, compare F+H+E with D+V.

### T21.2–3 — typed entries and priced paths

`TransferPath.single` / `TransferPath.step` admit heterogeneous intermediate
carriers. Direct reuse is an identity edge with its actual charge. `appendPath`
concatenates paths; `collapse` composes the morphisms. In v0.1.1 the four
recursive operations explicitly generalize the destination index in their
recursive telescope, with `termination_by structural`. Eight `rfl`
computation lemmas and a closed two-edge witness are additional gates. `collapse_exec`,
`append_execution` and `append_overhead` connect syntax translation, composition
and additivity. `path_legal`, `path_cost_le`, `path_hard_contract` inherit the
proved T20 properties. Execution cost cannot increase relative to the source,
but the complete bill can increase because of transfer fees.

The constructed witness uses a source with both actions costing 2, and a target
with corresponding actions costing 2 and 0. Both morphisms are legal and loss
nonincreasing. The same source-optimal action is transported through a zero-fee
route to cost 2, or through a unit-fee route to cost 0. The lower-fee route is not
the lower-total-cost route. With mutual simulation and a source-optimal tree,
`mutual_path_execution` and `mutual_paths_compare` reduce comparison of route
bills to comparison of fees. This does not search for a shortest path.

### T21.4–6 — finite offer selection, extension, and mandatory costs

`choose freshQuote candidates` selects an Option: `none` denotes fresh synthesis,
not abstention; `some c` denotes an actual already found route. `best` evaluates
its cost. The finite selector uses T19 `pick`, with the fresh alternative winning
exact ties. It never invokes the fresh solver just to compute the comparator.
`chooseAgainstOptimum` is an exact *reference evaluator* computing D+V; it may
itself have to solve the target problem and makes no computational-saving claim.
The operational caller must supply a trustworthy and feasible fresh quote; an
estimate only proves optimality relative to that estimate.

The soft objective is total worst-case cost; it is not automatically a hard
budget/tolerance contract. `chosen_hard_contract` requires eligibility of all
supplied candidates for a common hard contract, and the fresh alternative must
separately be feasible for that same contract. Filtering and certifying such a
fresh comparator are not implemented as a separate optimization algorithm here.
`Listed` ties offered entries to the actual library. `best_monotone` applies when
all previous offers and their tariffs are retained. Mere growth of a historical
library need not expand the found offers. `afterSearch` charges the shared cost
of finding/evaluating them, even when fresh synthesis ultimately wins.
`search_profitable_iff` characterizes strict net benefit from paying that fee.
The bloat witness models a mandatory size-based scan (cost 2 -> 3 at budget 2),
with an identical useful offer before and after adding an unused entry. It does
not apply to freely ignorable or freely indexable entries.

### T21.7 — fixed feasible stream amortization

For each task i let D_i, V_i, H_i, E_i denote its fresh discovery charge, optimal
execution cost, all reuse overhead and transferred execution cost, respectively.
E_i >= V_i and delta_i = E_i - V_i. Charge a one-time acquisition K once:

    fresh = sum_i (D_i + V_i)
    cumulative = K + sum_i (H_i + E_i)
    cumulative < fresh iff K + sum_i (H_i + delta_i) < sum_i D_i.

If acquisition is sunk use K=0. If acquisition also solves a task, compare plans
serving exactly the same task stream: account for that task on BOTH sides and
avoid double-counting its costs. The theorem permits nonuniform per-use prices.
It is exact accounting for a fixed feasible sequence, not an offline or online
optimizer for acquisition, retention, eviction, or future reuse. Unknown future
applicability and search costs remain separate research problems.

### T21.8 — semantic oracle vs realized search

`Admitted` requires library membership AND an external issued-offer predicate
fixing which certificates and prices may be used. In a hard-contract experiment
the predicate also restricts the service class. Arbitrary declarations of zero
fees cannot silently enter the oracle space. `OracleOptimal` is a specification
of an attaining optimum over all admitted offers and the fresh alternative.
`enumerated_oracle` constructs an attaining witness when the issued registry is
an explicit exhaustive finite list; there is no unconditional computable oracle
for all functions, all certificates, or all arbitrarily long paths.
`oracle_le_realized` and `search_gap_accounting` quantify incompleteness of a
supplied candidate list. `CostComplete` is sufficient for matching the oracle:
for every admitted offer there is a listed offer no worse in total cost. It is
stronger than merely finding an optimal offer; full proof-term enumeration is
unnecessary. Search expense and the remaining optimality gap are distinct.
T22 must discover, certify and price new morphisms under a declared access and
cost model. T21 does not assume T22 is solved.

## Proof obligations in the new module

| Gate | Lean declarations |
|---|---|
| T21.1 | `candidate_optimum_le`, `residual_comparison`, `paid_candidate_iff` |
| T21.2 | `ResearchTask`, `LibraryEntry`, `TransferCandidate`, `candidate_legal`, `candidate_hard_contract` |
| T21.3 | `TransferPath`, `collapse_exec`, `append_execution`, `append_overhead`, `path_legal`, `path_cost_le`, `path_hard_contract`, `mutual_path_execution`, `mutual_paths_compare`, `Witnesses.cheaper_path_not_cheaper_total` |
| T21.4 | `choose`, `choose_mem`, `chosen_from_list`, `best_le_fresh`, `best_le_candidate`, `best_attained`, `chosen_from_library`, `chosen_hard_contract` |
| T21.5 | `listed_monotone`, `best_monotone` |
| T21.6 | `search_profitable_iff`, `Witnesses.library_bloat_witness`, `Witnesses.bloat_budget_barrier` |
| T21.7 | `UseCost`, `use_accounting`, `stream_accounting`, `amortization_iff` |
| T21.8 | `OracleOptimal`, `oracle_le_realized`, `complete_search_matches_oracle`, `enumerated_oracle`, `search_gap_accounting` |

## Verification

Expected toolchain: Lean 4.36.0 (same as supplied T20 verification), Python 3,
standard shell. No Mathlib or external Python packages.

```sh
bash run_verify.sh
```

The fail-closed script checks the manifest and original upstream source hashes,
compiles T19, T20 and T21 in dependency order in a temporary directory, audits
the names and exact number of `#print axioms` reports (also inspects partial
reports emitted on compilation failure) and rejects warnings, `sorryAx`,
`Classical.choice` or unexpected axiom dependencies. The only permitted standard
axioms are `propext`, `Quot.sound`. It then executes the independent finite tests. The standalone audit-parser
fixtures in `test_audit.py` exercise the fail-closed diagnostic logic; they
are synthetic logs, not evidence of Lean compilation.
Exit 127 means Lean is absent, not success. Exit nonzero at any step invalidates
the package verification. To run finite checks alone: `python3 check_library.py`.
The `FINITE_CHECK.log` file records the actual authoring-time Python execution.

## Next gate

Freeze T21 only after the repaired definitions, computation lemmas and all original
theorems compile locally, and the axiom audit and cross-checks pass. T22 should synthesize maps over finite declared domains, not enumerate
arbitrary total functions/proof terms. Price computation and the source of
access to read/loss tables must be explicit, and search completeness must be
stated relative to the admitted morphism language. No empirical LLM data are
premises of these mathematical statements.
