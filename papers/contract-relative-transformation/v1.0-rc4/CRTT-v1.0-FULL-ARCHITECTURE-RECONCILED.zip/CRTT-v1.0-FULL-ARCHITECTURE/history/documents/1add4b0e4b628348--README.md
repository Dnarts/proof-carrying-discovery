# CRTT-T29-v0.1 — Correlated Admission and Finite Self-Modification Histories

Status: **SOURCE_CANDIDATE / LEAN_KERNEL_UNTESTED for RecursiveAdmission.lean**.
Parent: `CRTT-T28-v0.1.1-verified (1).zip`. Its 58 manifest entries were
checked. All fourteen inherited Lean modules are byte-identical; both strict
text auditors were replayed over the supplied 395 parent reports. The parent
kernel log is preserved as T28_KERNEL_CHECK.log. T28's independent Python
replacement model was rerun, and its output is byte-identical. No new Lean
compilation was possible in the author environment. The new module requests
49 additional axiom reports (444 total, fifteen modules).

## What the module actually proposes

1. Generic deterministic prefix accounting (`run_shift_spent`,
   `execute_prefix_bill`): reset of the local spent counter when resuming a
   funded continuation does not double-charge a prefix. `remainingBill_prefix`
   specializes this to the actual T28 continuation, not a fresh root run.
2. Joint lower/upper evidence. `RelativeOffer` is indexed by its exact old
   continuation. Its proof requires at least one offered row to cover the
   actual old/new completion bills jointly. `relativeOK` scans rows, not future
   executions; `paired_gain` and `relative_sound` establish strict improvement
   when every row clears validation and migration fees. Empty evidence cannot
   construct a valid offer. `fromAbsolute` embeds T28's original certificate.
3. T27 bridge (`fromDecision`, `decision_offer_gain`): a T27 regret certificate
   bounds the candidate by its reference plus epsilon on the belief. A separate
   strict incumbent margin and a joint actual-cost coverage proof are required.
   The declared reference need not be an exact global optimum for this bound.
4. Relative admission checks fallback liquidity BEFORE charging validation,
   candidate liquidity BEFORE migration, and strict joint gain. The base
   tariff is fixed. Rule semantics are certified by the existing T23 type;
   the abstract rule and validation fees are supplied data, not measured time.
   Accepted/rejected receipts are kept in a separate typed journal, rather than
   pretending the more restrictive T28 absolute gate has passed.
5. `Step` and indexed `Chain` represent actual finite histories of advances,
   relative attempts, and external paid evidence receipts. The root task pair
   remains fixed. `chain_preserves` retains prior certificates, search receipts,
   relative journal and the previous T28 history; base fees remain equal.
   `chain_funds` and `chain_paid_bound` conserve funds and bound paid attempts.
   A deferred attempt consumes no resources and does not change the session.
6. `objective = spent + remainingBill` is specification-only. The ordinary
   paid prefix conserves it, a paid rejection increases it by its fee,
   acquisition recording increases it by its fee, and an accepted replacement
   strictly decreases it by its actual net gain. `chain_objective` telescopes
   this identity. `chain_final_gain_iff` states that completing the endpoint is
   strictly cheaper than completing the start iff total accepted gains exceed
   rejection and acquisition overhead. `chain_accepted_limit` bounds the number
   of acceptances by initial objective plus accumulated overhead.

## Verification boundaries

* The new Lean declarations are proof-source candidates, not kernel results.
  No new theorem is assumed on the basis of the Python checks.
* A model and its joint cost coverage proof are supplied from outside. The
  actual hypothesis need not be exposed to the gate; obtaining/validating a
  model can be expensive. `fromDecision` prepares rows from a supplied model.
  `recordEvidence` meters a declared external charge; it is NOT a generator of
  new truthful evidence, a proof of acquisition execution, or a statistical
  calibration method. The gate does not run prospective completion to score a
  candidate. Construction of evidence and full model costs must be charged
  before claiming economic gains in a deployment.
* Results compare actual abstract completion bills under fixed root tasks,
  fixed base fees and the declared rule-cost contract, not arbitrary algorithms
  or CPU/memory time. Correlated rows used in the synthetic cross-check are
  offline fixtures, not learned predictive models.
* The journal is a functional in-memory record; its prefix theorem preserves
  prior content along generated steps, not authenticity or tamper resistance
  of externally serialized states. Labels are provenance metadata, not proofs
  of origin. `Chain` describes finite sequences and is not an autonomous
  scheduler. Free deferred steps may recur indefinitely; only paid attempts
  are bounded by funds. The controller replacement still changes static T23
  rule queues, not the entire learned state or the verifier of replacements.
* Upstream manifests and logs are retained verbatim under historical names.
  Historical path names are not interpreted as current paths; the new complete
  manifest covers every payload, including all previously unlisted manifests.

## Reproduction

Use Lean 4.36.0. Preserve the immutable input and write the new log externally:

```bash
set -o pipefail
bash run_verify.sh 2>&1 | tee ../T29-KERNEL_CHECK.log
```

Both text auditors and compiler exit status are required for all 444 requested
reports. `check_recursive.py` is an independent finite reference model, not
execution of the Lean module. The new finite log is FINITE_RECURSIVE.log.
