# T29 → T30 — from finite admitted histories to a replaceable meta-controller

## Gate 0: kernel-check T29

All 49 new reports must pass without weakening theorem statements. The parent
395 reports do not establish the new results. Keep the parent bytes unchanged.

## Gate 1: actual paid acquisition, not an accounting receipt

Connect T27's evidence-query tree and its observed replies to `RelativeOffer`.
A successful refinement must retain a witness for the actual paired cost model.
Debit the costs of observation, certificate construction, verification, failed
proposals and migration exactly once; establish liquidity throughout acquisition.
A regret certificate alone cannot justify replacement. A prior charge recorded
in the ledger is sunk for the *next* local comparison but not for the whole
history. For global net gain it must still be paid by the cumulative savings.

Hypothesis: joint evidence may be substantially cheaper than independent exact
cost evidence, since common nuisance terms cancel. Compare explicit paid
acquisition policies against the fixed T28 control. Do not assume that the cost
of constructing the catalogue or computing the reference values is negligible.

## Gate 2: learned continuation replacement

Extend T29 to LearningDiscovery: retain active cores, pending compilation,
remaining frontier, emitted certificates and all paid receipts. Optional
learning may be cancelled only under an explicit handoff contract. A full
state-preservation theorem must distinguish obligations from optional work.

## Gate 3: admission controller as the object of replacement

Make the proposal scheduler an explicit finite executable policy (not the
trusted verifier). Declare its observable state, actions, cost, and allowed
replacement language. Use T19/T27 for finite policy selection and T29 for
admission. Keep root semantics, admissibility rules, fee authority and proof
checker fixed. Prove every reachable state preserves the contract by induction
on actual transitions. Require a separate resource bound for proposal synthesis.

A useful sufficient bound for a finite history is paidAttempts + balance_final
<= balance_initial. This does not prove scheduler termination. Prohibit free
self-loops, or require a well-founded administrative measure, if total execution
termination is claimed. For histories that contain paid rejection/acquisition,
accepted count <= initial objective + cumulative overhead, not necessarily <=
initial objective. Global improvement iff cumulative accepted gain exceeds
all nonproductive paid overhead. A finite sequence of valid improvements need
not be optimal or monotonically cheaper at every step.

## Gate 4: persistence and fail-closed migration

The current pure model is atomic by definition, not an implementation of crash
recovery. Introduce explicit prepare/validate/commit/abort receipts, exact
versioned continuation identity, persisted funds and atomic readback witnesses.
Preserve causal provenance independently of superseded active controllers.
Reject stale evidence when the continuation changes. Formalize the interruption
model rather than calling functional state equality proof of durable storage.
