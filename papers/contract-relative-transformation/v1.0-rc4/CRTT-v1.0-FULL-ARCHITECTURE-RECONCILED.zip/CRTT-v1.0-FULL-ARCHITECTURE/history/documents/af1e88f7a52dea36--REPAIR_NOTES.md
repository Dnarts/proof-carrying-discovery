# CRTT-T21 v0.1.1 — repair candidate

Evidence: the user's local Lean 4.36.0 report for v0.1 identifies four root
recursive-call type errors (original lines 77, 81, 86, 99), six failed
constructor reductions, five blocked `decide` witnesses, and transitive
`sorryAx` dependencies. The original source and archives are preserved.
The report is not a new execution of this revision.

## Root correction

`TransferPath S T` is an indexed family. `S` is its fixed parameter; `T` is
an index that changes when recursing on the `prior` of a `step`. The original
equation functions mentioned `T` outside the recursive telescope, causing
recursive calls to expect the original destination. This revision puts the
implicit destination in the function-type telescope in each of `pathOverhead`,
`collapse`, `executePath`, `appendPath`. The latter varies the destination of
its second path, preserving the first path. A `termination_by structural`
annotation requests structural recursion; it is not a well-founded fallback.

The typed ADT, operational meaning, expense accounting and all original
statements are retained. No path is replaced by an untyped list, no proofs are
weakened, and no placeholder or classical/noncomputable definition is added.
`choose_mem` also specifies the target and the base option explicitly.

## New proof gates (in the module, not yet kernel-checked)

- `overhead_single`, `overhead_step`
- `collapse_single`, `collapse_step`
- `execute_single`, `execute_step`
- `append_single`, `append_step`

All eight use `rfl`, so they require actual definitional equality. In
`Witnesses.two_edge_computes`, a translated source tree is followed by a
priced identity edge; `decide` must compute the overhead (3) and execution
(0). The existing single-edge witnesses and all original proof obligations
remain unchanged. These gates are intended to distinguish fixing the root
computational semantics from merely repairing a downstream tactic.

`run_verify.sh` invokes `audit_lean.py` even if Lean exits unsuccessfully.
The audit reports received and missing declarations, disallowed axioms,
warnings and errors; a nonzero compiler status always prevents progress to
downstream modules. It does not label unprinted reports as clean. Synthetic
fixtures exercise the audit parser. The original Python model is unchanged.

References for the structural recursion design (not a compiler execution):
https://lean-lang.org/doc/reference/latest/Definitions/Recursive-Definitions/

## Status

Authoring container: Lean unavailable; external GitHub download fails DNS.
No claim that the new equations, tactics or proofs compile. The independent
finite Python checks and manifest verification are separately executable.
Do not promote `REPAIR_CANDIDATE` to `VERIFIED` until a complete local
Lean 4.36.0 run passes with all expected reports, no warnings and no forbidden
axioms. If there is another elaboration failure, keep this revision intact and
return its first root diagnostic along with the axiom summary.
