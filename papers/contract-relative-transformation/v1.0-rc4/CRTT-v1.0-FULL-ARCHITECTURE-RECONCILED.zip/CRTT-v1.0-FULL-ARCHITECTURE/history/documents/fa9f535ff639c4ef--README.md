# CRTT-T20-v0.1 — Investigation Transfer

Status: **VERIFIED on Lean 4.36.0** (`run_verify.sh` exits 0: manifest OK, both modules compile with exit 0 and zero diagnostics, 22 + 22 axiom reports audited, `propext`/`Quot.sound` only, no `sorryAx`, no warnings, finite cross-check PASS). Toolchain `Lean (version 4.36.0, arm64-apple-darwin24.6.0, commit 611c117)`.
This package is independent of any LLM architecture. It imports the actual T19
`Problem`, `Investigation`, `Legal`, `runCost`, `solve`, and proof declarations;
it does not replace them with an analogous model. `AdaptiveObservation.lean`
is byte-for-byte from `CRTT-T03-T19-v0.1.2-verified.zip`, SHA-256
`4935dc618d899f294ad60fd6f9599b1e760022cf61a6fc5d0051089db7f8c133`.
The supplied upstream archive's six manifest entries were independently checked.
Its README reports a successful Lean audit, and that audit was independently
rerun on Lean 4.36.0 before this package was verified; the nested module hash
matches the verified artifact.

## Domain and contract

T19 describes a finite declared list of possible worlds, a list of available
binary deterministic noiseless ports, a nonempty list of actions, fixed natural
observation prices, natural terminal losses, and a natural depth bound. A legal
tree uses declared ports and actions, never repeats a port along a branch, and
respects the bound even on unrealizable branches. Its worst-case cost is the
maximum of the sum of observation costs and terminal loss over the declared
worlds (zero on an empty world list). The upstream solver achieves the minimum
over this class. No oracle for the actual world is passed to syntax translation.

A morphism S -> T consists of h: Wt -> Ws, p: Qs -> Qt, a: As -> At,
with the following proof obligations:

- h maps declared target worlds into declared source worlds.
- p maps declared source ports into declared target ports and is injective
  on the declared source ports (not necessarily the entire type).
- a maps declared source actions into declared target actions.
- For declared q,w, read_T(p(q),w) = read_S(q,h(w)).
- For declared q, price_T(p(q)) <= price_S(q).
- For declared u,w, loss_T(a(u),w) <= loss_S(u,h(w)).
- The declared target depth is at least the source depth.

The maps are total typed functions. The laws are deliberately sufficient for
translation of every legal source tree. They need not be necessary for translation
of one selected tree. Neither h nor a needs to be injective or surjective.
Extra target ports/actions are allowed. Empty world lists and duplicates have the
same semantics as in T19. If terminal loss means regret rather than raw cost,
its inequality must be established against the respective task's regret functions.
No inference from one notion of loss to the other is implicit.

## Proof map

| Gate | Declarations |
|---|---|
| T20.1 Typed maps | `TaskSpec`, `TransferMorphism`, `mapTree` |
| T20.2 Trace and leaf commutation | `transfer_semantics` |
| T20.3 Legality and no-repeat rule | `mem_without_iff`, `declared_of_legal`, `transfer_legal_aux`, `transfer_legal` |
| T20.4 Pointwise and worst-case cost | `transfer_runCost_le`, `transfer_worst_le`, `optimum_le` |
| T20.5 Separate hard budgets | `transfer_hard_contract` |
| T20.6 Mutual simulation and optimality | `mutual_optimum_eq`, `transferred_optimizer` |
| T20.7 Identity, composition | `identity`, `compose`, `transfer_identity`, `transfer_compose` |
| T20.8 Counterexamples | `Witnesses.equal_optimum_bad_translation`, `equal_optimum_no_global_morphism`, `equal_optimum_no_loss_morphism`, `flipped_tree_cost` |
| T20.9 Fixed paid transfer | `paid_transfer_iff`, `paid_transfer_sufficient` |

The key induction invariant in legality is inclusion of the mapped remaining
source ports in the remaining target ports. Injectivity on the original declared
source list ensures removing the observed port does not also remove the image
of another remaining port. All actions in the source tree map to declared target
actions. `transfer_semantics` proves equality of realized port/outcome traces and
mapped leaves, and separately bounds observation expenditure and terminal loss.
Membership of h(w) is used when passing from pointwise to worst-case inequality.

Let V(S) be the T19 optimum. A morphism M:S->T gives V(T)<=V(S). A reverse
morphism N:T->S gives equality, and the translated source optimizer attains the
target optimum. The reverse morphism is not required to be an inverse. Identity
and composition hold at the level of translated trees as well as the maps.
These are sufficient simulation laws, not a characterization of all possible
transfers or a claim that equality of optima implies simulation.

## Counterexamples

1. Two bit tasks, unit observation price and error penalty four. The target
   complements its observed bit. Both optima are one; the identity syntax
   translation of the explicit optimal source tree costs five in the target.
   A certified alternative map complements both the world and terminal action;
   the same tree translated by that map costs one.
2. A redundant second source port leaves the optimum unchanged but prevents a
   globally injective port map into a single-port target. A particular source
   tree can still transfer; this is a limitation of the whole-vocabulary notion.
3. Even with equal port cardinality, source optimum one (zero terminal loss
   after observing) and target optimum one (constant terminal loss one) admit
   no morphism from source to target: at every mapped world some source action
   has loss zero while every target action has loss one. Thus the required
   separate terminal-loss bound cannot hold. Equal total costs can conceal
   different resource/quality profiles.

## Cost and limitations

A certified map is a supplied witness, not an algorithm that discovers maps.
Translation preserves a separate observation budget and terminal-loss tolerance;
this guarantee does not include the cost of discovering, checking, storing,
loading, or running the map and tree on a real implementation. T20.9 compares
an explicit fixed overhead plus actual worst-case execution cost against a
specified baseline in the same units. The bound using source cost is sufficient,
not necessary. If the comparator is fresh synthesis, it must include the cost
of that synthesis and validation. Strict advantage over the target *execution
optimum* is impossible for a legal tree plus nonnegative overhead. Savings come
from avoiding discovery costs, not from beating an already-optimal execution.
Multi-task accumulation and finding the morphisms remain open.

## Verification

On Lean 4.36.0:

```bash
set -o pipefail
bash run_verify.sh 2>&1 | tee KERNEL_CHECK.log
```

For scripts that use a pipeline, enable `set -o pipefail` first to preserve the
failure exit status. The supplied `run_verify.sh` itself has `set -euo pipefail`.
It checks SHA-256, compiles the original T19 to an `.olean` in a temporary
location, compiles T20 with that import, audits every explicit `#print axioms`
report (only `propext` and `Quot.sound` are permitted), rejects warnings and proof
placeholders, and runs the Python cross-check. It stops on any failure. No claim
of kernel acceptance is made until this script actually passes in Lean.

Python-only: `python3 check_transfer.py`. The included `FINITE_CHECK.log` is the
actual result in the authoring container. Exhaustive checks on 128 one-port
models cover all 262,144 pairs/maps, with 18,864 valid candidates. The separate
seeded two-port check covers 256 chains and all 74 legal source trees of each.
The code checks realized traces, mapped leaves, separate costs, global maxima,
mutual optimality, composition, hard budgets, and edge cases. These finite checks
are not a proof of Lean elaboration or a substitute for kernel verification.
