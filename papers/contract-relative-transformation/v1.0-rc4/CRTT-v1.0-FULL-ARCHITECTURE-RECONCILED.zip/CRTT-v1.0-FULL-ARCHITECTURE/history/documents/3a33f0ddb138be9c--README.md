# CRTT-T22.9-v0.2.1 — completion source candidate

**LEAN KERNEL STATUS: UNTESTED for the new/modified declarations.**

This revision is based on the two identical 518-line Lean source blocks in the
user-supplied pasted text (20261127-181852). The full draft is archived as
`DRAFT_BudgetedDiscovery.lean.txt`. The four imported Lean files are byte-identical
to the supplied verified parent `CRTT-T22.9-v0.1.2-verified.zip`. The five original
budget-core theorem bodies and preceding definitions are also unchanged. The
parent source and its supplied verification log are archived separately, not
represented as a kernel check of this revision.

## Main changes

- Retains all 21 audit requests from the draft and adds 13. Five modules, 166
  expected audit reports in total (22+22+51+37+34). No `sorry` placeholders are
  introduced. A successful kernel run is still required.
- Explicit account specialization, field reduction and Nat arithmetic in
  the new draft proofs (`measure_lt`, `run_measure_le`, etc.).
- `execute` uses the remaining balance as its transition fuel, because each fee
  is at least one. `execute_eq_saturate` connects it to the specification measure;
  `execute_topUp_add` states the split-budget identity at fixed tariffs.
- `execute_partition` and `execute_certificates_prefix` connect actual runs to
  the one-step invariant and monotone certificate list.
- `run_exhausts_with_budget`, `execute_exhausted_with_budget`, `execute_full`,
  `start_full`: sufficient funds imply exhaustion and exact equality of the
  canonical result list to `discoverAll` (not enumeration of every world map).
  A sufficient, not necessary bound is max(port fee, action fee) * measure.
- `CertifiedAccount`, `start`, `resume`, `classifyAccount` retain the full
  account and partition proof, including in an inconclusive result.

## Gate ledger (new claims are proof-source candidates)

| Gate | Declaration(s) |
|---|---|
| a | typed Morphism certificates, unchanged |
| b | accounting, spent_monotone, budget_bound (verified parent) |
| c | quote_certificates_prefix, execute_certificates_prefix |
| d | run_add, saturate_topUp_add, execute_topUp_add |
| e | measure_lt, execute_partition, initial_pending_eq_discoverAll, start_full |
| f | exhausted_empty_impossible, classify |
| g | classifyAccount and full resumable account; incomplete is not impossible |
| h | early_optimal (verified parent, conditional on supplied partition and lower bound) |

## Boundaries and costs

Tariffs meter abstract paid transitions, not elapsed time, allocation or RAM.
Raw port enumeration at `initial` remains upfront and unmetered. The action
list is built in a paid accepted-port transition. `measure` itself enumerates
that action list to obtain its length; it is kept for specification and proof,
not invoked by `execute`/`resume`. Computing the bound explicitly is not free.
Proof erasure is relied upon for the execution interface; no compiled runtime
measurement or binary inspection has been performed here.

The split theorem assumes a deterministic quote function and unchanged tariffs.
It is not a claim about changes in prices or goal between resumptions.
`early_optimal` does not synthesize a lower bound or implement operational early
stopping. Its optimum is relative to the canonical representative list; all
morphism coverage needs score invariance under witness replacement (or a
separate cost coverage proof). No arbitrary-route or wall-clock bound is claimed.
Trace/sum-of-fees as a separate formal object remains outside this revision.

The Python checks are independent finite models and regression witnesses, not
execution of the Lean module or evidence of its compilation. The new model
checks partition, positive-fee execution, exact split, sufficiently funded
exhaustion, monotone certificates, negative/inconclusive verdicts and supplied
lower-bound early optimality. It also checks unpaid thunk witnesses.

## Verification (Lean 4.36.0)

    set -o pipefail
    bash run_verify.sh 2>&1 | tee ../KERNEL_RERUN-v0.2.1.log

Keep new logs outside the immutable package. The parent log and draft snapshot
are part of the manifest. The strict runner is derived from the verified parent;
it retains the same auditor and fixtures and checks all requested theorem
reports even if a module compilation fails. It stops before downstream builds
on any failed module or audit.

The author environment lacks Lean; do not change the status to VERIFIED until
all actual compiler obligations and diagnostics pass.
