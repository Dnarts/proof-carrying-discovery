# CRTT-T22-v0.1 — Constructive Morphism Discovery

Status: **VERIFIED on Lean 4.36.0**, including the new module. `run_verify.sh`
exits 0 on a fresh extraction of this archive: all four modules compile with
zero diagnostics, 22 + 22 + 51 + 37 = 132 axiom reports are audited by name,
only `propext` and `Quot.sound` appear, and there is no `sorryAx`, no
`Classical.choice`, no warning and no error. Toolchain
`Lean (version 4.36.0, arm64-apple-darwin24.6.0, commit 611c117)`.

The full local log is `KERNEL_CHECK.log` in this archive. `UPSTREAM_T21_KERNEL.log`
is the preserved upstream T21 log and covers only the three inherited modules;
`KERNEL_CHECK.log` is the run that covers `MorphismDiscovery.lean` as well.

The existing three Lean modules are exact copies from
`CRTT-T21-v0.1.2-verified.zip`; their checksums are in `UPSTREAM_SHA256.txt` and
re-verified by the script on every run.

One defect was repaired to reach this status: the base case of `maps_complete`
used `simpa only [he]` on `List.Mem.head`, which states membership of the binder
form `fun i => f i` and does not unify with the bare `f` in the goal. The six
downstream completeness theorems inherited `sorryAx` from that single failure
(`maps_complete`, `morphism_portCandidate`, `discover_complete`,
`empty_iff_no_morphism`, `discover_same_execution`, `direct_offer_complete`).
Rewriting the goal by the extensional equality and then applying
`List.Mem.head` closes it, and all six are now `propext, Quot.sound`.

## Scope

T22 discovers T20 `TransferMorphism` certificates for deterministic binary,
finite, fully indexed problems, with Nat observation prices and terminal losses.
Worlds and ports are `Fin w`, `Fin q`; both can be empty. The action carrier is
`Fin (a+1)`, because T19 requires a default action. All worlds, ports and actions
are declared. This restriction is essential: arbitrary list subdomains of a
larger type may require total extensions outside the declared lists.

`MorphismDiscovery.lean` imports the unchanged T21 library, and its certificate
is the actual T20 type. No new axiom or `sorry` is intentionally introduced.
Only successful Lean compilation and audited dependencies can establish that
these source proofs are accepted. No classical choice is intended in T22.

## Algorithm

1. Check source depth <= target depth. Enumerate all total port maps p.
2. Reject p if its images are not injective, or any price increases. Before
   enumerating action maps, reject p if any target world lacks a read-compatible
   source world (readCover). This is a scoped rejection of p, not of all maps.
3. For each surviving p and total action map a, look for a source witness for
   each target world x. First filter to B_p(x), then find the first world y in
   that row satisfying every terminal loss inequality. The witness is local;
   h is never enumerated globally. The reference Lean code may recompute rows
   and checks; it is not an optimized memoized implementation.
4. If all rows have a witness, construct a total worldMap using proof-directed
   extraction from Option. `Fin 0` requires no artificial default world and the
   condition over an empty target is vacuous. Construct the actual T20
   certificate, including all required membership, price, injectivity,
   observation, loss and depth proofs.
5. Return the exhaustive list of certified morphisms with a representative for
   every valid (p,a) pair. No decision about a time-limited prefix can use the
   global impossibility theorem. Search time, verification and ranking are not
   free in the T21 economics.

For finite counts ns, nt, ps, pt, as, at, brute-force triples number at most
pt^ps * at^as * ns^nt (0^0=1). The local method eliminates enumeration of the
last factor: each pair (p,a) requires at most ns*nt world compatibility checks,
with each check itself inspecting ports/actions. This is not a polynomial-time
claim for the full search. A local witness may be recomputed at execution of the
certificate's worldMap, but T20's mapTree/transfer does not consult worldMap.

## Theorem registry

| Gate | Principal Lean declarations |
| --- | --- |
| T22.1 | `mem_indices`, `maps_complete`, `portOK_iff`, `readOK_iff`, `lossOK_iff` |
| T22.2 | `portWorlds_iff`, `worldWitness_sound`, `worldWitness_complete`, `local_world_iff` |
| T22.3 | `synthWorldMap`, `synthWorldMap_spec` |
| T22.4 | `buildMorphism`, `fixed_pair_iff`, `certifyPair_of_checks` |
| T22.5 | `morphism_portCandidate`, `discover_complete`, `empty_iff_no_morphism` |
| T22.6 (scoped) | `depth_barrier`, `port_map_rejected`, `empty_read_row_barrier`, `empty_joint_row_barrier` |
| T22.7 | `transfer_eq_of_maps`, `discover_same_execution` |
| T22.8 (direct offers only) | `IndexedEntry`, `directOffer`, `directOffers`, `direct_offer_complete` |
| T22.9 | OPEN: budgeted search, interruptible enumeration, sound distinction between incomplete search and impossibility |

All returned elements have type `TransferMorphism S.spec T.spec`. The theorem
`discover_complete` is completeness modulo equality of the port/action maps,
NOT equality of all worldMap witnesses. `empty_iff_no_morphism` applies only to
the exhaustive enumeration on the specified full indexed problem.

The local obstruction theorems are proofs for a rejected p or (p,a), or a
failed depth test. The package does not yet implement a minimal unsatisfiable
core, Hall-style port matching certificate, or a diagnostic ADT enumerating
all rejection reasons. A local read obstruction cannot exclude alternative p.

The direct-offer bridge to T21 is conditional: it preserves the total price
for each direct morphism when the quoted EdgeExpense depends only on (p,a).
A fee or issued-offer rule depending on h can distinguish these witnesses.
The bridge does not enumerate arbitrary multihop paths, discover the registry
of authorized offers, or justify uncharged search. T22.8 in the full T21
setting is still open; the stated direct-offer completeness is a narrower result.

## Validation

`check_transfer_discovery.py` independently compares the set of executable
map pairs from local witness construction with brute enumeration of all total
h,p,a on 65,536 exhaustive one-port task pairs and 2,304 seeded/asymmetric
cases (including empty carriers). It also checks realized per-world tree
costs and equality of the direct-fee score image on legal trees. See
`FINITE_CHECK.log` for actual counts. This script does not interpret Lean code,
so it does not establish compilation or formal theorem validity.

`run_verify.sh` checks manifests and upstream hashes; runs 10 auditor fixtures;
then compiles all four modules in dependency order, storing temporary oleans.
It audits the precise names of 22 + 22 + 51 + 37 = 132 declared axiom reports,
allows only standard propext and Quot.sound, checks compiler exit codes, and
rejects warnings, missing reports, `sorryAx`, Classical.choice and unknown
axioms. It also runs the independent Python checks if compilation succeeds.
The existing auditor is copied unchanged from T21. Source integrity does not
constitute a compiler result.

Target version: Lean 4.36.0. Run locally to reproduce the recorded result:

```bash
unzip CRTT-T22-v0.1.1-verified.zip
cd CRTT-T22-v0.1
set -o pipefail
bash run_verify.sh 2>&1 | tee KERNEL_CHECK.log
```

The promotion condition stated by the previous revision — a successful local run
with no warnings and no unauthorized axiom reports — has been met, and
`KERNEL_CHECK.log` records that run. A recorded PASS is still not a substitute
for kernel acceptance on the consumer's own machine: rerun the script and read
the `#print axioms` output yourself.
