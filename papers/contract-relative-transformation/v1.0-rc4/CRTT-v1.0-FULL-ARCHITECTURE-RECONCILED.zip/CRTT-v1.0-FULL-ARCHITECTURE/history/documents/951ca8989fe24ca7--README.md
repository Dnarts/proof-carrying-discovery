# CRTT-T17 v0.1 — online discovery, source draft

Independent extension of CRTT v0.2. The earlier package is unchanged.
Target: Lean 4.36.0; `Std` and `Lean` only. No neural networks or Mathlib.

## T17a — hidden future method

Assume an empty library, at least two methods, common costs D > R >= 0,
one method used per task, T >= 2, and no speculative purchases. The first
task accepts every method; every later task accepts the same hidden method.
The hidden continuation is not observable on the first task.
A clairvoyant optimum pays D+(T-1)R. Any deterministic first choice has a
continuation with cost 2D+(T-2)R and regret D-R. The worst ratio for T=2 is
2D/(D+R). For uniform hidden method among m alternatives, independent of the
strategy's randomness, expected regret is (1-1/m)(D-R). The uniform first
choice minimizes the worst expected regret against an oblivious adversary.
The Lean source proves the deterministic cost statements; the randomized
statement remains an analytical extension, not a Lean theorem in this module.

## T17b — homogeneous rent-or-discover stream

Assume 0 <= R < L < D, identical task applicability, unknown horizon, no
mandatory overhead or eviction. First use of a transferable method costs D;
subsequent uses cost R; local solutions cost L. Set r=L-R and B=D-R.
The offline optimum is TR+min(Tr,B). Buy on the kth arriving task, after k-1
local tasks, if the kth task exists. Cost is TL before k, and TR+B+(k-1)r
from k onward. Every deterministic policy in this information model can be
represented by a fixed threshold or by never buying, as no task feedback
provides any information about the remaining horizon.

The break-even threshold k0=ceil(B/r)=floor((B-1)/r)+1 for positive integer
B,r is 2-competitive. For T<k0, renting is offline optimal. For T>=k0,
the excess is exactly (k0-1)r<B<=offline cost. This establishes the bound
without division by zero, including T=0. Buying happens on task k0, not
after k0 completed local tasks.

## T17c — exact discrete minimax threshold (analytical)

For k>=1, the worst competitive ratio occurs at T=k. Before k, the ratio
max(1,TL/(TR+B)) is nondecreasing, and at k purchasing costs strictly more
than renting on that task. For T>=k the ratio is the maximum of
(TR+B+(k-1)r)/(TL) and (TR+B+(k-1)r)/(TR+B), both nonincreasing in T.
Thus Gamma(k)=[kR+B+(k-1)r]/[kR+min(kr,B)].
For kr<=B it equals 1+(B-r)/(kL), decreasing in k. For kr>=B it equals
1+(k-1)r/(kR+B), increasing in k. The optimal integer threshold is therefore
one of floor(B/r), ceil(B/r), compared by exact cross multiplication.
Never buying cannot improve on these finite thresholds: its supremum is
L/R for R>0 or unbounded for R=0.

Counterexample to always selecting the ceiling: D=5,L=4,R=1 gives
Gamma(1)=5/4 and Gamma(2)=3/2. The offline break-even threshold is 2, but
buying on the first task is minimax optimal. Lean contains the finite cost
witnesses, not the universal minimax proof. T17c is checked on bounded grids
by Python exact rational arithmetic; its universal proof remains analytical.

## Verification and scope

The original v0.2 directory passed all six manifest entries in the current
session. Lean is not installed here. No compilation, elaboration, or axiom
inspection was performed. These are source drafts with proposed proofs,
not verified Lean certificates. The Python finite check is not a substitute
for kernel verification.

```sh
lean --version
lean OnlineDiscovery.lean
python3 check_online.py
shasum -a 256 -c SHA256SUMS.txt
```

Inspect compiler diagnostics and `#print axioms` output. Do not weaken
statements to obtain compilation. T17 does not establish a general theorem
about discovery algorithms, non-homogeneous task streams, adaptive search,
or costly libraries. The next research question is what information about
future applicability changes the attainable online regret, under an
explicit acquisition and validation budget.
