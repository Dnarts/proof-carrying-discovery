#!/usr/bin/env python3
"""Read-only preflight of the assembled CRTT archive; writes outside it."""
from pathlib import Path, PurePosixPath
from collections import Counter
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.parse
import zipfile

BASE = Path('/workspace/scratch/3ead007c968d')
ROOT = BASE / 'deliverables/CRTT-v1.0-FULL-ARCHITECTURE'
OUT = BASE / 'work/full_archive_preflight'
OUT.mkdir(exist_ok=True, parents=True)
PENDING = {'START_HERE.html', 'MANIFEST.json', 'SHA256SUMS.txt'}
REPORT = {'schema': 'crtt-full-archive-preflight-v1',
    'started_utc': datetime.now(timezone.utc).isoformat(), 'archive_root': str(ROOT),
    'scope': 'Read-only preflight before final top-level manifests and ZIP. No Lean invocation.',
    'findings': [], 'source_checks': [], 'links': [], 'catalog_paths': [], 'verifier_cases': []}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(Path(path).read_bytes())


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def inventory(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}


def problem(kind, **details):
    REPORT['findings'].append({'kind': kind, **details})


def check_bytes(group, path, expected_bytes, origin):
    actual = path.read_bytes() if path.is_file() else None
    row = {'group': group, 'path': str(path.relative_to(ROOT)), 'origin': origin,
        'expected_sha256': sha(expected_bytes), 'actual_sha256': sha(actual) if actual is not None else None,
        'bytes': len(expected_bytes), 'matches': actual == expected_bytes}
    REPORT['source_checks'].append(row)
    if not row['matches']:
        problem('source_byte_mismatch', **row)


def compare_tree(group, target, source):
    src = inventory(source)
    dest = inventory(target)
    if set(src) != set(dest):
        problem('source_inventory_mismatch', group=group,
            missing=sorted(set(src)-set(dest)), extra=sorted(set(dest)-set(src)))
    for rel in src:
        check_bytes(group, target/rel, (source/rel).read_bytes(), str(source/rel))


def compare_zip_tree(group, target, archive):
    with zipfile.ZipFile(archive) as z:
        names = [i.filename for i in z.infolist() if not i.is_dir()]
        actual = set(inventory(target))
        if set(names) != actual:
            problem('zip_tree_inventory_mismatch', group=group,
                    missing=sorted(set(names)-actual), extra=sorted(actual-set(names)))
        for name in names:
            check_bytes(group, target/name, z.read(name), str(archive)+'!'+name)


def source_preservation():
    compare_tree('canonical', ROOT/'canonical', BASE/'work/snapshots/a3bc17f64f96b996/CRTT-T32-v1.0-rc1')
    compare_tree('freeze', ROOT/'evidence/freeze', BASE/'work/frozen/CRTT-v1.0-FROZEN')
    compare_tree('recheck', ROOT/'evidence/recheck', BASE/'work/independent_review')
    compare_zip_tree('history/T01-T18', ROOT/'history/T01-T18', ROOT/'canonical/HISTORY_T01_T18.zip')
    compare_zip_tree('history/T03-T19', ROOT/'history/T03-T19', ROOT/'canonical/HISTORY_T03_T19.zip')
    source_index = json.loads((BASE/'work/snapshot_index.json').read_text())
    by_name = {r['name']: r for r in source_index}
    archives = json.loads((ROOT/'catalog/ARCHIVES.json').read_text())
    REPORT['original_archive_count'] = len(archives)
    REPORT['original_archive_unique_hashes'] = len({r['sha256'] for r in archives})
    for record in archives:
        check_bytes('original_archive', ROOT/record['archive_path'],
                    Path(by_name[record['name']]['input']).read_bytes(), by_name[record['name']]['input'])
        if digest(ROOT/record['archive_path']) != record['sha256']:
            problem('archive_catalog_hash_mismatch', path=record['archive_path'])
    for target in sorted((ROOT/'originals/supplied_logs').iterdir()):
        matches = list((BASE/'inputs').rglob(target.name))
        if len(matches) != 1:
            problem('ambiguous_original_log', path=str(target), sources=list(map(str,matches)))
        else:
            check_bytes('supplied_log', target, matches[0].read_bytes(), str(matches[0]))
    with ExitStack() as stack:
        zips = {r['name']: stack.enter_context(zipfile.ZipFile(ROOT/r['archive_path'])) for r in archives}
        all_occurrences = 0
        docs = json.loads((ROOT/'catalog/HISTORICAL_DOCUMENTS.json').read_text())
        for record in docs:
            data = (ROOT/record['path']).read_bytes()
            if sha(data) != record['sha256']:
                problem('historical_document_catalog_hash_mismatch', path=record['path'])
            for occurrence in record['occurrences']:
                check_bytes('historical_document_occurrence', ROOT/record['path'],
                    zips[occurrence['archive']].read(occurrence['member']),
                    occurrence['archive']+'!'+occurrence['member'])
                all_occurrences += 1
        REPORT['historical_document_count'] = len(docs)
        REPORT['historical_document_origin_occurrences'] = all_occurrences
        for path in sorted((ROOT/'history/referenced-sources').rglob('*')):
            if not path.is_file():
                continue
            prefix, *parts = path.relative_to(ROOT/'history/referenced-sources').parts
            candidates = [a for a in archives if a['sha256'].startswith(prefix)]
            if not candidates:
                problem('unresolved_referenced_source_origin', path=str(path.relative_to(ROOT)))
                continue
            member = '/'.join(parts)
            check_bytes('referenced_source', path, zips[candidates[0]['name']].read(member),
                        candidates[0]['name']+'!'+member)
        recoveries = json.loads((ROOT/'catalog/HISTORICAL_RECOVERY.json').read_text())
        for record in recoveries:
            archive_name = Path(record['source_archive']).name
            check_bytes('historical_recovery', ROOT/record['path'],
                zips[archive_name].read(record['archive_member']), record['source_archive']+'!'+record['archive_member'])
            if digest(ROOT/record['path']) != record['expected_sha256']:
                problem('historical_recovery_pin_mismatch', path=record['path'])
        report_records = json.loads((ROOT/'catalog/ORIGINAL_ARCHIVE_AUDIT.json').read_text())
        archive_entry_checks = []
        for ar in report_records:
            z = zips[ar['name']]
            for m in ar['manifests']:
                manifest_data = z.read(m['path']).decode()
                actual_manifest = {}
                for line in manifest_data.splitlines():
                    if line.strip():
                        h, name = line.split(maxsplit=1)
                        actual_manifest[name] = h
                parent = str(PurePosixPath(m['path']).parent)
                for e in m['entries']:
                    member = parent+'/'+e['path'] if parent != '.' else e['path']
                    actual = sha(z.read(member))
                    okay = actual == e['actual'] == e['expected'] == actual_manifest[e['path']] and e['status']=='MATCH'
                    archive_entry_checks.append({'archive':ar['archive_path'],'manifest':m['path'],
                        'entry':e['path'],'sha256':actual,'matches':okay})
                    if not okay:
                        problem('original_archive_audit_record_mismatch', archive=ar['name'], entry=e)
        REPORT['original_archive_manifest_entry_checks'] = archive_entry_checks


def markdown_destinations(text):
    for m in re.finditer(r'\[[^\]\n]*\]\(', text):
        start = m.end()
        depth = 1
        i = start
        while i < len(text) and depth:
            if text[i] == '\\':
                i += 2
                continue
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
            i += 1
        if depth == 0:
            dest = text[start:i-1].strip()
            if dest.startswith('<') and '>' in dest:
                dest = dest[1:dest.index('>')]
            yield dest, text.count('\n',0,m.start())+1


def anchors(path):
    text = path.read_text()
    out = set(re.findall(r'<a\s+id=[\'\"]([^\'\"]+)', text))
    for line in text.splitlines():
        if re.match(r'^#{1,6}\s+',line):
            label=re.sub(r'^#{1,6}\s+','',line).strip().lower()
            out.add(re.sub(r'[^\w\- ]','',label).replace(' ','-'))
    return out


def links_and_catalogs():
    derived = [*ROOT.glob('*.md'), ROOT/'PROVENANCE.json', *(ROOT/'catalog').glob('*.json')]
    absolute = []
    for path in derived:
        for number,line in enumerate(path.read_text().splitlines(),1):
            if re.search(r'/workspace/|/scratch/|(?:file|sandbox):|(?<!\w)[A-Za-z]:\\\\',line):
                absolute.append({'file':str(path.relative_to(ROOT)),'line':number,'text':line})
    REPORT['absolute_scratch_references_in_derived_documents'] = absolute
    if absolute:
        problem('absolute_paths_in_derived_documents', count=len(absolute))
    for path in ROOT.glob('*.md'):
        for dest,line in markdown_destinations(path.read_text()):
            if re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',dest):
                REPORT['links'].append({'file':path.name,'line':line,'target':dest,'status':'external'})
                continue
            target, sep, anchor = urllib.parse.unquote(dest).partition('#')
            local = path.parent/target if target else path
            status='exists' if local.exists() else 'planned_final_artifact' if target in PENDING else 'missing'
            if anchor and local.is_file() and local.suffix == '.md' and anchor not in anchors(local):
                status='missing_anchor'
            row={'file':path.name,'line':line,'target':dest,'status':status}
            REPORT['links'].append(row)
            if status in {'missing','missing_anchor'}:
                problem('broken_markdown_link',**row)
    def visit(value, location, field=None):
        if isinstance(value,dict):
            for k,v in value.items():visit(v,location+[k],k)
        elif isinstance(value,list):
            for i,v in enumerate(value):visit(v,location+[i],field)
        elif isinstance(value,str) and re.match(r'^(canonical|catalog|diagrams|history|evidence|originals)(/|$)',value):
            if field == 'status_authority':
                return  # This field is prose; concrete witness fields are checked.
            path=re.sub(r':\d+(?:-\d+)?$','',value.split('#',1)[0])
            row={'location':location,'value':value,'exists':(ROOT/path).exists()}
            REPORT['catalog_paths'].append(row)
            if not row['exists']:
                problem('broken_catalog_path',**row)
    for path in [ROOT/'PROVENANCE.json',*(ROOT/'catalog').glob('*.json')]:
        visit(json.loads(path.read_text()),[str(path.relative_to(ROOT))])


def semantic_counts():
    gates=json.loads((ROOT/'catalog/GATES.json').read_text())
    early=json.loads((ROOT/'catalog/EARLY_ARCHITECTURE.json').read_text())
    current=json.loads((ROOT/'catalog/CURRENT_ARCHITECTURE.json').read_text())
    modules=json.loads((ROOT/'catalog/MODULES.json').read_text())
    stages=gates['stages']
    source_stages={s['id']:s for s in early['stages']+current['stages']}
    changed=[]
    for s in stages:
        original=source_stages[s['id']]
        for field in ['status','subgates','definition_sources','evidence_sources']:
            if s.get(field)!=original.get(field):
                changed.append({'id':s['id'],'field':field})
    if changed:
        problem('stage_status_or_evidence_mapping_changed',changes=changed)
    unknown=[s['id'] for s in stages if s['status']=='numbering_unresolved']
    expected_unknown=['T01','T02']+[f'T{i:02}' for i in range(4,14)]
    if unknown!=expected_unknown:
        problem('unresolved_early_numbering_changed',actual=unknown)
    direct=[]
    names={p.stem for p in (ROOT/'canonical').glob('*.lean')}
    expected_audits=0
    for p in sorted((ROOT/'canonical').glob('*.lean')):
        data=p.read_text()
        for line in re.findall(r'^import\s+([^\n]+)',data,re.M):
            for imp in line.split():
                direct.append({'module':p.stem,'imports':imp,'external':imp not in names})
        expected_audits+=len(re.findall(r'^#print axioms\s+\S+',data,re.M))
    key=lambda e:(e['module'],e['imports'],e['external'])
    graph_match=sorted(direct,key=key)==sorted(modules['import_edges'],key=key)==sorted(current['import_edges'],key=key)
    if not graph_match:
        problem('import_graph_mismatch')
    order={name:i for i,name in enumerate(modules['topological_build_order'])}
    order_valid=all(e['external'] or order[e['imports']]<order[e['module']] for e in direct)
    if not order_valid:
        problem('topological_build_order_invalid')
    values={'stages':len(stages),'subgate_records':sum(len(s['subgates']) for s in stages),
        'unknown_early_stage_count':len(unknown),'unknown_early_stages':unknown,
        'stage_statuses':dict(Counter(s['status'] for s in stages)),
        'subgate_statuses':dict(Counter(sg.get('status','unspecified') for s in stages for sg in s['subgates'])),
        'statuses_and_evidence_preserved_from_source_catalogs':not changed,
        'source_import_edges':len(direct),'external_import_edges':sum(e['external'] for e in direct),
        'graph_matches_sources':graph_match,'topological_build_order_valid':order_valid,
        'source_axiom_report_requests':expected_audits,
        'interpretation':'147 is a number of catalogue records, not a count of independently passed tests.'}
    REPORT['semantic_counts']=values
    if (values['stages'],values['subgate_records'],values['unknown_early_stage_count'],len(direct),expected_audits)!=(36,147,12,22,542):
        problem('unexpected_semantic_counts',counts=values)


def build_fixture(root):
    (root/'canonical').mkdir(parents=True)
    (root/'originals/archives').mkdir(parents=True)
    (root/'canonical/Proof.lean').write_bytes(b'-- Synthetic integrity fixture; no Lean execution.\n')
    with zipfile.ZipFile(root/'originals/archives/fixture.zip','w') as z:
        z.write(root/'canonical/Proof.lean','fixture/Proof.lean')
    save(root/'PROVENANCE.json',{'canonical':{
        'archive_path':'originals/archives/fixture.zip', 'member_root':'fixture',
        'sha256':digest(root/'originals/archives/fixture.zip')}})
    refresh_fixture(root)


def refresh_fixture(root):
    files=[p for p in sorted(root.rglob('*')) if p.is_file() and p.name not in {'MANIFEST.json','SHA256SUMS.txt'}]
    save(root/'MANIFEST.json',{'payload_file_count':len(files),'files':[
        {'path':str(p.relative_to(root)),'sha256':digest(p),'size_bytes':p.stat().st_size} for p in files]})
    files=[p for p in sorted(root.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt']
    (root/'SHA256SUMS.txt').write_text(''.join(digest(p)+'  '+str(p.relative_to(root))+'\n' for p in files))


def verifier_logic():
    cases=OUT/'verifier_cases'
    cases.mkdir(exist_ok=True)
    base=cases/'valid'
    if base.exists():
        raise RuntimeError('Fixture tree already exists; do not overwrite an earlier run')
    build_fixture(base)
    casespec=[('valid',0)]
    for name in ['tampered','unlisted','unsafe_zip_member','absolute_provenance_path']:
        shutil.copytree(base,cases/name)
    (cases/'tampered/canonical/Proof.lean').write_text('changed\n')
    (cases/'unlisted/extra.txt').write_text('not in manifest\n')
    with zipfile.ZipFile(cases/'unsafe_zip_member/originals/archives/fixture.zip','a') as z:
        z.writestr('../outside.txt','unsafe member fixture')
    refresh_fixture(cases/'unsafe_zip_member')
    external=cases/'external.zip'
    shutil.copy2(base/'originals/archives/fixture.zip',external)
    absolute=cases/'absolute_provenance_path'
    pv=json.loads((absolute/'PROVENANCE.json').read_text())
    pv['canonical']['archive_path']=str(external)
    save(absolute/'PROVENANCE.json',pv)
    refresh_fixture(absolute)
    casespec += [('tampered',1),('unlisted',1),('unsafe_zip_member',1),('absolute_provenance_path',1)]
    for name,desired in casespec:
        args=[sys.executable,'-B',str(ROOT/'verify_archive.py'),'--root',str(cases/name)]
        result=subprocess.run(args,capture_output=True,timeout=30)
        (cases/(name+'.stdout.log')).write_bytes(result.stdout)
        (cases/(name+'.stderr.log')).write_bytes(result.stderr)
        row={'case':name,'argv':args,'expected_secure_exit':desired,'actual_exit':result.returncode,
            'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr),
            'matches_expected_exit':result.returncode==desired}
        REPORT['verifier_cases'].append(row)
        if not row['matches_expected_exit']:
            problem('verifier_logic_hardening',case=name,expected=desired,actual=result.returncode,
                    detail='Canonical provenance archive_path is not validated for containment. Actual assembled provenance is relative and valid.')
    REPORT['verifier_static_review']={
        'path':'verify_archive.py','sha256':digest(ROOT/'verify_archive.py'),
        'complete_inventory_checked':True,'all_payload_sha_and_sizes_checked':True,
        'manifest_excludes_itself_and_sums_by_inventory':True,'sums_cover_manifest':True,
        'zip_crc_duplicate_names_paths_symlinks_checked':True,
        'canonical_bytes_bound_to_retained_original_zip':True,
        'self_hash_cycle_required':False,
        'note':'Full execution against the real assembly waits for top-level MANIFEST/SHA and final ZIP.'}


def main():
    REPORT['inventory_before']=inventory(ROOT)
    source_preservation()
    links_and_catalogs()
    semantic_counts()
    verifier_logic()
    after=inventory(ROOT)
    before=REPORT['inventory_before']
    REPORT['observed_existing_files_changed_during_preflight']=[p for p,h in before.items() if after.get(p)!=h]
    REPORT['new_files_added_by_parallel_assembly']=sorted(set(after)-set(before))
    REPORT['pending_artifacts_missing']=[p for p in sorted(PENDING) if not (ROOT/p).exists()]
    REPORT['finished_utc']=datetime.now(timezone.utc).isoformat()
    REPORT['summary']={'byte_comparison_records':len(REPORT['source_checks']),
        'unique_source_files_compared':len({r['path'] for r in REPORT['source_checks']}),
        'source_byte_mismatches':sum(not r['matches'] for r in REPORT['source_checks']),
        'markdown_links_checked':len(REPORT['links']),
        'catalog_paths_checked':len(REPORT['catalog_paths']),
        'original_archive_manifest_entries_rechecked':len(REPORT['original_archive_manifest_entry_checks']),
        'finding_count':len(REPORT['findings']),
        'lean_executed':False}
    save(OUT/'preflight_report.json',REPORT)
    print(json.dumps(REPORT['summary'],indent=2))
    print(json.dumps(REPORT['findings'],ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
