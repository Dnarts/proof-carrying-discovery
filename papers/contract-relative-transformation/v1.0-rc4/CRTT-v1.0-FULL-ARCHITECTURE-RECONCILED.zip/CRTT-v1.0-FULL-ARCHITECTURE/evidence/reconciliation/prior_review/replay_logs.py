#!/usr/bin/env python3
"""Review newly supplied log views against current CRTT sources; no Lean run."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,re,subprocess,sys

BASE=Path('/workspace/scratch/3ead007c968d')
ROOT=BASE/'work/user_rebuild_review/input/CRTT-v1.0-FULL-ARCHITECTURE'
SRC=ROOT/'canonical'
LOG=ROOT/'evidence/local_verification'
OUT=BASE/'work/user_rebuild_review/independent_logs'
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'commands').mkdir(exist_ok=True)
ERRORS=[]
REPORT={'schema':'crtt-new-log-review-v1','started_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'New log views, current source audit targets and supplied CLI/reference replay only.',
        'input_root':str(ROOT),'lean_executed_locally':False,'errors':ERRORS}


def sha(data):return hashlib.sha256(data).hexdigest()
def digest(p):return sha(p.read_bytes())
def need(condition,message):
    if not condition:ERRORS.append(message)
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def snapshot():
    return {str(p.relative_to(ROOT)):digest(p) for p in [*SRC.glob('*.lean'),*SRC.glob('*.py'),SRC/'run_verify.sh',SRC/'SHA256SUMS.txt',ROOT/'evidence/freeze/T32-KERNEL_CHECK.log',*LOG.rglob('*.log')]}


def command(job):
    label,args=job
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env.pop('PYTHONOPTIMIZE',None);env.pop('PYTHONPATH',None)
    started=datetime.now(timezone.utc).isoformat()
    result=subprocess.run(args,cwd=SRC,env=env,capture_output=True,timeout=60)
    stdout=OUT/'commands'/f'{label}.stdout.log';stderr=OUT/'commands'/f'{label}.stderr.log'
    stdout.write_bytes(result.stdout);stderr.write_bytes(result.stderr)
    row={'id':label,'argv':args,'cwd':str(SRC),'started_utc':started,
        'finished_utc':datetime.now(timezone.utc).isoformat(),'exit_code':result.returncode,
        'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr),
        'stdout':str(stdout),'stderr':str(stderr),'mode':'local Python replay of supplied outputs, not new Lean execution'}
    save(OUT/'commands'/f'{label}.json',row)
    return row


def main():
    before=snapshot()
    runner=(LOG/'RUNNER_FULL.log').read_bytes()
    aggregate=(LOG/'ALL_LEAN_LOGS.log').read_bytes()
    frozen=(ROOT/'evidence/freeze/T32-KERNEL_CHECK.log').read_bytes()
    REPORT['input_digests']={str(p.relative_to(ROOT)):{'sha256':digest(p),'bytes':p.stat().st_size}
        for p in [LOG/'ALL_LEAN_LOGS.log',LOG/'RUNNER_FULL.log',ROOT/'evidence/freeze/T32-KERNEL_CHECK.log']}
    REPORT['runner_is_byte_identical_to_frozen_witness']=runner==frozen
    source_manifest=dict((name,h) for h,name in (line.split(maxsplit=1) for line in (SRC/'SHA256SUMS.txt').read_text().splitlines()))
    runner_source=(SRC/'run_verify.sh').read_text()
    expected_order=re.search(r'^for src in (.+); do$',runner_source,re.M).group(1).split()
    lines=runner.splitlines(keepends=True);offsets=[0]
    for line in lines:offsets.append(offsets[-1]+len(line))
    positions=[(i,re.fullmatch(rb'=== LEAN: (\S+\.lean) ===\r?\n?',line).group(1).decode())
        for i,line in enumerate(lines) if re.fullmatch(rb'=== LEAN: (\S+\.lean) ===\r?\n?',line)]
    need([n for i,n in positions]==expected_order,'Runner source order differs from current run_verify.sh')
    need({p.stem+'.lean' for p in (LOG/'per_module').glob('*.log')}==set(expected_order),'Per-module log file set differs from current source set')
    am=list(re.finditer(rb'(?m)^={80}\r?\n=== MODULE: (\S+\.lean) ===\r?\n={80}\r?\n',aggregate))
    need([m.group(1).decode() for m in am]==expected_order,'Aggregate module order differs from current runner')
    aggregate_sections={m.group(1).decode():aggregate[m.end():am[i+1].start() if i+1<len(am) else len(aggregate)] for i,m in enumerate(am)}
    rows=[];jobs=[];expected_all=Counter();actual_all=Counter()
    axiom_counts=Counter()
    report_pattern=re.compile(r"^'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)[ \t]*$",re.M)
    for index,name in positions:
        source=SRC/name;path=LOG/'per_module'/(source.stem+'.log');data=path.read_bytes()
        footer=next(j for j in range(index+1,len(lines)) if lines[j].startswith(('AUDIT '+name+':').encode()))
        match=re.fullmatch(rb'AUDIT (\S+): (\d+)/(\d+) axiom reports; Lean exit=(-?\d+); dependencies=(.*)\r?\n?',lines[footer])
        if not match:raise ValueError('Cannot parse runner audit footer '+name)
        supplied_exit=int(match.group(4));raw=b''.join(lines[index+1:footer])
        requested=re.findall(r'^#print axioms\s+(\S+)',source.read_text(),re.M)
        expected=Counter('CRTT.'+source.stem+'.'+n for n in requested)
        reports=report_pattern.findall(data.decode());actual=Counter(n for n,deps in reports)
        for n,deps in reports:
            for a in {a.strip() for a in deps.split(',') if a.strip()}:axiom_counts[a]+=1
        expected_all.update(expected);actual_all.update(actual)
        aggregate_body=aggregate_sections.get(name,b'')
        aggregate_match=aggregate_body.startswith(data) and not aggregate_body[len(data):].strip(b'\r\n')
        record={'source':str(source.relative_to(ROOT)),'source_sha256':digest(source),
            'source_matches_current_manifest':digest(source)==source_manifest[name],
            'per_module_log':str(path.relative_to(ROOT)),'log_sha256':sha(data),'log_bytes':len(data),
            'requested_reports':len(requested),'actual_reports':len(reports),
            'exact_qualified_names_match':expected==actual,'duplicate_report_names':[n for n,c in actual.items() if c>1],
            'per_module_bytes_equal_runner_raw_segment':data==raw,
            'runner_segment_byte_start':offsets[index+1],'runner_segment_byte_end':offsets[footer],
            'runner_footer_lean_exit':supplied_exit,
            'exit_provenance':'Value read from supplied RUNNER_FULL footer; not an independently observed compiler exit.',
            'aggregate_body_equals_log_plus_only_blank_separators':aggregate_match,
            'aggregate_extra_separator_bytes':len(aggregate_body)-len(data)}
        rows.append(record)
        need(record['source_matches_current_manifest'],'Current source pin mismatch '+name)
        need(expected==actual,'Exact audit-name mismatch '+name)
        need(data==raw,'Per-module and runner raw segment mismatch '+name)
        need(aggregate_match,'Aggregate body differs from per-module log '+name)
        need(supplied_exit==0,'Supplied compiler status is nonzero '+name)
        jobs += [(source.stem+'_audit',[sys.executable,'-B',str(SRC/'audit_lean.py'),str(source),str(path),str(supplied_exit)]),
                 (source.stem+'_names',[sys.executable,'-B',str(SRC/'audit_names.py'),str(source),str(path)])]
    aggregate_reports=Counter(n for n,deps in report_pattern.findall(aggregate.decode()))
    need(expected_all==actual_all==aggregate_reports,'Global 542-name multiset mismatch')
    need(sum(expected_all.values())==542,'Current source audit request count differs from 542')
    need(set(axiom_counts)<={'propext','Quot.sound'},'Unexpected axiom dependencies')
    ci=next(i for i,line in enumerate(lines) if line.strip()==b'=== T32 CLI: ACTUAL LEAN EXECUTION ===')
    ce=next(i for i in range(ci+1,len(lines)) if lines[i].startswith(b'AUDIT ReleaseMain.lean:'))
    cli=b''.join(lines[ci+1:ce]);cli_status=int(re.search(rb'Lean exit=(-?\d+)',lines[ce]).group(1))
    cli_path=OUT/'runner_cli.raw.log';cli_path.write_bytes(cli)
    REPORT['cli_segment']={'sha256':sha(cli),'bytes':len(cli),'byte_start':offsets[ci+1],'byte_end':offsets[ce],
        'supplied_lean_exit':cli_status,'source_journal_sha256':sha(runner)}
    jobs += [('cli_audit',[sys.executable,'-B',str(SRC/'audit_lean.py'),str(SRC/'ReleaseMain.lean'),str(cli_path),str(cli_status)]),
             ('cli_names',[sys.executable,'-B',str(SRC/'audit_names.py'),str(SRC/'ReleaseMain.lean'),str(cli_path)]),
             ('cli_reference',[sys.executable,'-B',str(SRC/'check_release.py'),'--lean-log',str(cli_path)])]
    with ThreadPoolExecutor(max_workers=3) as pool:
        commands=list(pool.map(command,jobs))
    need(all(c['exit_code']==0 for c in commands),'A strict replay or reference comparison failed')
    REPORT['per_module']=rows;REPORT['commands']=commands
    REPORT['diagnostics']={kind:{pattern:len(re.findall(pattern,data.decode(),re.I))
        for pattern in [r'\bwarning:',r'\berror:',r'\bsorryAx\b',r'\bClassical\.choice\b']}
        for kind,data in [('aggregate',aggregate),('runner',runner)]}
    need(all(v==0 for row in REPORT['diagnostics'].values() for v in row.values()),'Forbidden diagnostic pattern in supplied log')
    header=aggregate[:am[0].start()].decode() if am else aggregate.decode()
    REPORT['provenance']={'aggregate_header':header,
        'module_logs_have_separate_exit_records':False,
        'module_logs_are_exact_runner_segments':all(r['per_module_bytes_equal_runner_raw_segment'] for r in rows),
        'aggregate_date_is_textual_metadata':True,
        'separate_outer_runner_process_exit_receipt_present_in_new_log_directory':False,
        'new_log_directory_files':sorted(str(p.relative_to(LOG)) for p in LOG.rglob('*') if p.is_file()),
        'runner_has_final_success_marker':b'PASS: T32 complete manifest, Lean compilation, 542 audited reports, finite checks and actual CLI/reference agreement.' in runner,
        'archive_metadata_fresh_lean_execution':json.loads((ROOT/'PROVENANCE.json').read_text())['fresh_lean_execution'],
        'freshness_conclusion':'The supplied output is consistent with successful current-source verification. Byte equality with a prior deterministic output neither proves nor disproves a later run. No separate new process receipt is included; the new timestamp is a header assertion. Fresh independent execution is not established by this replay.',
        'historical_exit_127':'The previously observed exit 127 belongs to that earlier local environment; it does not rule out a later run elsewhere and is not erased by adding a new timestamp.'}
    REPORT['scope_inputs_unchanged']=snapshot()==before
    need(REPORT['scope_inputs_unchanged'],'Input files changed during log review')
    REPORT['summary']={'content_replay_status':'PASS' if not ERRORS else 'FAIL','module_logs':len(rows),
        'current_source_pins_matched':sum(r['source_matches_current_manifest'] for r in rows),
        'exact_audit_reports':sum(actual_all.values()),'audit_requests':sum(expected_all.values()),
        'per_module_strict_parser_calls':42,'cli_strict_parser_calls':2,'cli_reference_cases':9,
        'total_python_commands':len(commands),'all_python_commands_exit_zero':all(c['exit_code']==0 for c in commands),
        'axiom_dependency_occurrences':dict(axiom_counts),'new_independent_lean_execution_established':False,
        'replay_is_not_fresh_compilation':True}
    REPORT['finished_utc']=datetime.now(timezone.utc).isoformat()
    save(OUT/'log_review.json',REPORT)
    print(json.dumps(REPORT['summary'],indent=2))
    print(json.dumps(ERRORS,ensure_ascii=False))
    raise SystemExit(0 if not ERRORS else 1)


if __name__=='__main__':main()
