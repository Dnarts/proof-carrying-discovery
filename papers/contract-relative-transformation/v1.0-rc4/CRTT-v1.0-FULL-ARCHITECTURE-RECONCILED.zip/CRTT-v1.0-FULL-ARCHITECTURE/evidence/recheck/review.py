#!/usr/bin/env python3
"""Independent read-only source checks and explicit supplied-log replay.

The package is never changed. Python fixtures run afresh in the working copy.
Lean is neither installed nor invoked. Lean status values passed to auditors
are extracted from the supplied journal and are not locally observed exits.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from collections import Counter
import hashlib
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import sys
import time
import zipfile

BASE = Path('/workspace/scratch/3ead007c968d')
ORIGINAL = BASE / 'work/snapshots/a3bc17f64f96b996/CRTT-T32-v1.0-rc1'
WORK = BASE / 'work/replay-review'
OUT = BASE / 'work/independent_review'
FROZEN = BASE / 'work/frozen/CRTT-v1.0-FROZEN'
SOURCE_ZIP = BASE / 'inputs/latest/CRTT-T32-v1.0-rc1-verified (1).zip'
EXPECTED_ZIP = 'a3bc17f64f96b9966b1226ffb5f9fad055c763796960deb858da7a2f3b78f4bc'
INDEX = BASE / 'work/snapshot_index.json'
SUPPLIED = OUT / 'supplied'
LOGS = OUT / 'commands'
SEGMENTS = OUT / 'segments'
TMP = OUT / 'tmp'
for directory in (LOGS, SEGMENTS, TMP):
    directory.mkdir(exist_ok=True)


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def inventory(root):
    return {str(p.relative_to(root)): {'bytes': p.stat().st_size, 'sha256': digest(p)}
            for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()}


def parse_manifest(path):
    entries = {}
    for number, line in enumerate(Path(path).read_text().splitlines(), 1):
        match = re.fullmatch(r'([0-9a-f]{64})[ \t]+(.+)', line)
        if not match:
            raise ValueError(f'Invalid SHA line {path}:{number}: {line!r}')
        h, name = match.groups()
        name = name.removeprefix('*')
        p = PurePosixPath(name)
        if p.is_absolute() or '..' in p.parts or name in entries:
            raise ValueError(f'Unsafe or duplicate path {path}:{number}: {name!r}')
        entries[name] = h
    return entries


def flat_manifest(root, name, complete=False):
    entries = parse_manifest(root / name)
    actual_names = {p.name for p in root.iterdir() if p.is_file()} - {name}
    results = []
    for filename, expected in entries.items():
        path = root / filename
        actual = digest(path) if path.is_file() else None
        record = {'path': str(path), 'name': filename, 'expected_sha256': expected,
                  'actual_sha256': actual, 'matches': expected == actual}
        results.append(record)
        if actual != expected:
            REPORT['real_sha_mismatches'].append(record)
    return {'manifest': str(root / name), 'sha256': digest(root / name),
            'entry_count': len(entries), 'matched_count': sum(r['matches'] for r in results),
            'complete_inventory_required': complete,
            'unlisted': sorted(actual_names - set(entries)) if complete else [],
            'missing': sorted(set(entries) - actual_names), 'entries': results,
            'pass': all(r['matches'] for r in results)
                    and (not complete or actual_names == set(entries))}


REPORT = {
    'schema': 'crtt-independent-review-v1', 'started_utc': utc(),
    'review_kind': 'fresh Python checks plus replay of supplied Lean journal',
    'working_copy': str(WORK), 'canonical_source': str(ORIGINAL),
    'fresh_lean_verification': {'status': 'NOT_RUN', 'reason': 'Lean not on PATH; no toolchain download or installation'},
    'environment': {'python': sys.version, 'platform': platform.platform(),
                    'assertions_enabled': not sys.flags.optimize,
                    'lean_on_path': shutil.which('lean')},
    'real_sha_mismatches': [], 'commands': [], 'limitations': [
        'Supplied compiler exits and provenance are statements in the hashed journal; local replay does not cryptographically attest its execution.',
        'Fresh finite Python cases do not constitute fresh Lean compilation or proof of properties outside their finite scope.',
        'Historical manifests are checked as pinned subsets; later unlisted files are not classified as historical hash mismatches.',
        'No historical source, package manifest, or supplied witness is edited.',
    ],
}


def checkpoint():
    write_json(OUT / 'review_report.json', REPORT)


def run_command(label, args, expected_exit=0, origin='fresh Python execution', timeout=240):
    env = os.environ.copy()
    env.pop('PYTHONOPTIMIZE', None)
    env.pop('PYTHONPATH', None)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['PYTHONHASHSEED'] = '0'
    env['TMPDIR'] = str(TMP)
    start = utc()
    t0 = time.monotonic()
    timed_out = False
    try:
        p = subprocess.run(args, cwd=WORK, env=env, capture_output=True, timeout=timeout)
        code, stdout, stderr = p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as exc:
        code, stdout, stderr, timed_out = None, exc.stdout or b'', exc.stderr or b'', True
    outpath, errpath = LOGS / f'{label}.stdout.log', LOGS / f'{label}.stderr.log'
    outpath.write_bytes(stdout)
    errpath.write_bytes(stderr)
    record = {'id': label, 'argv': [str(a) for a in args],
              'display_command': shlex.join([str(a) for a in args]), 'cwd': str(WORK),
              'started_utc': start, 'finished_utc': utc(),
              'elapsed_seconds': round(time.monotonic() - t0, 6),
              'exit_code': code, 'expected_exit_code': expected_exit, 'timed_out': timed_out,
              'matches_expected_exit': code == expected_exit and not timed_out,
              'evidence_origin': origin,
              'environment_controls': {'PYTHONOPTIMIZE': 'unset', 'PYTHONPATH': 'unset',
                  'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONHASHSEED': '0', 'TMPDIR': str(TMP)},
              'stdout': {'path': str(outpath), 'bytes': len(stdout), 'sha256': digest_bytes(stdout)},
              'stderr': {'path': str(errpath), 'bytes': len(stderr), 'sha256': digest_bytes(stderr)}}
    write_json(LOGS / f'{label}.json', record)
    print(f'{label}: exit={code}; expected={expected_exit}; {record["elapsed_seconds"]:.3f}s', flush=True)
    return record


def inspect_source_zip():
    actual = digest(SOURCE_ZIP)
    result = {'path': str(SOURCE_ZIP), 'expected_sha256': EXPECTED_ZIP,
              'actual_sha256': actual, 'matches': actual == EXPECTED_ZIP}
    if not result['matches']:
        REPORT['real_sha_mismatches'].append(result.copy())
    records = []
    with zipfile.ZipFile(SOURCE_ZIP) as z:
        names = [info.filename for info in z.infolist()]
        result['duplicate_names'] = [name for name, count in Counter(names).items() if count > 1]
        result['unsafe_paths'] = [name for name in names
            if PurePosixPath(name).is_absolute() or '..' in PurePosixPath(name).parts]
        result['crc_failure'] = z.testzip()
        for info in z.infolist():
            if info.is_dir():
                continue
            path = PurePosixPath(info.filename)
            relative = str(PurePosixPath(*path.parts[1:]))
            data = z.read(info)
            expected = digest_bytes(data)
            local = ORIGINAL / relative
            local_hash = digest(local) if local.is_file() else None
            row = {'member': info.filename, 'relative_path': relative,
                   'bytes': len(data), 'zip_member_sha256': expected,
                   'extracted_sha256': local_hash, 'matches': expected == local_hash}
            records.append(row)
            if not row['matches']:
                REPORT['real_sha_mismatches'].append(row)
    result['entries'] = records
    result['file_count'] = len(records)
    result['exact_extracted_file_set'] = set(r['relative_path'] for r in records) == set(inventory(ORIGINAL))
    result['pass'] = result['matches'] and result['exact_extracted_file_set'] and all(r['matches'] for r in records) and not result['unsafe_paths'] and not result['duplicate_names'] and result['crc_failure'] is None
    return result


def nested_historical_checks():
    result = []
    for name in ('HISTORY_T01_T18.zip', 'HISTORY_T03_T19.zip'):
        with zipfile.ZipFile(WORK / name) as z:
            record = {'archive': name, 'sha256': digest(WORK / name), 'crc_failure': z.testzip(), 'entries': []}
            for member in z.namelist():
                if not member.endswith('/SHA256SUMS.txt'):
                    continue
                parent = member.rsplit('/', 1)[0]
                for line in z.read(member).decode().splitlines():
                    h, filename = line.split(maxsplit=1)
                    actual = digest_bytes(z.read(parent + '/' + filename))
                    row = {'manifest_member': member, 'member': parent + '/' + filename,
                           'expected_sha256': h, 'actual_sha256': actual, 'matches': h == actual}
                    record['entries'].append(row)
                    if not row['matches']:
                        REPORT['real_sha_mismatches'].append(row)
            record['pass'] = record['crc_failure'] is None and all(e['matches'] for e in record['entries'])
            result.append(record)
    return result


def historical_checks():
    snapshots = json.loads(INDEX.read_text())
    snapshot_manifests = []
    for snap in snapshots:
        for p in Path(snap['extract']).rglob('SHA256SUMS.txt'):
            snapshot_manifests.append((digest(p), snap, p))
    results, recoveries = [], []
    for manifest in sorted(WORK.glob('T*_SHA256SUMS.txt')):
        stage = manifest.name.removesuffix('_SHA256SUMS.txt')
        pinned = parse_manifest(manifest)
        historical_digest = digest(manifest)
        row = {'manifest': manifest.name, 'manifest_sha256': historical_digest,
               'scope': 'pinned subset only; later unlisted files are out of scope',
               'entries': [], 'local_content_locator_checks': []}
        local_unresolved = []
        for name, h in pinned.items():
            same = WORK / name
            alias = WORK / (stage + '_' + name)
            if stage == 'T247' and name == 'KERNEL_CHECK.log':
                alias = WORK / 'T247_KERNEL.log'
            if same.is_file() and digest(same) == h:
                loc = same
                resolution = 'original relative path'
            elif alias.is_file() and digest(alias) == h:
                loc = alias
                resolution = 'explicit stage-prefixed historical locator; byte identity checked'
            else:
                loc = None
                resolution = 'historical object not present at either current or stage-prefixed locator'
                local_unresolved.append((name, h))
            row['local_content_locator_checks'].append({'historical_name': name,
                'expected_sha256': h, 'resolved_path': str(loc) if loc else None, 'resolution': resolution})
        matches = [(snap, p) for h, snap, p in snapshot_manifests if h == historical_digest]
        row['matching_snapshot_manifest_count'] = len(matches)
        if not matches:
            row['pass'] = False
            row['unresolved_pins'] = [{'name': n, 'sha256': h} for n, h in local_unresolved]
            results.append(row)
            continue
        snap, historical_manifest = sorted(matches, key=lambda x: (len(x[0]['name']), x[0]['name'], str(x[1])))[0]
        archive_actual = digest(Path(snap['input']))
        row['source_archive'] = {'path': snap['input'], 'indexed_sha256': snap['sha256'],
                                 'actual_sha256': archive_actual, 'matches': snap['sha256'] == archive_actual}
        row['source_manifest'] = str(historical_manifest)
        with zipfile.ZipFile(snap['input']) as z:
            manifest_member = str(historical_manifest.relative_to(Path(snap['extract'])))
            archived_manifest_hash = digest_bytes(z.read(manifest_member))
            row['archived_manifest_matches_historical_manifest'] = archived_manifest_hash == historical_digest
            historical_root = historical_manifest.parent
            for name, expected in pinned.items():
                source = historical_root / name
                actual = digest(source) if source.is_file() else None
                member = str(source.relative_to(Path(snap['extract'])))
                archived_actual = digest_bytes(z.read(member)) if member in z.namelist() else None
                item = {'historical_name': name, 'expected_sha256': expected,
                        'source_path': str(source), 'source_sha256': actual,
                        'archive_member': member, 'archived_member_sha256': archived_actual,
                        'matches': expected == actual == archived_actual}
                row['entries'].append(item)
                if not item['matches']:
                    REPORT['real_sha_mismatches'].append(item)
                if (name, expected) in local_unresolved:
                    recoveries.append({'stage': stage, 'historical_manifest': manifest.name,
                        'historical_manifest_sha256': historical_digest, 'historical_name': name,
                        'expected_sha256': expected, 'source_path': str(source),
                        'source_sha256': actual, 'source_archive': snap['input'],
                        'source_archive_sha256': archive_actual, 'archive_member': member,
                        'archived_member_sha256': archived_actual,
                        'suggested_recovered_relative_path': f'{stage}/{name}',
                        'recovered_byte_identity_verified': item['matches'],
                        'witness': 'Exact historical manifest bytes found in original archive; manifest entry, archive member and extracted original agree.'})
        row['entry_count'] = len(pinned)
        row['local_unresolved_count_before_recovery'] = len(local_unresolved)
        row['pass'] = row['source_archive']['matches'] and row['archived_manifest_matches_historical_manifest'] and all(e['matches'] for e in row['entries'])
        results.append(row)
    write_json(OUT / 'historical_recovery.json', recoveries)
    return results, recoveries


def supplied_segments():
    path = SUPPLIED / 'T32-KERNEL_CHECK.log'
    data = path.read_bytes()
    lines = data.splitlines(keepends=True)
    offsets = [0]
    for line in lines:
        offsets.append(offsets[-1] + len(line))
    raw_text = data.decode()
    marker = re.compile(rb'^=== LEAN: (\S+\.lean) ===\r?\n?$')
    positions = [(i, marker.fullmatch(line).group(1).decode())
                 for i, line in enumerate(lines) if marker.fullmatch(line)]
    runner = (WORK / 'run_verify.sh').read_text()
    expected_order = re.search(r'^for src in (.+); do$', runner, re.M).group(1).split()
    actual_order = [name for i, name in positions]
    if actual_order != expected_order:
        raise ValueError('Supplied compile section order differs from reviewed runner')
    checks = []
    for i, name in positions:
        footer = next(j for j in range(i + 1, len(lines)) if lines[j].startswith(('AUDIT ' + name + ':').encode()))
        text = lines[footer].decode().strip()
        summary = re.fullmatch(r'AUDIT (\S+): (\d+)/(\d+) axiom reports; Lean exit=(-?\d+); dependencies=(.*)', text)
        if not summary:
            raise ValueError('Unrecognized supplied footer ' + text)
        raw = b''.join(lines[i + 1:footer])
        segment = SEGMENTS / f'{Path(name).stem}.compile.raw.log'
        segment.write_bytes(raw)
        checks.append({'source': name, 'source_sha256': digest(WORK / name),
             'segment_path': str(segment), 'segment_sha256': digest_bytes(raw),
             'source_log_sha256': digest_bytes(data), 'byte_start': offsets[i + 1], 'byte_end': offsets[footer],
             'marker_line': i + 1, 'audit_footer_line': footer + 1,
             'reported_actual_count': int(summary.group(2)), 'reported_expected_count': int(summary.group(3)),
             'supplied_lean_exit_code': int(summary.group(4)),
             'lean_exit_provenance': 'parsed from supplied journal; not a locally observed compiler process',
             'source_expected_report_count': len(re.findall(r'^#print axioms\s+(\S+)', (WORK / name).read_text(), re.M))})
    cli_marker = next(i for i, line in enumerate(lines) if line.strip() == b'=== T32 CLI: ACTUAL LEAN EXECUTION ===')
    cli_end = next(j for j in range(cli_marker + 1, len(lines)) if lines[j].startswith(b'AUDIT ReleaseMain.lean:'))
    cli_status = int(re.search(rb'Lean exit=(-?\d+)', lines[cli_end]).group(1))
    cli = b''.join(lines[cli_marker + 1:cli_end])
    cli_path = SEGMENTS / 'ReleaseMain.cli.raw.log'
    cli_path.write_bytes(cli)
    cli_record = {'source': 'ReleaseMain.lean', 'segment_path': str(cli_path),
         'segment_sha256': digest_bytes(cli), 'source_log_sha256': digest_bytes(data),
         'byte_start': offsets[cli_marker + 1], 'byte_end': offsets[cli_end],
         'marker_line': cli_marker + 1, 'audit_footer_line': cli_end + 1,
         'supplied_lean_exit_code': cli_status, 'lean_exit_provenance': 'supplied journal only'}
    diagnostics = {p: len(re.findall(p, raw_text, re.I))
                   for p in [r'\bwarning:', r'\berror:', r'\bsorryAx\b', r'\bClassical\.choice\b']}
    version = re.findall(r'^Lean \(version .+\)$', raw_text, re.M)
    evidence = {'journal_path': str(path), 'journal_sha256': digest_bytes(data),
        'observed_version_lines': version,
        'pinned_toolchain_in_log': len(version) == 1 and 'version 4.36.0,' in version[0] and 'commit 611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9' in version[0],
        'compile_section_count': len(checks), 'source_expected_report_total': sum(c['source_expected_report_count'] for c in checks),
        'supplied_report_total': sum(c['reported_actual_count'] for c in checks),
        'whole_journal_diagnostic_pattern_counts': diagnostics,
        'final_success_marker_present': 'PASS: T32 complete manifest, Lean compilation, 542 audited reports, finite checks and actual CLI/reference agreement.' in raw_text,
        'compile_sections': checks, 'cli_section': cli_record,
        'trust_boundary': 'Source and output hashes plus parser replay establish byte identity and journal consistency; compiler execution is not independently attested.'}
    return evidence


def main():
    if sys.flags.optimize:
        raise RuntimeError('Assertions must remain enabled')
    if shutil.which('lean'):
        raise RuntimeError('Lean unexpectedly available; refusing an unplanned compiler invocation')
    original_before = json.loads((OUT / 'original_inventory_before.json').read_text())
    frozen_before = inventory(FROZEN)
    REPORT['initial_working_copy_matches_canonical_source'] = inventory(WORK) == original_before
    REPORT['reviewed_before_execution'] = [{'path': str(WORK / n), 'sha256': digest(WORK / n)}
        for n in ['audit_lean.py', 'audit_names.py', 'verify_integrity.py', 'run_verify.sh',
                  'test_audit.py', 'test_release_projection.py', 'check_release.py']]
    REPORT['source_zip'] = inspect_source_zip()
    REPORT['current_manifest'] = flat_manifest(WORK, 'SHA256SUMS.txt', complete=True)
    REPORT['current_upstream'] = flat_manifest(WORK, 'UPSTREAM_SHA256.txt')
    REPORT['frozen_external_manifest'] = flat_manifest(FROZEN, 'SHA256SUMS.txt', complete=True)
    REPORT['standalone_history'] = nested_historical_checks()
    REPORT['historical_manifests'], REPORT['historical_recoveries'] = historical_checks()
    REPORT['historical_upstream_manifests'] = [flat_manifest(WORK, p.name) for p in sorted(WORK.glob('T*_UPSTREAM_SHA256.txt'))]
    snapshots = json.loads(INDEX.read_text())
    pins = []
    for name, h in parse_manifest(WORK / 'PARENT_ARCHIVE_SHA256.txt').items():
        matches = [snap for snap in snapshots if snap['sha256'] == h]
        matches = [{'path': s['input'], 'actual_sha256': digest(s['input'])} for s in matches]
        pins.append({'declared_name': name, 'expected_sha256': h, 'located_archives': matches,
                     'pass': bool(matches) and all(m['actual_sha256'] == h for m in matches)})
    REPORT['parent_archive_pins'] = pins
    checkpoint()
    print('Initial integrity and historical recovery checks complete.', flush=True)
    # This directly exercises the fail-closed preflight; expected exit 127 is
    # evidence that no local Lean verification happened, not a full release pass.
    REPORT['commands'].append(run_command('runner_without_lean', ['bash', 'run_verify.sh'], expected_exit=127,
        origin='fresh runner preflight only; Lean absent; full release verification blocked'))
    finite = ['check_pruning.py', 'check_impasse.py', 'check_learning.py', 'check_meta.py',
              'check_evidence.py', 'check_decision.py', 'check_replacement.py', 'check_relative.py',
              'check_admission.py', 'check_trace.py', 'check_policy.py', 'check_closure.py', 'check_release.py']
    with ThreadPoolExecutor(max_workers=3) as executor:
        pending = {executor.submit(run_command, Path(name).stem, [sys.executable, name]): name
                   for name in finite}
        for future in as_completed(pending):
            REPORT['commands'].append(future.result())
            checkpoint()
    evidence = supplied_segments()
    REPORT['supplied_lean_evidence'] = evidence
    jobs = []
    for c in evidence['compile_sections']:
        stem = Path(c['source']).stem
        jobs.append((f'replay_{stem}_audit', [sys.executable, 'audit_lean.py', c['source'], c['segment_path'], str(c['supplied_lean_exit_code'])]))
        jobs.append((f'replay_{stem}_names', [sys.executable, 'audit_names.py', c['source'], c['segment_path']]))
    cli = evidence['cli_section']
    jobs += [('replay_cli_audit', [sys.executable, 'audit_lean.py', 'ReleaseMain.lean', cli['segment_path'], str(cli['supplied_lean_exit_code'])]),
             ('replay_cli_names', [sys.executable, 'audit_names.py', 'ReleaseMain.lean', cli['segment_path']]),
             ('replay_cli_reference', [sys.executable, 'check_release.py', '--lean-log', cli['segment_path']])]
    with ThreadPoolExecutor(max_workers=3) as executor:
        pending = [executor.submit(run_command, label, args, origin='local parser/reference replay of supplied journal; not fresh Lean execution') for label, args in jobs]
        for future in as_completed(pending):
            REPORT['commands'].append(future.result())
    REPORT['commands'].append(run_command('integrity_after_replay', [sys.executable, 'verify_integrity.py']))
    by_id = {c['id']: c for c in REPORT['commands']}
    comparisons = []
    for name in finite:
        stem = Path(name).stem
        supplied_name = 'FINITE_' + stem.removeprefix('check_').upper() + '.log'
        old = WORK / supplied_name
        if old.is_file():
            generated = Path(by_id[stem]['stdout']['path'])
            comparisons.append({'script': name, 'supplied_fixture_log': supplied_name,
                 'supplied_sha256': digest(old), 'fresh_stdout_sha256': digest(generated),
                 'byte_identical': digest(old) == digest(generated),
                 'interpretation': 'Output equivalence is separate from the script exit result.'})
    REPORT['finite_stdout_comparisons'] = comparisons
    REPORT['supplied_final_audit'] = {
        'path': str(SUPPLIED / 'T32-FINAL-AUDIT.log'), 'sha256': digest(SUPPLIED / 'T32-FINAL-AUDIT.log'),
        'role': 'historical supplied replay result; local command records are separate',
        'reported_audit_occurrences': len(re.findall(r'^AUDIT ', (SUPPLIED / 'T32-FINAL-AUDIT.log').read_text(), re.M)),
        'local_replay_auditor_invocations': len([j for j in jobs if j[0].endswith('_audit')]),
    }
    REPORT['original_source_unchanged'] = inventory(ORIGINAL) == original_before
    REPORT['working_copy_unchanged'] = inventory(WORK) == original_before
    REPORT['frozen_files_unchanged'] = inventory(FROZEN) == frozen_before
    REPORT['summary'] = {
        'current_manifest': f"{REPORT['current_manifest']['matched_count']}/{REPORT['current_manifest']['entry_count']}",
        'current_upstream': f"{REPORT['current_upstream']['matched_count']}/{REPORT['current_upstream']['entry_count']}",
        'historical_manifest_count': len(REPORT['historical_manifests']),
        'historical_manifests_pass': sum(m['pass'] for m in REPORT['historical_manifests']),
        'historical_pinned_file_checks': sum(len(m['entries']) for m in REPORT['historical_manifests']),
        'historical_objects_recovered_from_original_archives': len(REPORT['historical_recoveries']),
        'standalone_historical_checks': sum(len(m['entries']) for m in REPORT['standalone_history']),
        'fresh_finite_scripts_pass': sum(by_id[Path(n).stem]['matches_expected_exit'] for n in finite),
        'fresh_finite_script_count': len(finite),
        'supplied_compile_sections': evidence['compile_section_count'],
        'supplied_axiom_reports': evidence['supplied_report_total'],
        'supplied_log_parser_replay_pass': all(by_id[label]['matches_expected_exit'] for label, args in jobs),
        'command_count': len(REPORT['commands']),
        'all_commands_match_expected_exit': all(c['matches_expected_exit'] for c in REPORT['commands']),
        'runner_exit_without_lean': by_id['runner_without_lean']['exit_code'],
        'real_sha_mismatch_count': len(REPORT['real_sha_mismatches']),
        'fresh_lean_run': False,
    }
    REPORT['finished_utc'] = utc()
    checkpoint()
    write_json(OUT / 'original_inventory_after.json', inventory(ORIGINAL))
    write_json(OUT / 'working_copy_inventory_after.json', inventory(WORK))
    print(json.dumps(REPORT['summary'], indent=2), flush=True)
    if REPORT['real_sha_mismatches'] or not REPORT['summary']['all_commands_match_expected_exit']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
