#!/usr/bin/env python3
"""Verify the complete archive's bytes and inventory; this does not run Lean."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def safe_relative(value: str) -> PurePosixPath:
    p = PurePosixPath(value)
    if (not value or not p.parts or p.is_absolute() or '..' in p.parts
            or '\\' in value or '\n' in value or '\r' in value or p.as_posix() != value):
        raise ValueError(f'Unsafe or noncanonical path: {value!r}')
    return p


def verify(root: Path, archives: bool = True) -> dict:
    errors = []
    actual_files = {}
    for p in root.rglob('*'):
        rel = p.relative_to(root).as_posix()
        if p.is_symlink():
            errors.append(f'Symlink is not permitted: {rel}')
        elif p.is_file():
            actual_files[rel] = p
    checksums = {}
    for line in (root / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        m = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        if not m:
            errors.append(f'Malformed checksum line: {line!r}')
            continue
        wanted, rel = m.groups()
        safe_relative(rel)
        if rel in checksums:
            errors.append(f'Duplicate checksum entry: {rel}')
        checksums[rel] = wanted
    expected_inventory = set(checksums) | {'SHA256SUMS.txt'}
    if set(actual_files) != expected_inventory:
        errors.append('Inventory mismatch: ' + json.dumps({
            'missing': sorted(expected_inventory - set(actual_files)),
            'unlisted': sorted(set(actual_files) - expected_inventory)}, ensure_ascii=False))
    checked = 0
    for rel, wanted in checksums.items():
        p = actual_files.get(rel)
        if p is None:
            continue
        if digest(p) != wanted:
            errors.append(f'SHA-256 mismatch: {rel}')
        else:
            checked += 1
    manifest = json.loads((root / 'MANIFEST.json').read_text(encoding='utf-8'))
    records = manifest['files']
    paths = [r['path'] for r in records]
    if len(paths) != len(set(paths)):
        errors.append('Duplicate MANIFEST paths')
    payload_inventory = set(actual_files) - {'MANIFEST.json', 'SHA256SUMS.txt'}
    if set(paths) != payload_inventory:
        errors.append('MANIFEST payload inventory mismatch')
    for rec in records:
        rel = rec['path']
        safe_relative(rel)
        p = actual_files.get(rel)
        if p is None:
            continue
        if rec['sha256'] != checksums.get(rel):
            errors.append(f'MANIFEST/SHA256SUMS disagreement: {rel}')
        if rec['size_bytes'] != p.stat().st_size:
            errors.append(f'Size mismatch: {rel}')
    if manifest['payload_file_count'] != len(records):
        errors.append('MANIFEST file count mismatch')
    archive_count = 0
    if archives:
        for p in sorted((root / 'originals' / 'archives').glob('*.zip')):
            with zipfile.ZipFile(p) as z:
                names = z.namelist()
                if len(names) != len(set(names)):
                    errors.append(f'Duplicate ZIP member: {p.name}')
                for entry in z.infolist():
                    safe_relative(entry.filename.rstrip('/'))
                    if stat.S_ISLNK(entry.external_attr >> 16):
                        errors.append(f'Symlink in ZIP: {p.name}: {entry.filename}')
                bad = z.testzip()
                if bad is not None:
                    errors.append(f'ZIP CRC failure: {p.name}: {bad}')
            archive_count += 1
    provenance = json.loads((root / 'PROVENANCE.json').read_text(encoding='utf-8'))
    archive_rel = safe_relative(provenance['canonical']['archive_path']).as_posix()
    if archive_rel not in actual_files:
        raise ValueError('Canonical archive is absent from the verified file inventory')
    canonical_archive = root / archive_rel
    if canonical_archive.is_symlink() or not canonical_archive.resolve().is_relative_to(root.resolve()):
        raise ValueError('Canonical archive must stay inside the verified archive directory')
    if digest(canonical_archive) != provenance['canonical']['sha256']:
        errors.append('Canonical archive differs from its provenance SHA-256 pin')
    member_root = safe_relative(provenance['canonical']['member_root']).as_posix()
    with zipfile.ZipFile(canonical_archive) as z:
        prefix = member_root + '/'
        members = {n[len(prefix):]: z.read(n) for n in z.namelist()
                   if n.startswith(prefix) and not n.endswith('/')}
    canonical_files = {p.relative_to(root / 'canonical').as_posix(): p
                       for p in (root / 'canonical').rglob('*') if p.is_file()}
    if set(members) != set(canonical_files):
        errors.append('Canonical source inventory differs from accepted original ZIP')
    for rel, data in members.items():
        if rel in canonical_files and canonical_files[rel].read_bytes() != data:
            errors.append(f'Canonical source bytes differ from accepted original ZIP: {rel}')
    return {'status': 'PASS' if not errors else 'FAIL',
            'checksums_matched': checked, 'checksums_expected': len(checksums),
            'files_total': len(actual_files), 'payload_files': len(records),
            'original_archives_crc_checked': archive_count,
            'canonical_files_compared': len(members),
            'lean_executed': False, 'errors': errors}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--skip-zip-crc', action='store_true')
    args = parser.parse_args()
    try:
        result = verify(args.root.resolve(), not args.skip_zip_crc)
    except (OSError, ValueError, KeyError, zipfile.BadZipFile) as exc:
        result = {'status': 'FAIL', 'errors': [str(exc)], 'lean_executed': False}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
