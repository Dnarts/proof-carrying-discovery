# RC2 bibliography revision

Only `section9.tex` and `references.tex` changed. Pages 1–17 are text- and raster-identical to the checksummed RC1 PDF. Eight repository-linked companion references were added and all eleven distinct related Zenodo record/DOI hyperlink destinations were checked in the PDF. Direct external resolution could not be confirmed; see `ZENODO_LINK_AUDIT.md`. The 20-page build is clean. No new Lean execution or formal source modification. The historical RC1 review follows (its page counts and run statements describe that earlier release).

---

# Editorial and mathematical review — integrated release candidate

**Internal recommendation: accept package B with minor revisions; integrated manuscript ready for author review, not external peer review or publication approval.**

- The pasted B review counted 72 `\rc` occurrences as if they were theorem identifiers. Direct extraction gives 72 occurrences: 13 source filenames, 58 audited declaration mentions, and one supporting definition (`discoverAll`). Several short names occur in more than one module, so module context and the precise source map matter. This is a correction to the review metric, not a missing theorem.
- Section 3: clarify the indexed task's full nonempty action carrier (including a default). Bellman uses a nonempty scenario list for the displayed recurrence and gives zero on the empty list; no change needed there. Transfer, exact finite search and its canonical-representative scope checked against source statements.
- Section 4: disambiguate the overloaded port/receipt notation Q across Sections 3, 4 and 6. Funded exhaustion, budget-independent continuation and inclusion-irreducibility retain their distinct premises.
- Section 5: the T25 scenarios are task pairs with fixed carrier sizes. Distinguish reference objective, actual bill, hard regret constraints, and external evidence coverage. No general online optimality claim for the T26 fixed acquisition schedule.
- Sections 1–2 and 6–7 unchanged in bytes relative to the ABC source archive. The root trace identity and rejection-free meta-policy inequality remain separate.
- Section 8: distinguish author-supplied Lean compilation logs, independent finite reference computations, and successful repeat Python replay. A byte-identical runner log does not establish independent fresh execution. Correctly distinguish 542 audited declarations from 520 theorems and 22 definitions. In the predecessor witness the starting available balance is 95 with 5 previously spent, not 100 available; the double witness starts with a different redundant policy.
- Section 9: compare to information/decision theory, adaptive query strategies, proof-carrying code, conflict learning, metareasoning, reflection and dynamic/self-updating programs; no claim of priority or full literature coverage.

Both prior source maps were checked against the exact historical/canonical source files and the successful transcript: 214 source locators, including 137 recorded audit lines. The full reconciled architecture archive passed its own manifest verifier (766/766), matched the 21 canonical Lean sources byte-for-byte with the accepted T32 ZIP, and passed `replay_evidence.py` (45 exit-zero Python commands, 542 audited names, nine CLI fixtures). This work did not recompile Lean. The final paper has 19 pages with the established 10pt and one-inch margin layout; both final LaTeX passes completed.

Remaining publication tasks: author approval of the final manuscript; deposit the supplementary artifact at a durable public identifier (none invented); external mathematical review and a broader novelty/literature audit. Historical numbering gaps T01, T02, T04–T13 remain explicit.
