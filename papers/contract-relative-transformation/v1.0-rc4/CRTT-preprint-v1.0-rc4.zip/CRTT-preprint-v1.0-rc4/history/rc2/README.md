# CRTT preprint v1.0-rc2

Integrated English manuscript: 20 pages, Sections 1–9 and references. Packages A (1–4), B (5–10), C (11–15), D (16–20). A and C remain byte-identical to the accepted ABC manuscript sources. B has three local clarifications. D covers evidence, all nine release witnesses, reproduction, related work and limitations.

Build from this directory with `pdflatex -interaction=nonstopmode -halt-on-error main.tex` twice. No external bibliography processing is required. The compiled `main.pdf` is included. The separately distributed `CRTT-v1.0-FULL-ARCHITECTURE-RECONCILED.zip` is the exact formal supplementary artifact; its SHA-256 is printed in the article.

`REVIEW.md` records editorial decisions and scope. `SOURCE_MAP_AB.md`, `SOURCE_MAP_C.md`, and `SOURCE_MAP_D.md` preserve links to formal claims, declarations and verification evidence. `REVIEW_RECEIPT.json` preserves the RC1 repeat audit of the supplied logs and records the RC2 bibliography checks; it is not a new Lean compilation. `SOURCE_SHA256_AB.txt` and `SOURCE_SHA256_C.txt` retain original source pins. `SHA256SUMS.txt` covers the entire manuscript bundle except itself.

Status: manuscript release candidate, not an externally peer-reviewed or published article. No formal CRTT source was changed.

RC2 adds eight companion-work entries (24 references in total) from the author’s three research repositories. `ZENODO_LINK_AUDIT.md` and `.json` distinguish verified repository locators from unconfirmed live record resolution. Earlier metadata and modified text are retained under `history/rc1/`. Pages 1–17 and all mathematical LaTeX sources are unchanged.
