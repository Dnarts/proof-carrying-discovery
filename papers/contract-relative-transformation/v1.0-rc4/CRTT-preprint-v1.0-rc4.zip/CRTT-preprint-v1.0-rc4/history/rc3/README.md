# CRTT preprint v1.0-rc3

Integrated English manuscript: 20 pages, Sections 1–9 and references. Packages A (1–4), B (5–10), C (11–15), D (16–20). The mathematical contents of A and C remain unchanged from the accepted ABC manuscript sources; RC3 modifies only the title metadata and spacing in A. B has three local clarifications. D covers evidence, all nine release witnesses, reproduction, related work and limitations.

Build from this directory with `pdflatex -interaction=nonstopmode -halt-on-error main.tex` twice. No external bibliography processing is required. The compiled `main.pdf` is included. The separately distributed `CRTT-v1.0-FULL-ARCHITECTURE-RECONCILED.zip` is the exact formal supplementary artifact; its SHA-256 is printed in the article.

`REVIEW.md` records editorial decisions and scope. `SOURCE_MAP_AB.md`, `SOURCE_MAP_C.md`, and `SOURCE_MAP_D.md` preserve links to formal claims, declarations and verification evidence. `REVIEW_RECEIPT.json` preserves the RC1 repeat audit of the supplied logs and records the RC2 bibliography checks; it is not a new Lean compilation. `SOURCE_SHA256_AB.txt` and `SOURCE_SHA256_C.txt` retain original source pins. `SHA256SUMS.txt` covers the entire manuscript bundle except itself.

Status: manuscript release candidate, not an externally peer-reviewed or published article. No formal CRTT source was changed.

RC2 adds eight companion-work entries (24 references in total) from the author’s three research repositories. `ZENODO_LINK_AUDIT.md` and `.json` distinguish verified repository locators from unconfirmed live record resolution. Earlier metadata and modified text are retained under `history/rc1/`. In RC2, pages 1–17 and all mathematical LaTeX sources were unchanged relative to RC1.

RC3 adds the author email below the name as a mailto hyperlink. Only the author/date lines of `sections12.tex` changed; the date spacing was adjusted to keep 20 pages. Pages 2–20 match RC2 in extracted text and raster rendering. All 24 references and existing external link destinations are unchanged. RC2 metadata and title source are preserved under `history/rc2/`. No fresh Lean compilation or replay was performed for this contact-only revision.
