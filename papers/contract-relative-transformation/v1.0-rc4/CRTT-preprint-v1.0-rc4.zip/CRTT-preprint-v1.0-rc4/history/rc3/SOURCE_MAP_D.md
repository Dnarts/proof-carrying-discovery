# Section 8–9 evidence and bibliographic locators

Canonical evidence lives in the separately distributed RECONCILED archive, identified by the SHA-256 in Section 8.3. The source and audit counts below refer to that immutable payload, not to a new Lean invocation.

| Claim | Exact source |
|---|---|
| 21 Lean files, 542 targets (520 theorems, 22 definitions) | `catalog/AUDITED_DECLARATIONS.csv`; `catalog/VERIFICATION.json`; `VERIFICATION_RU.md` |
| Pinned toolchain and complete runner | `canonical/lean-toolchain`; `canonical/run_verify.sh`; supplied `evidence/local_verification/RUNNER_FULL.log` line 176 |
| Parser controls | supplied runner lines 164–175; `canonical/test_audit.py`; `canonical/test_release_projection.py` |
| Canonical release proof targets | `canonical/Release.lean` lines 22–81 and 273–285; supplied runner lines 778–800 |
| 515 learning cases | supplied runner, finite learning output (`vs_read_costlier: 515`); `canonical/check_learning.py` |
| T28 cost witness | `canonical/check_replacement.py`; runner line 904; net gain and reserve discussion lines 919–922 |
| T29c mixed costs | `canonical/check_trace.py`; runner lines 945–946 |
| T31 closure and 8→7→6, 4→10 | `canonical/check_closure.py`; runner lines 978–1000 |
| T32 nine cases | `canonical/FINITE_RELEASE.json`; `canonical/Release.lean` `Witnesses` and `reports`; `canonical/check_release.py` lines 67–91, 102–148; runner lines 1542–1554 |
| Five-unit prior work | `canonical/Release.lean` line 254 (`partialLive`); runner `T32PRIOR` and `T32CERT` predecessor rows |
| Log replay vs fresh run | `catalog/VERIFICATION.json`; `evidence/reconciliation/replay/log_review.json`; `REVIEW_RECEIPT.json` (new replay) |
| Historical numbering and axiom limitations | `GAPS_AND_STATUS_RU.md` |

The bibliography uses published metadata and DOI links (or the original arXiv identifier in the RAT-verification entry); the artifact entry refers to the supplied supplementary archive rather than an invented DOI. Related-work paragraphs are a scoped comparison, not an exhaustive novelty review.

## Companion-study references (rc2)

See `ZENODO_LINK_AUDIT.md` and `ZENODO_LINK_AUDIT.json` for exact repository locators, blob SHA values, and the distinction between repository verification and unresolved external record availability. These citations are contextual, not proof dependencies.
