# CRTT v1.0 RC4: fresh Linux verification receipt

This receipt records a clean run of the public RC4 verification wrapper against the exact RECONCILED software supplement identified in §8.3. It is distinct from the supplied author transcript, the recorded historical Python replay, and the earlier separate Linux run against the inner RC1 ZIP.

- Repository commit supplying the wrapper: 78c57a30fc1ec9a5e667fae94bfe40f4cce4c4fe
- Wrapper path: papers/contract-relative-transformation/v1.0-rc4/publication/supplement/verify_fresh.sh
- Wrapper SHA-256: fa7ed0361195fcef3b7c2321c702f9694a6fa2bfbe6ecbefdedc81687ce0d420
- Input: CRTT-v1.0-FULL-ARCHITECTURE-RECONCILED.zip
- Input SHA-256: e09580cdb8a8f900401390db394a7bde07bb328449b50b059f2a8cd3c175c79e
- Toolchain: Lean 4.36.0, x86_64-unknown-linux-gnu, commit 611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9
- Official Linux toolchain archive SHA-256: 2b7ab1ed8b92d2e6abfaf41344823b510064dbc9c0260cac73eb496ab2dea6eb

`STATUS.json` gives the wrapper verdict and digests of its component logs. The raw environment log is omitted because it includes local paths and a host identifier. `FRESH_KERNEL_CHECK.log` is the actual freshly executed canonical runner transcript. `SHA256SUMS.txt` verifies the contents of this receipt. The original supplement and repository were not changed.

The run checks the canonical stack and the finite cases exercised by the runner, not the execution of every historical variant, independent peer review, or wall-clock performance.
