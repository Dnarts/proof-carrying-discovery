"""Independent finite arithmetic cross-check for CRTT-T17-v0.1."""
from fractions import Fraction


def online_cost(D, R, T, first, target):
    return D + (T - 1) * R if first == target else 2 * D + (T - 2) * R


def clairvoyant_cost(D, R, T):
    return D + (T - 1) * R


def offline_opt(D, L, R, T):
    return T * R + min(T * (L - R), D - R)


def buy_at_cost(D, L, R, k, T):
    return T * L if T < k else T * R + (D - R) + (k - 1) * (L - R)


def break_even(D, L, R):
    B, r = D - R, L - R
    return (B + r - 1) // r


def main():
    t17a = 0
    for D in range(1, 10):
        for R in range(0, D + 1):
            for T in range(2, 8):
                for first in range(3):
                    for target in range(3):
                        oc = online_cost(D, R, T, first, target)
                        cc = clairvoyant_cost(D, R, T)
                        assert cc <= oc
                        if first != target:
                            assert oc - cc == D - R
                        t17a += 1

    t17b = 0
    for R in range(0, 6):
        for L in range(R + 1, 10):
            for D in range(L, 16):
                k0 = break_even(D, L, R)
                assert k0 >= 1
                assert (k0 - 1) * (L - R) < D - R <= k0 * (L - R)
                for T in range(1, k0 + 6):
                    c = buy_at_cost(D, L, R, k0, T)
                    opt = offline_opt(D, L, R, T)
                    assert c <= 2 * opt
                    if T < k0:
                        assert c == opt
                    t17b += 1

    # T17c discrete optimum check: worst ratio for k occurs at T = k,
    # and optimal k lies in {floor(B/r), ceil(B/r)}.
    t17c_opt = 0
    for R in range(0, 4):
        for L in range(R + 1, 8):
            for D in range(L, 16):
                B, r = D - R, L - R
                k_floor = B // r
                k_ceil = (B + r - 1) // r
                candidates = {k_floor, k_ceil}
                best_ratio = None
                best_ks = set()
                for k in range(1, k_ceil + 5):
                    worst = max(Fraction(buy_at_cost(D, L, R, k, T), offline_opt(D, L, R, T))
                                for T in range(1, k + 8))
                    assert worst == Fraction(buy_at_cost(D, L, R, k, k), offline_opt(D, L, R, k))
                    if best_ratio is None or worst < best_ratio:
                        best_ratio = worst
                        best_ks = {k}
                    elif worst == best_ratio:
                        best_ks.add(k)
                assert best_ks & candidates
                t17c_opt += 1

    print("PASS CRTT-T17-v0.1 finite arithmetic cross-check")
    print("T17a cases:", t17a)
    print("T17b cases:", t17b)
    print("T17c optimum cases:", t17c_opt)


if __name__ == "__main__":
    main()
