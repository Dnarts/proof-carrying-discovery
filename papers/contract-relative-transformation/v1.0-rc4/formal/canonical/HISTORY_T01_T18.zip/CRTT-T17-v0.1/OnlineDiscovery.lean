/-
  CRTT-T17-v0.1 — OnlineDiscovery.lean
  Clean Lean 4 (no Mathlib, no Classical.choice, no sorryAx).
  Formalizes T17a (adversarial regret under unknown future method)
  and T17b (discrete online threshold & 2-competitiveness).
-/

namespace CRTT.OnlineDiscovery

/-- T17a: Cost of a deterministic online strategy choosing `first` on task 1,
    when tasks 2..T (for T ≥ 2) require hidden method `target`. -/
def onlineCost (D R T : Nat) (first target : Nat) : Nat :=
  if first = target then
    D + (T - 1) * R
  else
    2 * D + (T - 2) * R

/-- T17a: Clairvoyant (oracle) cost knowing `target` from task 1. -/
def clairvoyantCost (D R T : Nat) : Nat :=
  D + (T - 1) * R

/-- Clairvoyant cost is always ≤ online cost when R ≤ D and T ≥ 2. -/
theorem clairvoyant_optimal (D R T first target : Nat)
    (hRD : R ≤ D) (hT : 2 ≤ T) :
    clairvoyantCost D R T ≤ onlineCost D R T first target := by
  unfold clairvoyantCost onlineCost
  by_cases h : first = target
  · simp [h]
  · simp [h]
    have h1 : T - 1 = (T - 2) + 1 := by omega
    rw [h1, Nat.add_mul, Nat.one_mul]
    omega

/-- Adversarial regret: for any deterministic first choice, there exists a
    hidden target (distinct from `first`) whose regret is exactly D - R. -/
theorem adversarial_regret (D R T first : Nat)
    (hRD : R ≤ D) (hT : 2 ≤ T) :
    ∃ target : Nat, target ≠ first ∧
      onlineCost D R T first target - clairvoyantCost D R T = D - R := by
  refine ⟨first + 1, Nat.ne_of_gt (Nat.lt_succ_self first), ?_⟩
  unfold onlineCost clairvoyantCost
  -- A bare `simp` on the `if` over a `Nat` equality pulls in `Classical.choice`;
  -- discharging the side condition explicitly keeps the proof constructive.
  have hne : ¬ (first = first + 1) := by omega
  rw [ite_eq_right hne]
  have h1 : T - 1 = (T - 2) + 1 := by omega
  rw [h1, Nat.add_mul, Nat.one_mul]
  omega

/-- Exact two-task witness for T17a (T = 2, mismatched first choice). -/
theorem two_task_ratio_witness (D R first : Nat) :
    onlineCost D R 2 first (first + 1) = 2 * D ∧
    clairvoyantCost D R 2 = D + R := by
  unfold onlineCost clairvoyantCost
  have hne : ¬ (first = first + 1) := by omega
  rw [ite_eq_right hne]
  constructor <;> omega

/-! ### T17b: Discrete Ski-Rental / Online Threshold -/

/-- Offline optimum for T identical tasks with local cost L, discovery D, reuse R. -/
def offlineOpt (D L R T : Nat) : Nat :=
  T * R + min (T * (L - R)) (D - R)

/-- Cost of always solving locally. -/
def localAllCost (L T : Nat) : Nat := T * L

/-- Cost of opening the general method on task 1 and reusing thereafter (for T ≥ 1). -/
def openFirstCost (D R T : Nat) : Nat := D + (T - 1) * R

/-- Online threshold strategy: solve first (k - 1) tasks locally, open on task k. -/
def buyAtCost (D L R k T : Nat) : Nat :=
  if T < k then
    T * L
  else
    T * R + (D - R) + (k - 1) * (L - R)

/-- Break-even threshold k0 = ceil((D - R) / (L - R)) for r = L - R > 0. -/
def breakEven (D L R : Nat) : Nat :=
  let B := D - R
  let r := L - R
  (B + r - 1) / r

/-- Offline optimum is a lower bound on both pure strategies (T ≥ 1). -/
theorem offline_le_threshold (D L R T : Nat)
    (hRL : R ≤ L) (hLD : L ≤ D) (hT : 1 ≤ T) :
    offlineOpt D L R T ≤ localAllCost L T ∧
    offlineOpt D L R T ≤ openFirstCost D R T := by
  unfold offlineOpt localAllCost openFirstCost
  constructor
  · have hmin : min (T * (L - R)) (D - R) ≤ T * (L - R) := Nat.min_le_left _ _
    have hmul : T * R + T * (L - R) = T * L := by
      rw [← Nat.mul_add]
      have : R + (L - R) = L := by omega
      rw [this]
    omega
  · have hmin : min (T * (L - R)) (D - R) ≤ D - R := Nat.min_le_right _ _
    have hT1 : T = (T - 1) + 1 := by omega
    have hTR : T * R = (T - 1) * R + R := by
      conv => lhs; rw [hT1]
      rw [Nat.add_mul, Nat.one_mul]
    omega

/-- Offline optimum is attained by either all-local or open-first (T ≥ 1). -/
theorem offline_attained (D L R T : Nat)
    (hRL : R ≤ L) (hLD : L ≤ D) (hT : 1 ≤ T) :
    offlineOpt D L R T = localAllCost L T ∨
    offlineOpt D L R T = openFirstCost D R T := by
  unfold offlineOpt localAllCost openFirstCost
  by_cases h : T * (L - R) ≤ D - R
  · left
    rw [Nat.min_eq_left h, ← Nat.mul_add]
    have : R + (L - R) = L := by omega
    rw [this]
  · right
    have h' : D - R ≤ T * (L - R) := by omega
    rw [Nat.min_eq_right h']
    have hT1 : T = (T - 1) + 1 := by omega
    have hTR : T * R = (T - 1) * R + R := by
      conv => lhs; rw [hT1]
      rw [Nat.add_mul, Nat.one_mul]
    omega

/-- Specification of the integer break-even threshold k0. -/
theorem buyAt_spec (D L R : Nat) (hRL : R < L) (hLD : L ≤ D) :
    let k0 := breakEven D L R
    1 ≤ k0 ∧ (k0 - 1) * (L - R) < D - R ∧ D - R ≤ k0 * (L - R) := by
  dsimp only [breakEven]
  let B := D - R
  let r := L - R
  -- `omega` sees the goal in terms of `D - R` and `L - R`, not the `let`-bound
  -- `B` and `r`, so it treats them as unrelated atoms. `show` restates the goal
  -- in the `B`/`r` form so the division facts below actually connect.
  show 1 ≤ (B + r - 1) / r ∧ ((B + r - 1) / r - 1) * r < B ∧ B ≤ ((B + r - 1) / r) * r
  -- Positivity must be established from the original `D L R` hypotheses and
  -- named before any `div` fact is introduced. Stating `r ≤ B` and then letting
  -- `omega` attack a `div`/`mod` goal loses it: `omega` cannot handle the
  -- products `↑(a / b) * ↑r` obtained after casting to `Int`, so every division
  -- fact has to be pre-linearised and the product kept in `div_add_mod` order.
  have hBpos : 0 < B := by omega
  have hr : 0 < r := by omega
  have hB : r ≤ B := by omega
  have hdiv : 1 ≤ (B + r - 1) / r := Nat.div_pos (by omega) hr
  have hmod : r * ((B + r - 1) / r) + (B + r - 1) % r = B + r - 1 :=
    Nat.div_add_mod (B + r - 1) r
  have hmul_comm : ((B + r - 1) / r) * r = r * ((B + r - 1) / r) :=
    Nat.mul_comm _ _
  have hlt : (B + r - 1) % r < r := Nat.mod_lt (B + r - 1) hr
  have hdm : ((B + r - 1) / r) * r + (B + r - 1) % r = B + r - 1 := by
    rw [Nat.mul_comm]; exact Nat.div_add_mod _ _
  refine ⟨hdiv, ?_, ?_⟩
  · have hexp : ((B + r - 1) / r - 1) * r + r = ((B + r - 1) / r) * r := by
      have h1 : (B + r - 1) / r = ((B + r - 1) / r - 1) + 1 := by omega
      conv => rhs; rw [h1]
      rw [Nat.add_mul, Nat.one_mul]
    omega
  · omega

/-- Before the threshold (T < k0), buyAtCost matches the offline optimum. -/
theorem before_threshold (D L R T : Nat)
    (hRL : R < L) (hLD : L ≤ D) (hT : T < breakEven D L R) :
    buyAtCost D L R (breakEven D L R) T = offlineOpt D L R T := by
  unfold buyAtCost offlineOpt
  simp [hT]
  have hspec := buyAt_spec D L R hRL hLD
  have hle : T ≤ breakEven D L R - 1 := by omega
  have hmul : T * (L - R) ≤ (breakEven D L R - 1) * (L - R) :=
    Nat.mul_le_mul_right (L - R) hle
  have hmin : T * (L - R) ≤ D - R := by omega
  rw [Nat.min_eq_left hmin, ← Nat.mul_add]
  have : R + (L - R) = L := by omega
  rw [this]

/-- At or after the threshold (T ≥ k), exact delay penalty relative to open-first. -/
theorem after_threshold (D L R k T : Nat)
    (hRL : R ≤ L) (hLD : L ≤ D) (hk : 1 ≤ k) (hT : k ≤ T) :
    buyAtCost D L R k T = openFirstCost D R T + (k - 1) * (L - R) := by
  unfold buyAtCost openFirstCost
  have hnot : ¬ T < k := by omega
  simp [hnot]
  have hT1 : T = (T - 1) + 1 := by omega
  have hTR : T * R = (T - 1) * R + R := by
    conv => lhs; rw [hT1]
    rw [Nat.add_mul, Nat.one_mul]
  omega

/-- Break-even threshold strategy is 2-competitive: buyAtCost ≤ 2 * offlineOpt. -/
theorem buyAt_two_competitive (D L R T : Nat)
    (hRL : R < L) (hLD : L ≤ D) :
    buyAtCost D L R (breakEven D L R) T ≤ 2 * offlineOpt D L R T := by
  by_cases hT : T < breakEven D L R
  · rw [before_threshold D L R T hRL hLD hT]
    omega
  · have hspec := buyAt_spec D L R hRL hLD
    have hge : breakEven D L R ≤ T := by omega
    have hmul : breakEven D L R * (L - R) ≤ T * (L - R) :=
      Nat.mul_le_mul_right (L - R) hge
    have hB : D - R ≤ T * (L - R) := by omega
    unfold buyAtCost offlineOpt
    simp [hT]
    rw [Nat.min_eq_right hB]
    omega

#print axioms clairvoyant_optimal
#print axioms adversarial_regret
#print axioms two_task_ratio_witness
#print axioms offline_le_threshold
#print axioms offline_attained
#print axioms buyAt_spec
#print axioms before_threshold
#print axioms after_threshold
#print axioms buyAt_two_competitive

end CRTT.OnlineDiscovery
