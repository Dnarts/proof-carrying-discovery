"""Independent finite arithmetic cross-check for CRTT-T18-v0.1."""
from itertools import product


def check_all():
    # 3 scenarios, 3 actions, costs in {0, 1, 2} -> 3^9 = 19683 matrices
    partitions = [
        (0, 0, 0),
        (0, 0, 1),
        (0, 1, 0),
        (1, 0, 0),
        (0, 1, 2),
    ]
    t18_1 = t18_6 = t18_3 = t18_4 = 0

    for flat in product((0, 1, 2), repeat=9):
        # cost[a][w]
        cost = [flat[3*a:3*a+3] for a in range(3)]
        opt = [min(cost[a][w] for a in range(3)) for w in range(3)]
        reg = [[cost[a][w] - opt[w] for w in range(3)] for a in range(3)]

        vals = {}
        for p in partitions:
            fibers = {}
            for w, z in enumerate(p):
                fibers.setdefault(z, []).append(w)
            val = max(min(max(reg[a][w] for w in ws) for a in range(3)) for ws in fibers.values())
            vals[p] = val
            t18_1 += 1

            for eps in (0, 1, 2):
                lhs = (val <= eps)
                rhs = all(any(all(reg[a][w] <= eps for w in ws) for a in range(3)) for ws in fibers.values())
                assert lhs == rhs
                t18_6 += 1

        # Refinement monotonicity
        for p_coarse in partitions:
            for p_fine in partitions:
                if all(p_coarse[i] == p_coarse[j] for i in range(3) for j in range(3) if p_fine[i] == p_fine[j]):
                    assert vals[p_fine] <= vals[p_coarse]
                    t18_3 += 1
                    for c_obs in (0, 1, 2):
                        assert (c_obs + vals[p_fine] < vals[p_coarse]) == (c_obs < vals[p_coarse] - vals[p_fine])
                        t18_4 += 1

    print("PASS CRTT-T18-v0.1 finite arithmetic cross-check")
    print("T18.1 layer decomposition:", t18_1)
    print("T18.6 epsilon-sufficiency:", t18_6)
    print("T18.3 refinement monotonicity:", t18_3)
    print("T18.4 paid observation:", t18_4)


if __name__ == "__main__":
    check_all()
