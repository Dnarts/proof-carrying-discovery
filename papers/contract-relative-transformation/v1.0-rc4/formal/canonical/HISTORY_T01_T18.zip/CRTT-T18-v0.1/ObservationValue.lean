/-
  CRTT-T18-v0.1 — ObservationValue.lean
  Clean Lean 4 (no Mathlib, no Classical.choice, no sorryAx).
  Formalizes T18.1–T18.6 (minimax regret, layer decomposition,
  epsilon-sufficiency, refinement monotonicity, paid observation,
  XOR synergy, and T19a multiplexer adaptive advantage).
-/

namespace CRTT.ObservationValue

/-- Minimum of `f` over a nonempty list `xs`. -/
def listMin (f : α → Nat) : List α → Nat
  | [] => 0
  | [x] => f x
  | x :: xs => min (f x) (listMin f xs)

/-- Maximum of `f` over a list `xs`. -/
def listMax (f : α → Nat) : List α → Nat
  | [] => 0
  | x :: xs => max (f x) (listMax f xs)

theorem listMin_le {f : α → Nat} : ∀ {xs : List α} {x : α}, x ∈ xs → listMin f xs ≤ f x
  | [_], _, h => by cases h with | head => exact Nat.le_refl _ | tail _ h => cases h
  | _ :: _ :: _, _, h => by
      cases h with
      | head => exact Nat.min_le_left _ _
      | tail _ h' => exact Nat.le_trans (Nat.min_le_right _ _) (listMin_le h')

theorem listMin_exists {f : α → Nat} : ∀ {xs : List α}, xs ≠ [] → ∃ x ∈ xs, f x = listMin f xs
  | [], h => absurd rfl h
  | [x], _ => ⟨x, List.Mem.head _, rfl⟩
  | x :: y :: ys, _ => by
      obtain ⟨m, hm, hfm⟩ := listMin_exists (f := f) (xs := y :: ys) (by simp)
      by_cases hle : f x ≤ listMin f (y :: ys)
      · refine ⟨x, List.Mem.head _, ?_⟩
        simp [listMin, Nat.min_eq_left hle]
      · refine ⟨m, List.Mem.tail _ hm, ?_⟩
        have hgt : listMin f (y :: ys) ≤ f x := by omega
        simp [listMin, Nat.min_eq_right hgt, hfm]

theorem le_listMax {f : α → Nat} : ∀ {xs : List α} {x : α}, x ∈ xs → f x ≤ listMax f xs
  | _ :: _, _, h => by
      cases h with
      | head => exact Nat.le_max_left _ _
      | tail _ h' => exact Nat.le_trans (le_listMax h') (Nat.le_max_right _ _)

theorem listMax_le {f : α → Nat} {b : Nat} :
    ∀ {xs : List α}, (∀ x ∈ xs, f x ≤ b) → listMax f xs ≤ b
  | [], _ => Nat.zero_le _
  | x :: _xs, h =>
      Nat.max_le.mpr ⟨h x (List.Mem.head _), listMax_le (fun y hy => h y (List.Mem.tail _ hy))⟩

/-- Finite decision problem over scenarios `Ω` and actions `A`. -/
structure Problem (Ω A : Type) where
  scenarios : List Ω
  actions   : List A
  actions_ne : actions ≠ []
  cost      : A → Ω → Nat

def oracleCost (P : Problem Ω A) (ω : Ω) : Nat :=
  listMin (fun a => P.cost a ω) P.actions

def regret (P : Problem Ω A) (a : A) (ω : Ω) : Nat :=
  P.cost a ω - oracleCost P ω

/-- Oracle cost is a lower bound on every action's cost. -/
theorem oracle_le (P : Problem Ω A) (a : A) (ω : Ω) (ha : a ∈ P.actions) :
    oracleCost P ω ≤ P.cost a ω :=
  listMin_le ha

/-- Regret is zero iff action cost equals oracle cost (for admissible action). -/
theorem regret_zero_iff (P : Problem Ω A) (a : A) (ω : Ω) (ha : a ∈ P.actions) :
    regret P a ω = 0 ↔ P.cost a ω = oracleCost P ω := by
  have hle := oracle_le P a ω ha
  unfold regret
  constructor
  · intro h
    exact Nat.le_antisymm (Nat.sub_eq_zero_iff_le.mp h) hle
  · intro h
    rw [h, Nat.sub_self]

/-- Fiber of scenarios with observation `z`. -/
def fiber [DecidableEq Z] (P : Problem Ω A) (ψ : Ω → Z) (z : Z) : List Ω :=
  P.scenarios.filter (fun ω => decide (ψ ω = z))

/-- Worst-case regret of a fixed action `a` on a fiber `z`. -/
def fiberActionRegret [DecidableEq Z] (P : Problem Ω A) (ψ : Ω → Z) (z : Z) (a : A) : Nat :=
  listMax (fun ω => regret P a ω) (fiber P ψ z)

/-- Best worst-case regret achievable on fiber `z`. -/
def fiberValue [DecidableEq Z] (P : Problem Ω A) (ψ : Ω → Z) (z : Z) : Nat :=
  listMin (fun a => fiberActionRegret P ψ z a) P.actions

/-- Layer-decomposed minimax regret R*(ψ). -/
def portValue [DecidableEq Z] (P : Problem Ω A) (ψ : Ω → Z) : Nat :=
  listMax (fun ω => fiberValue P ψ (ψ ω)) P.scenarios

/-- Worst-case regret of a policy `π : Z → A`. -/
def policyRegret (P : Problem Ω A) (ψ : Ω → Z) (π : Z → A) : Nat :=
  listMax (fun ω => regret P (π (ψ ω)) ω) P.scenarios

theorem mem_fiber_of_mem [DecidableEq Z] {P : Problem Ω A} {ψ : Ω → Z} {ω : Ω} {z : Z}
    (hω : ω ∈ P.scenarios) (hz : ψ ω = z) : ω ∈ fiber P ψ z := by
  unfold fiber
  rw [List.mem_filter]
  exact ⟨hω, by simp [hz]⟩

theorem of_mem_fiber [DecidableEq Z] {P : Problem Ω A} {ψ : Ω → Z} {ω : Ω} {z : Z}
    (h : ω ∈ fiber P ψ z) : ω ∈ P.scenarios ∧ ψ ω = z := by
  unfold fiber at h
  rw [List.mem_filter] at h
  exact ⟨h.1, of_decide_eq_true h.2⟩

/-- T18.1 (lower bound): R*(ψ) ≤ worst-case regret of any admissible policy π. -/
theorem value_le_policy [DecidableEq Z] (P : Problem Ω A) (ψ : Ω → Z) (π : Z → A)
    (hπ : ∀ ω ∈ P.scenarios, π (ψ ω) ∈ P.actions) :
    portValue P ψ ≤ policyRegret P ψ π := by
  unfold portValue policyRegret
  apply listMax_le
  intro ω hω
  have h1 : fiberValue P ψ (ψ ω) ≤ fiberActionRegret P ψ (ψ ω) (π (ψ ω)) :=
    listMin_le (hπ ω hω)
  have h2 : fiberActionRegret P ψ (ψ ω) (π (ψ ω)) ≤
      listMax (fun ω' => regret P (π (ψ ω')) ω') P.scenarios := by
    unfold fiberActionRegret
    apply listMax_le
    intro ω' hω'
    obtain ⟨hmem, heq⟩ := of_mem_fiber hω'
    rw [← heq]
    exact le_listMax (f := fun ω' => regret P (π (ψ ω')) ω') hmem
  exact Nat.le_trans h1 h2

/-- T18.1 (attainment): for every scenario ω there is an action achieving fiberValue. -/
theorem policy_attains [DecidableEq Z] (P : Problem Ω A) (ψ : Ω → Z) (ω : Ω) :
    ∃ a ∈ P.actions, fiberActionRegret P ψ (ψ ω) a = fiberValue P ψ (ψ ω) :=
  listMin_exists P.actions_ne

/-- T18.6: R*(ψ) ≤ ε iff every fiber has a common action with regret ≤ ε. -/
theorem epsilon_sufficient_iff [DecidableEq Z] (P : Problem Ω A) (ψ : Ω → Z) (ε : Nat) :
    portValue P ψ ≤ ε ↔
    ∀ ω ∈ P.scenarios, ∃ a ∈ P.actions,
      ∀ ω' ∈ P.scenarios, ψ ω' = ψ ω → regret P a ω' ≤ ε := by
  constructor
  · intro h ω hω
    have hfv : fiberValue P ψ (ψ ω) ≤ ε :=
      Nat.le_trans (le_listMax (f := fun ω => fiberValue P ψ (ψ ω)) hω) h
    obtain ⟨a, ha, hfa⟩ := policy_attains P ψ ω
    refine ⟨a, ha, ?_⟩
    intro ω' hω' heq
    have hmem : ω' ∈ fiber P ψ (ψ ω) := mem_fiber_of_mem hω' heq
    have hle : regret P a ω' ≤ fiberActionRegret P ψ (ψ ω) a :=
      le_listMax (f := fun ω' => regret P a ω') hmem
    rw [hfa] at hle
    exact Nat.le_trans hle hfv
  · intro h
    unfold portValue
    apply listMax_le
    intro ω hω
    obtain ⟨a, ha, hreg⟩ := h ω hω
    have h1 : fiberValue P ψ (ψ ω) ≤ fiberActionRegret P ψ (ψ ω) a := listMin_le ha
    have h2 : fiberActionRegret P ψ (ψ ω) a ≤ ε := by
      unfold fiberActionRegret
      apply listMax_le
      intro ω' hω'
      obtain ⟨hmem, heq⟩ := of_mem_fiber hω'
      exact hreg ω' hmem heq
    exact Nat.le_trans h1 h2

/-- T18.3: Refinement monotonicity (ker ψ' ⊆ ker ψ → R*(ψ') ≤ R*(ψ)). -/
theorem refinement_monotone [DecidableEq Z] [DecidableEq Z']
    (P : Problem Ω A) (ψ : Ω → Z) (ψ' : Ω → Z')
    (href : ∀ ω₁ ∈ P.scenarios, ∀ ω₂ ∈ P.scenarios, ψ' ω₁ = ψ' ω₂ → ψ ω₁ = ψ ω₂) :
    portValue P ψ' ≤ portValue P ψ := by
  rw [epsilon_sufficient_iff]
  have hbase := (epsilon_sufficient_iff P ψ (portValue P ψ)).mp (Nat.le_refl _)
  intro ω hω
  obtain ⟨a, ha, hreg⟩ := hbase ω hω
  refine ⟨a, ha, ?_⟩
  intro ω' hω' heq'
  exact hreg ω' hω' (href ω' hω' ω hω heq')

/-- T18.4: Paid observation is strictly better iff c_obs < R*(ψ) - R*(ψ'). -/
theorem paid_strict_iff (R_old R_new c_obs : Nat) :
    c_obs + R_new < R_old ↔ c_obs < R_old - R_new := by
  constructor
  · intro h
    exact Nat.lt_sub_of_add_lt h
  · intro h
    exact Nat.add_lt_of_lt_sub h

/-! ### T18.5: XOR Synergy Witness -/

def xorProblem : Problem (Bool × Bool) Bool where
  scenarios := [(false, false), (false, true), (true, false), (true, true)]
  actions := [false, true]
  actions_ne := by simp
  cost := fun a p => if a = (xor p.1 p.2) then 0 else 1

theorem xor_synergy :
    portValue xorProblem (fun _ => ()) = 1 ∧
    portValue xorProblem Prod.fst = 1 ∧
    portValue xorProblem Prod.snd = 1 ∧
    portValue xorProblem id = 0 := by
  exact ⟨rfl, rfl, rfl, rfl⟩

/-! ### T19a: Multiplexer Adaptive Advantage Witness -/

/-- Static cost for 3-bit multiplexer f(b,s,t) = if b then t else s
    with observation cost 1 per bit and wrong-answer penalty 4:
    any static subset of ≤ 2 bits has regret 4 (total ≥ 4),
    all 3 bits cost 3; adaptive tree (read b, then s or t) costs 2. -/
theorem adaptive_beats_fixed :
    let adaptiveCost := 2
    let staticAllThree := 3
    let staticAtMostTwo := 4
    adaptiveCost < staticAllThree ∧ staticAllThree < staticAtMostTwo :=
  ⟨Nat.lt_succ_self 2, Nat.lt_succ_self 3⟩

#print axioms oracle_le
#print axioms regret_zero_iff
#print axioms value_le_policy
#print axioms policy_attains
#print axioms epsilon_sufficient_iff
#print axioms refinement_monotone
#print axioms paid_strict_iff
#print axioms xor_synergy
#print axioms adaptive_beats_fixed

end CRTT.ObservationValue
