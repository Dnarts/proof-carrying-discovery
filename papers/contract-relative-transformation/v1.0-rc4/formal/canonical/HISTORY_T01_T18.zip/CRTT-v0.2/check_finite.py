"""Independent finite arithmetic cross-check; not a Lean proof or a kernel check."""
from itertools import product, combinations
from collections import Counter

E = (0, 1)
libs = [frozenset(e for e, flag in zip(E, bits) if flag) for bits in product((0, 1), repeat=len(E))]
traces = [t for n in range(3) for t in product(E, repeat=n)]
plans = [p for n in range(4) for p in product(traces, repeat=n)]
rates = [(d, r) for d in range(4) for r in range(d+1)]


def trace_cost(trace, lib, d, r):
    lib = set(lib)
    total = 0
    for e in trace:
        total += (r if e in lib else d)[e]
        lib.add(e)
    return total


def cost_pair(plan, d, r, initial=frozenset()):
    global_lib = set(initial)
    independent = cumulative = ledger_saving = 0
    for trace in plan:
        independent += trace_cost(trace, (), d, r)
        cumulative += trace_cost(trace, global_lib, d, r)
        ledger_saving += sum(d[e] - r[e] for e in set(trace) & global_lib)
        global_lib.update(trace)
    return independent, cumulative, ledger_saving


def main():
    monotone = ledgers = counted = 0
    for rr in product(rates, repeat=len(E)):
        d, r = zip(*rr)
        for small in libs:
            for big in libs:
                if small <= big:
                    for trace in traces:
                        assert trace_cost(trace, big, d, r) <= trace_cost(trace, small, d, r)
                        monotone += 1
        for plan in plans:
            for initial in libs:
                i, c, s = cost_pair(plan, d, r, initial)
                assert i == c + s
                ledgers += 1
                if not initial:
                    count = Counter(e for task in plan for e in set(task))
                    formula = sum(max(0, n - 1) * (d[e] - r[e]) for e, n in count.items())
                    assert s == formula
                    counted += 1
    # Separate small optimization test: all pairs of feasible plans over two tasks,
    # for all rate combinations. Compare actual minima with the slack criterion.
    opt = 0
    small_plans = list(product(traces[:3], repeat=2))
    for rr in product(rates, repeat=len(E)):
        d, r = zip(*rr)
        for p, q in combinations(small_plans, 2):
            costs = [cost_pair(x, d, r) for x in (p, q)]
            i0 = min(v[0] for v in costs)
            c0 = min(v[1] for v in costs)
            assert (c0 < i0) == any(s > i-i0 for i, c, s in costs)
            opt += 1
    d, r = (6, 4, 4), (2, 4, 4)
    example = {str(p): cost_pair(p, d, r) for p in product(((0,), (1,)), ((0,), (2,)))}
    assert example['((0,), (0,))'] == (12, 8, 4)
    assert min(v[0] for v in example.values()) == min(v[1] for v in example.values()) == 8
    assert trace_cost((0,), {0}, (5, 5), (1, 1))+1 <= 2
    assert trace_cost((0,), {0, 1}, (5, 5), (1, 1))+2 > 2
    print('PASS finite arithmetic cross-check; no Lean kernel execution')
    print('T14 monotonic trace cases:', monotone)
    print('T15 accounting cases (including nonempty initial libraries):', ledgers)
    print('T15 cross-task count formula, empty initial library:', counted)
    print('T15 optimization equivalence cases:', opt)
    print('T15 counterexample (independent, cumulative, saving):', example)
    print('T16 mandatory lookup counterexample: cost 2 -> 3, budget 2')

if __name__ == '__main__':
    main()
