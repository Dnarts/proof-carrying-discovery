import Std
import Lean

/-!
Executable finite selector without Mathlib or classical choice.
Finite enumerations are explicit, and their completeness is a proof premise.
Source draft; kernel verification has not been executed in this environment.
-/
namespace CRTT.Finite

universe u v w
variable {X : Type u} {Z : Type v} {A : Type w} [DecidableEq Z]

/-- Boolean executable universal test restricted to an observation fibre. -/
def checkFiber (observe : X → Z) (valid : X → A → Bool) (z : Z) (a : A) : List X → Bool
  | [] => true
  | x :: xs => (if observe x = z then valid x a else true) &&
      checkFiber observe valid z a xs

theorem checkFiber_iff (observe : X → Z) (valid : X → A → Bool) (z : Z) (a : A)
    (worlds : List X) : checkFiber observe valid z a worlds = true ↔
    ∀ x, x ∈ worlds → observe x = z → valid x a = true := by
  induction worlds with
  | nil => simp [checkFiber]
  | cons y ys ih =>
    simp only [checkFiber, Bool.and_eq_true, ih]
    constructor
    · rintro ⟨hy, hys⟩ x hx hz
      rcases List.mem_cons.mp hx with hxy | hmem
      · subst x
        simpa [hz] using hy
      · exact hys x hmem hz
    · intro h
      constructor
      · by_cases hy : observe y = z
        · simpa [hy] using h y (List.mem_cons.mpr (Or.inl rfl)) hy
        · simp [hy]
      · intro x hx hz
        exact h x (List.mem_cons.mpr (Or.inr hx)) hz

/-- Deterministic first satisfying candidate; no choice axiom in execution. -/
def firstPassing (test : A → Bool) : List A → Option A
  | [] => none
  | a :: rest => if test a then some a else firstPassing test rest

theorem firstPassing_sound (test : A → Bool) (actions : List A) (a : A)
    (h : firstPassing test actions = some a) : a ∈ actions ∧ test a = true := by
  induction actions with
  | nil => simp [firstPassing] at h
  | cons b bs ih =>
    by_cases hb : test b = true
    · have heq : b = a := Option.some.inj (by simpa [firstPassing, hb] using h)
      subst a
      exact ⟨List.mem_cons.mpr (Or.inl rfl), hb⟩
    · have hrec : firstPassing test bs = some a := by simpa [firstPassing, hb] using h
      obtain ⟨hm, ht⟩ := ih hrec
      exact ⟨List.mem_cons.mpr (Or.inr hm), ht⟩

theorem firstPassing_complete (test : A → Bool) (actions : List A)
    (h : ∃ a, a ∈ actions ∧ test a = true) : ∃ a, firstPassing test actions = some a := by
  induction actions with
  | nil => simp at h
  | cons b bs ih =>
    by_cases hb : test b = true
    · exact ⟨b, by simp [firstPassing, hb]⟩
    · obtain ⟨a, ha, ht⟩ := h
      have hm : a ∈ bs := by
        rcases List.mem_cons.mp ha with heq | hm
        · subst a
          exact False.elim (hb ht)
        · exact hm
      obtain ⟨c, hc⟩ := ih ⟨a, hm, ht⟩
      exact ⟨c, by simpa [firstPassing, hb] using hc⟩

def select (observe : X → Z) (valid : X → A → Bool)
    (worlds : List X) (actions : List A) (z : Z) : Option A :=
  firstPassing (fun a => checkFiber observe valid z a worlds) actions

theorem select_safe (observe : X → Z) (valid : X → A → Bool)
    (worlds : List X) (completeWorlds : ∀ x : X, x ∈ worlds)
    (actions : List A) (x : X) (a : A)
    (h : select observe valid worlds actions (observe x) = some a) :
    a ∈ actions ∧ valid x a = true := by
  obtain ⟨hm, ht⟩ := firstPassing_sound
    (fun a => checkFiber observe valid (observe x) a worlds) actions a h
  exact ⟨hm, (checkFiber_iff observe valid (observe x) a worlds).mp ht x (completeWorlds x) rfl⟩

theorem select_complete (observe : X → Z) (valid : X → A → Bool)
    (worlds : List X) (actions : List A) (completeActions : ∀ a : A, a ∈ actions)
    (z : Z) (h : ∃ a : A, ∀ x : X, observe x = z → valid x a = true) :
    ∃ a, select observe valid worlds actions z = some a := by
  obtain ⟨a, ha⟩ := h
  apply firstPassing_complete
  exact ⟨a, completeActions a, (checkFiber_iff observe valid z a worlds).mpr
    (fun x _ hx => ha x hx)⟩

/-- Explicit complete truth table: two incompatible worlds, one common observation. -/
example : select (fun _ : Bool => false) (fun x a : Bool => x == a)
    [false, true] [false, true] false = none := by decide

example : select (fun x : Bool => x) (fun x a : Bool => x == a)
    [false, true] [false, true] true = some true := by decide

end CRTT.Finite

#print axioms CRTT.Finite.select_safe
#print axioms CRTT.Finite.select_complete
