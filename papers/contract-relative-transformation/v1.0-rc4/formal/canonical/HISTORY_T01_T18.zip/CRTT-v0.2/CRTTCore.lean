import Std

/-!
Domain-independent logical core of contract-relative transformations.
This is a Lean source draft, not a machine-verified release.
No neural-network, storage, probability or numerical assumptions are used.
The relation `ok` is semantic: its decidability and operational cost are
separate obligations for an executable experiment.
-/

namespace CRTT

universe u v w t

/-- Each observed fibre has a single action valid for every member. -/
def FiberSufficient {X : Type u} {Z : Type v} {A : Type w}
    (observe : X → Z) (ok : X → A → Prop) : Prop :=
  ∀ z : Z, (∃ x : X, observe x = z) →
    ∃ a : A, ∀ x : X, observe x = z → ok x a

/-- A total deterministic policy solves every instance. -/
def Solves {X : Type u} {Z : Type v} {A : Type w}
    (observe : X → Z) (ok : X → A → Prop) (policy : Z → A) : Prop :=
  ∀ x : X, ok x (policy (observe x))

/-- Classical existence, not a claim of efficient synthesis. -/
theorem selector_iff {X : Type u} {Z : Type v} {A : Type w}
    [Nonempty A] (observe : X → Z) (ok : X → A → Prop) :
    (∃ policy : Z → A, Solves observe ok policy) ↔
      FiberSufficient observe ok := by
  classical
  constructor
  · intro h z hz
    obtain ⟨policy, hp⟩ := h
    refine ⟨policy z, ?_⟩
    intro x hx
    rw [← hx]
    exact hp x
  · intro h
    let policy : Z → A := fun z =>
      if hz : ∃ x : X, observe x = z then
        Classical.choose (h z hz)
      else Classical.choice (inferInstance : Nonempty A)
    refine ⟨policy, ?_⟩
    intro x
    have hx : ∃ y : X, observe y = observe x := ⟨x, rfl⟩
    change ok x (policy (observe x))
    simp only [policy, dite_eq_left hx]
    exact Classical.choose_spec (h (observe x) hx) x rfl

/-- A policy observing a refinement can simulate a policy on the old port. -/
theorem refine_policy {X : Type u} {Z : Type v} {Z' : Type t}
    {A : Type w} (old : X → Z) (new : X → Z') (decode : Z' → Z)
    (hdecode : ∀ x, old x = decode (new x)) (ok : X → A → Prop)
    (policy : Z → A) (hp : Solves old ok policy) :
    Solves new ok (fun z => policy (decode z)) := by
  intro x
  change ok x (policy (decode (new x)))
  rw [← hdecode x]
  exact hp x

/-- Feasibility of one observation class; empty classes are immaterial. -/
def FiberAdmissible {X : Type u} {Z : Type v} {A : Type w}
    (observe : X → Z) (ok : X → A → Prop) (z : Z) : Prop :=
  ∃ a : A, ∀ x : X, observe x = z → ok x a

/-- None means no compact action is issued; it is not task success. -/
def SafePartial {X : Type u} {Z : Type v} {A : Type w}
    (observe : X → Z) (ok : X → A → Prop) (policy : Z → Option A) : Prop :=
  ∀ (x : X) (a : A), policy (observe x) = some a → ok x a

/-- An information-theoretic oracle policy, not an executable controller. -/
noncomputable def maximalSelector {X : Type u} {Z : Type v} {A : Type w}
    (observe : X → Z) (ok : X → A → Prop) (z : Z) : Option A := by
  classical
  exact if h : FiberAdmissible observe ok z then some (Classical.choose h) else none

theorem maximalSelector_safe {X : Type u} {Z : Type v} {A : Type w}
    (observe : X → Z) (ok : X → A → Prop) :
    SafePartial observe ok (maximalSelector observe ok) := by
  classical
  intro x a ha
  by_cases h : FiberAdmissible observe ok (observe x)
  · have hsome : some (Classical.choose h) = some a := by
      simpa only [maximalSelector, dite_eq_left h] using ha
    have heq : Classical.choose h = a := Option.some.inj hsome
    rw [← heq]
    exact Classical.choose_spec h x rfl
  · simp [maximalSelector, h] at ha

/-- Any safely accepted fibre necessarily admits a common action. -/
theorem accepted_fiber_admissible {X : Type u} {Z : Type v} {A : Type w}
    (observe : X → Z) (ok : X → A → Prop) (policy : Z → Option A)
    (hp : SafePartial observe ok policy) (z : Z) (a : A)
    (ha : policy z = some a) : FiberAdmissible observe ok z := by
  refine ⟨a, ?_⟩
  intro x hx
  apply hp x a
  rw [hx]
  exact ha

/-- A safe policy cannot accept more observation classes than the oracle. -/
theorem maximalSelector_accepts {X : Type u} {Z : Type v} {A : Type w}
    (observe : X → Z) (ok : X → A → Prop) (z : Z) :
    (∃ a : A, maximalSelector observe ok z = some a) ↔
      FiberAdmissible observe ok z := by
  classical
  constructor
  · intro h
    obtain ⟨a, ha⟩ := h
    exact accepted_fiber_admissible observe ok (maximalSelector observe ok)
      (maximalSelector_safe observe ok) z a ha
  · intro h
    exact ⟨Classical.choose h, by simp only [maximalSelector, dite_eq_left h]⟩

/-- A family of contracts shares a single action, not a separate action per contract. -/
def JointOK {C : Type t} {X : Type u} {A : Type w}
    (ok : C → X → A → Prop) (family : C → Prop) (x : X) (a : A) : Prop :=
  ∀ c : C, family c → ok c x a

theorem joint_antitone {C : Type t} {X : Type u} {A : Type w}
    (ok : C → X → A → Prop) (small big : C → Prop)
    (h : ∀ c, small c → big c) (x : X) (a : A) :
    JointOK ok big x a → JointOK ok small x a := by
  intro hb c hc
  exact hb c (h c hc)

/-- A resource- or language-infeasible instance blocks every total policy. -/
theorem empty_action_barrier {X : Type u} {Z : Type v} {A : Type w}
    (observe : X → Z) (ok : X → A → Prop) (x : X)
    (h : ∀ a : A, ¬ ok x a) : ¬ ∃ policy : Z → A, Solves observe ok policy := by
  intro hpol
  obtain ⟨policy, hp⟩ := hpol
  exact h (policy (observe x)) (hp x)

/-- A collision with incompatible valid actions blocks every total policy. -/
theorem collision_barrier {X : Type u} {Z : Type v} {A : Type w}
    (observe : X → Z) (ok : X → A → Prop) (x y : X)
    (hsame : observe x = observe y)
    (h : ∀ a : A, ¬ (ok x a ∧ ok y a)) :
    ¬ ∃ policy : Z → A, Solves observe ok policy := by
  intro hpol
  obtain ⟨policy, hp⟩ := hpol
  apply h (policy (observe x))
  refine ⟨hp x, ?_⟩
  rw [hsame]
  exact hp y

end CRTT
