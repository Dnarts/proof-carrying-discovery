# CRTT v0.2 — research draft, not a verified release

## Scope

This is a domain-independent mathematical extension of the previous CRTT logical core. No neural networks, empirical outcomes, database formats, or implementation architecture are assumed. No change to CFR v1.0 is made.

- `CRTTCore.lean`: restored from the previously generated Library file, with `dif_pos` migrated to `dite_eq_left` (`dif_pos` is deprecated in Lean 4.36). No statement was changed.
- `FiniteSelector.lean`: explicit finite enumerations and Boolean validity checks, with proposed soundness/completeness proofs. Uses complete lists rather than Mathlib `Fintype`/`Finset`.
- `CumulativeDiscovery.lean`: typed safe configurations and licensed steps, a two-task transfer witness, ideal-library cost monotonicity, exact trace accounting, the corrected strict-optimum criterion, finite witnesses against the original T15 and for T16.
- `check_finite.py`, `FINITE_CHECK.log`: independently executable bounded arithmetic checks, not Lean certificates.

## Mathematical boundary

The ideal cost model fixes stable method identities, a common set of feasible plans, additive discovery/reuse costs, and no extra mandatory search/validation/holding cost. The library is updated after every method use; within-task reuse is permitted in both modes, but only cumulative accounting retains methods across tasks. The proofs do not establish that a black-box search algorithm can actually discover a valid method at the stipulated cost. A method's type alone does not prove transfer; `TransferWitness` explicitly requires two distinct tasks and actual licensed steps with strict coverage gain. Preparatory steps need not have immediate strict gain.

For a fixed plan p, independent cost = cumulative cost + cross-task savings. Strict optimal benefit is equivalent to existence of a feasible plan whose savings exceed its independent-optimality gap. An optimal cumulative plan containing a discounted repeat need not strictly beat the independent optimum. Mandatory lookup cost can invalidate monotonicity; optional free pruning/bypass can remove that counterexample.

The `SafeConfig` ambient world/action types and semantic validity are fixed for each task. Changes in available operators use an enabled subset of an ambient action type, and changes in observation may use a different carrier. Proof fields enforce safety and coverage preservation, not just the existence of propositions. The present extension type deliberately models a monotone step class only, not every possible non-monotone research transition. A complete dynamic controller, non-free lookup, pruning, probabilistic transfer, port and cost certificates remain open research tasks.

## Verification

Target toolchain for local verification: Lean 4.36.0 (`arm64-apple-darwin24.6.0`, commit `611c117`). These sources import only the Lean distribution (`Std`, `Lean`), not Mathlib.

**Status: all three sources compile under Lean 4.36.0 with exit 0 and zero diagnostics.** No `sorry`/`admit`/`native_decide` shortcuts are present; no `sorryAx` appears in any axiom report. Axiom audit for every `#print axioms` target:

| Theorem | Axioms |
| --- | --- |
| `CRTT.Finite.select_safe` | `propext, Quot.sound` |
| `CRTT.Finite.select_complete` | `propext, Quot.sound` |
| `CRTT.Cumulative.budgetReach_monotone` | `propext, Quot.sound` |
| `CRTT.Cumulative.plan_accounting` | `propext, Quot.sound` |
| `CRTT.Cumulative.strict_gain_iff` | `propext, Quot.sound` |
| `CRTT.Cumulative.Witnesses.repeat_not_sufficient` | `propext` |
| `CRTT.Cumulative.Witnesses.library_bloat_witness` | `propext` |

No theorem in this release depends on `Classical.choice`. The finite witnesses are constructive: `library_bloat_witness` proves list inclusion by explicit `List.Mem` case analysis, because the `simpa`/`decide` route through `List.Mem` and `BEq` is non-constructive in 4.36 and pulls in `Classical.choice`. The classical existence result in the original core is a separate, choice-free-unaffected matter.

```sh
lean --version
lean CRTTCore.lean
lean FiniteSelector.lean
lean CumulativeDiscovery.lean
python3 check_finite.py
shasum -a 256 -c SHA256SUMS.txt
```

Re-inspect the `#print axioms` output and all compiler diagnostics yourself; this release states what one toolchain reported, not a universal theorem. A successful Python check does not establish Lean compilation.

## Next proof gates

1. Verify/repair all three sources using the pinned compiler, retaining exact logs. Do not weaken a theorem to obtain compilation.
2. `SufficientPartitions`: greatest adequate partition iff compatibility is an equivalence relation with a common action per class, under nonempty local action sets; finite unrestricted class-count minimum = hitting set. Restrict accessible observation family separately.
3. `SelectiveCoverage`: typed partial selector, maximum coverage, disjoint barrier partition; higher-order incompatible fibres, not merely pairwise collisions.
4. `LocalInteractions`: assume a given hypergraph-local additive decomposition; prove vanishing Möbius terms not contained in any hyperedge. Do not infer locality from checking only low orders.
5. `ExponentialAggregation` (Mathlib branch): distinguish single normalized cluster from a mixture with other regions; prove the single-cluster bound and separate inter-cluster mass redistribution bound.
6. `CumulativeDiscovery`: formalize method application and validation costs, storage and retrieval, finite dynamic programming and online-vs-clairvoyant comparison. Do not use the ideal fixed-plan ledger as an online learning guarantee.

No claim of mathematical novelty, empirical transfer, or verified Lean release is made here.
