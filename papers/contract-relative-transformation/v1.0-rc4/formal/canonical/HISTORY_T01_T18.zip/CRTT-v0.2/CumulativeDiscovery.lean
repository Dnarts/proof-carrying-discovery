import Std
import Lean

/-!
CRTT-Cumulative: source draft for Lean 4.36.0, not kernel-checked here.
Ideal cost layer: fixed feasible plans, stable method identities, additive costs,
no mandatory lookup/holding/validation overhead and no deletion of methods.
Within a task both accounting modes may reuse methods; only the cumulative
mode carries the library across task boundaries.
-/

namespace CRTT.Cumulative

universe u v w

inductive BarrierClass where
  | operator | epistemic | algorithmic | resource | temporal
  deriving DecidableEq, Repr

/-- A configuration has a fixed world space and a fixed semantic contract.
    Observation type, enabled actions and policy can change. -/
structure SafeConfig (X : Type u) (A : Type v) (ok : X → A → Prop) where
  Z : Type w
  observe : X → Z
  enabled : X → A → Prop
  select : Z → Option A
  safe : ∀ x a, select (observe x) = some a → enabled x a ∧ ok x a

def Covered {X : Type u} {A : Type v} {ok : X → A → Prop}
    (s : SafeConfig.{u,v,w} X A ok) (x : X) : Prop :=
  ∃ a, s.select (s.observe x) = some a

/-- The new configuration is itself safe; this proof is separate from
    preservation of the coverage of the preceding configuration. -/
structure LicensedStep {X : Type u} {A : Type v} {ok : X → A → Prop}
    (before : SafeConfig.{u,v,w} X A ok) where
  after : SafeConfig.{u,v,w} X A ok
  preserves : ∀ x, Covered before x → Covered after x

def StrictGain {X : Type u} {A : Type v} {ok : X → A → Prop}
    {before : SafeConfig.{u,v,w} X A ok} (step : LicensedStep before) : Prop :=
  ∃ x, ¬ Covered before x ∧ Covered step.after x

/-- Applicability and coverage preservation are checked per task.
    Being typed on tasks alone does not prove transferability. -/
structure TaskFamily where
  Task : Type u
  X : Task → Type v
  A : Task → Type w
  ok : (i : Task) → X i → A i → Prop

/-- The observation carrier may vary while the task and its contract remain fixed.
    For this draft it lives in the same universe as the ambient action type. -/
abbrev Configuration (F : TaskFamily.{u,v,w}) (i : F.Task) :=
  SafeConfig.{v,w,w} (F.X i) (F.A i) (F.ok i)

/-- A partial, typed method: an issued step has actual proof fields. The semantic
    function alone does not establish executability or its claimed cost. -/
structure Extension (F : TaskFamily.{u,v,w}) where
  target : BarrierClass
  run : (i : F.Task) → (before : Configuration F i) → Option (LicensedStep before)
  costDisc : Nat
  costReuse : Nat
  reuse_le : costReuse ≤ costDisc

/-- Witness of strict coverage gain on two distinct tasks, not universality. -/
structure TransferWitness (F : TaskFamily.{u,v,w}) (e : Extension F) where
  first : F.Task
  second : F.Task
  distinct : first ≠ second
  beforeFirst : Configuration F first
  beforeSecond : Configuration F second
  stepFirst : LicensedStep beforeFirst
  stepSecond : LicensedStep beforeSecond
  appliedFirst : e.run first beforeFirst = some stepFirst
  appliedSecond : e.run second beforeSecond = some stepSecond
  gainFirst : StrictGain stepFirst
  gainSecond : StrictGain stepSecond

/-- A method identifier must refer to a fixed method and version. Here it is
    the element of E itself. The library is represented by List membership;
    duplicates are irrelevant in the ideal model. -/
def Included {E : Type u} (small big : List E) : Prop :=
  ∀ e, e ∈ small → e ∈ big

theorem included_cons {E : Type u} {small big : List E} (e : E)
    (h : Included small big) : Included (e :: small) (e :: big) := by
  intro a ha
  rcases List.mem_cons.mp ha with hEq | hMem
  · exact List.mem_cons.mpr (Or.inl hEq)
  · exact List.mem_cons.mpr (Or.inr (h a hMem))

section Cost
variable {E : Type u} [DecidableEq E]

/-- Discovery/reuse are full per-use costs in this ideal model. -/
def useCost (disc reuse : E → Nat) (lib : List E) (e : E) : Nat :=
  if e ∈ lib then reuse e else disc e

def traceCost (disc reuse : E → Nat) (lib : List E) : List E → Nat
  | [] => 0
  | e :: es => useCost disc reuse lib e + traceCost disc reuse (e :: lib) es

theorem useCost_antitone (disc reuse : E → Nat)
    (cheap : ∀ e, reuse e ≤ disc e) (small big : List E)
    (h : Included small big) (e : E) :
    useCost disc reuse big e ≤ useCost disc reuse small e := by
  by_cases hs : e ∈ small
  · have hb := h e hs
    simp [useCost, hs, hb]
  · by_cases hb : e ∈ big
    · simpa [useCost, hs, hb] using cheap e
    · simp [useCost, hs, hb]

theorem traceCost_antitone (disc reuse : E → Nat)
    (cheap : ∀ e, reuse e ≤ disc e) (steps : List E)
    (small big : List E) (h : Included small big) :
    traceCost disc reuse big steps ≤ traceCost disc reuse small steps := by
  induction steps generalizing small big with
  | nil => simp [traceCost]
  | cons e es ih =>
    exact Nat.add_le_add (useCost_antitone disc reuse cheap small big h e)
      (ih (e :: small) (e :: big) (included_cons e h))

/-- T14 for attainable targets, not just numeric costs. Feasibility must be
    independent of the library or monotone under extension. -/
def BudgetReach (disc reuse : E → Nat) (feasible : List E → Prop)
    (B : Nat) (lib : List E) : Prop :=
  ∃ steps, feasible steps ∧ traceCost disc reuse lib steps ≤ B

theorem budgetReach_monotone (disc reuse : E → Nat)
    (cheap : ∀ e, reuse e ≤ disc e) (feasible : List E → Prop)
    (B : Nat) (small big : List E) (h : Included small big) :
    BudgetReach disc reuse feasible B small → BudgetReach disc reuse feasible B big := by
  intro hReach
  obtain ⟨steps, hFeasible, hBudget⟩ := hReach
  exact ⟨steps, hFeasible, Nat.le_trans (traceCost_antitone disc reuse cheap steps small big h) hBudget⟩

/-- Cross-task savings occur only when a method was known globally but is
    still unknown in the library reset at the start of the current task. -/
def stepSaving (disc reuse : E → Nat) (globalLib localLib : List E) (e : E) : Nat :=
  if e ∈ globalLib ∧ e ∉ localLib then disc e - reuse e else 0

def traceSaving (disc reuse : E → Nat) (globalLib localLib : List E) : List E → Nat
  | [] => 0
  | e :: es => stepSaving disc reuse globalLib localLib e +
      traceSaving disc reuse (e :: globalLib) (e :: localLib) es

theorem useCost_accounting (disc reuse : E → Nat)
    (cheap : ∀ e, reuse e ≤ disc e) (globalLib localLib : List E)
    (h : Included localLib globalLib) (e : E) :
    useCost disc reuse localLib e =
      useCost disc reuse globalLib e + stepSaving disc reuse globalLib localLib e := by
  by_cases hl : e ∈ localLib
  · have hg := h e hl
    simp [useCost, stepSaving, hl, hg]
  · by_cases hg : e ∈ globalLib
    · have hc := cheap e
      simp [useCost, stepSaving, hl, hg] <;> omega
    · simp [useCost, stepSaving, hl, hg]

theorem traceCost_accounting (disc reuse : E → Nat)
    (cheap : ∀ e, reuse e ≤ disc e) (steps : List E)
    (globalLib localLib : List E) (h : Included localLib globalLib) :
    traceCost disc reuse localLib steps =
      traceCost disc reuse globalLib steps + traceSaving disc reuse globalLib localLib steps := by
  induction steps generalizing globalLib localLib with
  | nil => simp [traceCost, traceSaving]
  | cons e es ih =>
    simp only [traceCost, traceSaving]
    rw [useCost_accounting disc reuse cheap globalLib localLib h e,
        ih (e :: globalLib) (e :: localLib) (included_cons e h)] <;> omega

/-- One list of extension uses per task; reset the library at each boundary. -/
def independentCost (disc reuse : E → Nat) : List (List E) → Nat
  | [] => 0
  | steps :: rest => traceCost disc reuse [] steps + independentCost disc reuse rest

def cumulativeCost (disc reuse : E → Nat) (globalLib : List E) : List (List E) → Nat
  | [] => 0
  | steps :: rest => traceCost disc reuse globalLib steps +
      cumulativeCost disc reuse (steps ++ globalLib) rest

def planSaving (disc reuse : E → Nat) (globalLib : List E) : List (List E) → Nat
  | [] => 0
  | steps :: rest => traceSaving disc reuse globalLib [] steps +
      planSaving disc reuse (steps ++ globalLib) rest

/-- T15a: exact ledger identity even when a task uses a method repeatedly. -/
theorem plan_accounting (disc reuse : E → Nat)
    (cheap : ∀ e, reuse e ≤ disc e) (tasks : List (List E)) (globalLib : List E) :
    independentCost disc reuse tasks =
      cumulativeCost disc reuse globalLib tasks + planSaving disc reuse globalLib tasks := by
  induction tasks generalizing globalLib with
  | nil => simp [independentCost, cumulativeCost, planSaving]
  | cons steps rest ih =>
    have h : Included ([] : List E) globalLib := by
      intro e he
      simp at he
    simp only [independentCost, cumulativeCost, planSaving]
    rw [traceCost_accounting disc reuse cheap steps globalLib [] h, ih (steps ++ globalLib)] <;> omega

end Cost

/-- Optimization is over the same feasible plans, and minima are attained. -/
def IsOptimal {P : Type u} (feasible : P → Prop) (cost : P → Nat) (p : P) : Prop :=
  feasible p ∧ ∀ q, feasible q → cost p ≤ cost q

/-- T15b: the saving must exceed the plan's independent optimality gap.
    The inequality is written without truncated Nat subtraction. -/
theorem strict_gain_iff {P : Type u} (feasible : P → Prop)
    (indep cum saving : P → Nat)
    (ledger : ∀ p, feasible p → indep p = cum p + saving p)
    (i c : P) (_hi : IsOptimal feasible indep i) (hc : IsOptimal feasible cum c) :
    cum c < indep i ↔ ∃ p, feasible p ∧ indep p < indep i + saving p := by
  constructor
  · intro h
    refine ⟨c, hc.1, ?_⟩
    have hLedger := ledger c hc.1
    omega
  · rintro ⟨p, hp, hGain⟩
    have hLedger := ledger p hp
    have hMin := hc.2 p hp
    omega

/-- A strictly discounted repeat in an independently optimal plan is sufficient. -/
theorem independent_optimum_saving_suffices {P : Type u} (feasible : P → Prop)
    (indep cum saving : P → Nat)
    (ledger : ∀ p, feasible p → indep p = cum p + saving p)
    (i c : P) (hi : IsOptimal feasible indep i) (hc : IsOptimal feasible cum c)
    (positive : 0 < saving i) : cum c < indep i := by
  apply (strict_gain_iff feasible indep cum saving ledger i c hi hc).2
  exact ⟨i, hi.1, by omega⟩

namespace Witnesses

/-- Shared method 0 costs 6/2; private methods 1 and 2 cost 4/4. -/
def disc (e : Nat) : Nat := if e = 0 then 6 else 4
def reuse (e : Nat) : Nat := if e = 0 then 2 else 4

def shared : List (List Nat) := [[0], [0]]
def privatePlan : List (List Nat) := [[1], [2]]

example : independentCost disc reuse shared = 12 := by decide
example : cumulativeCost disc reuse [] shared = 8 := by decide
example : planSaving disc reuse [] shared = 4 := by decide
example : independentCost disc reuse privatePlan = 8 := by decide
example : cumulativeCost disc reuse [] privatePlan = 8 := by decide

/-- All four plans: choose shared/private independently on each task. -/
inductive Plan where
  | ss | sp | ps | pp
  deriving DecidableEq, Repr

def traces : Plan → List (List Nat)
  | .ss => shared
  | .sp => [[0], [2]]
  | .ps => [[1], [0]]
  | .pp => privatePlan

def indCost (p : Plan) := independentCost disc reuse (traces p)
def cumCost (p : Plan) := cumulativeCost disc reuse [] (traces p)
def save (p : Plan) := planSaving disc reuse [] (traces p)

/-- A cumulative optimum repeats a strictly discounted method, but the two
    optimal costs coincide. This refutes the proposed sufficient condition. -/
theorem repeat_not_sufficient :
    IsOptimal (fun _ : Plan => True) indCost .pp ∧
    IsOptimal (fun _ : Plan => True) cumCost .ss ∧
    0 < save .ss ∧ cumCost .ss = indCost .pp := by
  constructor
  · constructor
    · trivial
    · intro q _
      cases q <;> decide
  · constructor
    · constructor
      · trivial
      · intro q _
        cases q <;> decide
    · exact ⟨by decide, by decide⟩

/-- T16: mandatory scan cost; no free pruning or bypass. Method 0 is the
    only useful action. Libraries in this witness have distinct entries. -/
def chargedCost (lib : List Nat) : Nat := useCost (fun _ => 5) (fun _ => 1) lib 0 + lib.length

theorem library_bloat_witness :
    Included ([0] : List Nat) [0,1] ∧ chargedCost [0] ≤ 2 ∧ ¬ chargedCost [0,1] ≤ 2 := by
  constructor
  · intro e he
    cases he with
    | head => simp
    | tail _ h => cases h
  · exact ⟨by decide, by decide⟩

end Witnesses
end CRTT.Cumulative

#print axioms CRTT.Cumulative.budgetReach_monotone
#print axioms CRTT.Cumulative.plan_accounting
#print axioms CRTT.Cumulative.strict_gain_iff
#print axioms CRTT.Cumulative.Witnesses.repeat_not_sufficient
#print axioms CRTT.Cumulative.Witnesses.library_bloat_witness
