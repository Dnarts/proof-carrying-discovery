#!/usr/bin/env bash
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

LOG="crtt_kernel_audit_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

echo "=== TOOLCHAIN ==="
lean --version

check_pkg() {
  local dir="$1"
  shift
  echo ""
  echo "========================================"
  echo "PACKAGE: $dir"
  echo "========================================"
  if [ ! -d "$dir" ]; then
    echo "MISSING DIR: $dir (распакуй архив $dir рядом со скриптом)"
    return 1
  fi
  (
    cd "$dir" || exit 1
    if [ -f "SHA256SUMS.txt" ]; then
      echo "--- SHA256 ---"
      shasum -a 256 -c SHA256SUMS.txt
    fi
    for f in "$@"; do
      echo "--- LEAN: $f ---"
      lean "$f"
    done
    for py in check_*.py; do
      if [ -f "$py" ]; then
        echo "--- PYTHON: $py ---"
        python3 "$py"
      fi
    done
  )
}

check_pkg "CRTT-v0.2" CRTTCore.lean FiniteSelector.lean CumulativeDiscovery.lean
check_pkg "CRTT-T17-v0.1" OnlineDiscovery.lean
check_pkg "CRTT-T18-v0.1" ObservationValue.lean

echo ""
echo "=== DONE. Log saved to: $LOG ==="
