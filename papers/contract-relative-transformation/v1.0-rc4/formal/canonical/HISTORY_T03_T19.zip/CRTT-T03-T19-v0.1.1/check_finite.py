#!/usr/bin/env python3
"""Exact independent finite cross-check. Does not run or verify Lean."""
from functools import lru_cache
from itertools import product, permutations


def partitions(n):
    """Canonical restricted growth strings, including the empty partition."""
    def go(prefix):
        if len(prefix) == n:
            yield tuple(prefix)
        else:
            for z in range(max(prefix, default=-1) + 2):
                yield from go(prefix + [z])
    return list(go([]))


def refines(p, q):
    return all(p[i] != p[j] or q[i] == q[j]
               for i in range(len(p)) for j in range(len(p)))


def check_partitions():
    n, m = 4, 3
    ps = partitions(n)
    assert len(ps) == 15
    tested, exist, path, helly = 0, 0, 0, 0
    for rows in product(range(1 << m), repeat=n):
        def sufficient(p):
            for z in set(p):
                common = (1 << m) - 1
                for i in range(n):
                    if p[i] == z:
                        common &= rows[i]
                if common == 0:
                    return False
            return True
        good = [p for p in ps if sufficient(p)]
        greatest = [q for q in good if all(refines(p, q) for p in good)]
        comp = lambda i, j: bool(rows[i] & rows[j])
        equiv = all(comp(i, i) for i in range(n)) and all(
            not (comp(i, j) and comp(j, k)) or comp(i, k)
            for i, j, k in product(range(n), repeat=3))
        common_classes = True
        for i in range(n):
            common = (1 << m) - 1
            for j in range(n):
                if comp(i, j):
                    common &= rows[j]
            common_classes &= common != 0
        assert bool(greatest) == (equiv and common_classes), rows
        assert len(greatest) <= 1
        if greatest:
            q = greatest[0]
            assert all((q[i] == q[j]) == comp(i, j)
                       for i, j in product(range(n), repeat=2))
        exist += bool(greatest)
        tested += 1
        path += all(rows) and not equiv
        helly += equiv and not common_classes
    print(f'T03: {tested} validity relations, {len(ps)} partitions each; coarsest exists: {exist}; '
          f'nontransitive compatible relations (all worlds feasible): {path}; '
          f'equivalence without common class action: {helly}')
    assert path > 0 and helly > 0


@lru_cache(None)
def trees(ports):
    """All legal adaptive trees, no repeated port on a path."""
    return ((0,), (1,)) + tuple((p, l, r) for p in ports
        for l in trees(tuple(q for q in ports if q != p))
        for r in trees(tuple(q for q in ports if q != p)))


def path(t, w, reads, prices):
    paid = 0
    while len(t) == 3:
        p, l, r = t
        paid += prices[p]
        t = r if reads[p][w] else l
    return paid, t[0]


def schedules(ports):
    return [q for k in range(len(ports) + 1) for q in permutations(ports, k)]


def follows(t, qs):
    if not qs:
        return len(t) == 1
    return len(t) == 3 and t[0] == qs[0] and follows(t[1], qs[1:]) and follows(t[2], qs[1:])


def check_adaptive():
    worlds, ports = tuple(range(3)), (0, 1)
    ts = trees(ports)
    ss = schedules(ports)
    fixed = tuple(t for t in ts if any(follows(t, q) for q in ss))
    assert len(ts) == 74 and len(ss) == 5
    cnt = hardcnt = 0
    for readings in product((0, 1), repeat=6):
        reads = (readings[:3], readings[3:])
        for price_values in product(range(2), repeat=2):
            prices = dict(zip(ports, price_values))
            paths = [tuple(path(t, w, reads, prices) for w in worlds) for t in ts]
            fixed_indices = [i for i, t in enumerate(ts) if t in fixed]
            for losses in product((0, 2), repeat=6):
                loss = (losses[:3], losses[3:])
                @lru_cache(None)
                def dp(B, P):
                    if not B:
                        return 0
                    stop = min(max(loss[a][w] for w in B) for a in (0, 1))
                    return min([stop] + [prices[p] + max(dp(tuple(w for w in B if reads[p][w] == b),
                               tuple(q for q in P if q != p)) for b in (0, 1)) for p in P])
                costs = [max(c + loss[a][w] for w, (c, a) in enumerate(tpath)) for tpath in paths]
                opt = dp(worlds, ports)
                assert opt == min(costs)
                assert opt <= min(costs[i] for i in fixed_indices)
                cnt += 1
                # Hard error constraint is separate from total scalarized cost.
                for eps, budget in product((0, 2), range(3)):
                    feasible = any(all(c <= budget and loss[a][w] <= eps
                                   for w, (c, a) in enumerate(tpath)) for tpath in paths)
                    capped = min(max(c + (0 if loss[a][w] <= eps else budget + 1)
                                     for w, (c, a) in enumerate(tpath)) for tpath in paths)
                    assert feasible == (capped <= budget)
                    hardcnt += 1
    print(f'T19: {cnt} finite cost/port models, {len(ts)} adaptive trees per model; '
          f'Bellman optimality and adaptive <= static checked')
    print(f'T19.7: {hardcnt} hard tolerance/budget checks against all legal trees')


def witness(n, target):
    worlds = tuple(product((0, 1), repeat=n))
    ports = tuple(range(n))
    @lru_cache(None)
    def dp(B, P):
        if not B:
            return 0
        stop = min(max(4 * (a != target(w)) for w in B) for a in (0, 1))
        return min([stop] + [1 + max(dp(tuple(w for w in B if w[p] == b),
                     tuple(q for q in P if q != p)) for b in (0, 1)) for p in P])
    fixed = {}
    for mask in range(1 << n):
        S = tuple(i for i in ports if mask & (1 << i))
        cells = {}
        for w in worlds:
            cells.setdefault(tuple(w[p] for p in S), set()).add(target(w))
        fixed[S] = len(S) + 4 * any(len(v) > 1 for v in cells.values())
    return dp(worlds, ports), min(fixed.values()), fixed


if __name__ == '__main__':
    check_partitions()
    check_adaptive()
    adaptive, static, details = witness(3, lambda w: w[2] if w[0] else w[1])
    assert (adaptive, static) == (2, 3)
    print(f'Multiplexer: adaptive={adaptive}, static={static}; fixed subset costs={details}')
    adaptive, static, details = witness(2, lambda w: w[0] ^ w[1])
    assert (adaptive, static) == (2, 2) and details == {(): 4, (0,): 5, (1,): 5, (0, 1): 2}
    print(f'XOR: adaptive={adaptive}; fixed subset costs={details}')
    print('PASS independent finite checks; Lean kernel not executed by this script.')
