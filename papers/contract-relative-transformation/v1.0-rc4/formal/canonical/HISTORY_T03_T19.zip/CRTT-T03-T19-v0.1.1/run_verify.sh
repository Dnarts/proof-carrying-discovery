#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if command -v shasum >/dev/null 2>&1; then
  shasum -a 256 -c SHA256SUMS.txt
else
  sha256sum -c SHA256SUMS.txt
fi
if ! command -v lean >/dev/null 2>&1; then
  printf '%s\n' 'ERROR: Lean not installed. Kernel verification not performed.' >&2
  exit 127
fi
lean --version
for module in SufficientPartitions.lean AdaptiveObservation.lean; do
  printf '\n=== LEAN: %s ===\n' "$module"
  # Lean exits successfully on some warnings; reject sorryAx and warnings of sorry.
  if output=$(lean "$module" 2>&1); then
    printf '%s\n' "$output"
    if printf '%s\n' "$output" | grep -Eiq "sorryAx|uses 'sorry'|declaration uses sorry"; then
      printf '%s\n' 'ERROR: untrusted proof placeholder reported.' >&2
      exit 1
    fi
    if printf '%s\n' "$output" | grep -Eiq '(^|[[:space:]])warning:'; then
      printf '%s\n' 'ERROR: Lean warnings remain.' >&2
      exit 1
    fi
    if [[ "$module" == AdaptiveObservation.lean ]] && printf '%s\n' "$output" | grep -Fq 'Classical.choice'; then
      printf '%s\n' 'ERROR: Classical.choice in audited T19 dependencies.' >&2
      exit 1
    fi
  else
    status=$?
    printf '%s\n' "$output" >&2
    exit "$status"
  fi
done
python3 check_finite.py
printf '\nPASS: manifest, Lean compilation and finite cross-check. Inspect axiom reports above.\n'
