import Std

/-!
CRTT T03: sufficient equivalence relations on an arbitrary state space.
Coarser means a larger equivalence relation. Sufficiency is semantic, not
an assertion of efficient observation. No finiteness is needed. The general
proof uses classical decidability locally; Lean 4.36.0 reported Classical.choice
for coarsest_exists_iff and its two derived counterexamples in v0.1.
-/
namespace CRTT.SufficientPartitions

universe u v

abbrev Relation (X : Type u) := X → X → Prop

def Sufficient {X : Type u} {A : Type v}
    (valid : X → A → Prop) (r : Relation X) : Prop :=
  ∀ x, ∃ a, ∀ y, r x y → valid y a

def Refines {X : Type u} (r s : Relation X) : Prop :=
  ∀ x y, r x y → s x y

def Compatible {X : Type u} {A : Type v}
    (valid : X → A → Prop) (x y : X) : Prop :=
  ∃ a, valid x a ∧ valid y a

def Coarsest {X : Type u} {A : Type v}
    (valid : X → A → Prop) (r : Relation X) : Prop :=
  Equivalence r ∧ Sufficient valid r ∧
    ∀ s : Relation X, Equivalence s → Sufficient valid s → Refines s r

theorem sufficient_refines_compatible {X : Type u} {A : Type v}
    {valid : X → A → Prop} {r : Relation X}
    (he : Equivalence r) (hs : Sufficient valid r) :
    Refines r (Compatible valid) := by
  intro x y hxy
  obtain ⟨a, ha⟩ := hs x
  exact ⟨a, ha x (he.refl x), ha y hxy⟩

theorem sufficient_refinement {X : Type u} {A : Type v}
    {valid : X → A → Prop} {r s : Relation X}
    (hrs : Refines r s) (hs : Sufficient valid s) : Sufficient valid r := by
  intro x
  obtain ⟨a, ha⟩ := hs x
  exact ⟨a, fun y hy => ha y (hrs x y hy)⟩

/-- Merge a designated pair, leaving every other equivalence class a singleton. -/
def PairMerge {X : Type u} (x y p q : X) : Prop :=
  p = q ∨ ((p = x ∨ p = y) ∧ (q = x ∨ q = y))

theorem pairMerge_equiv {X : Type u} (x y : X) : Equivalence (PairMerge x y) := by
  constructor
  · intro p
    exact Or.inl rfl
  · intro p q h
    rcases h with h | ⟨hp, hq⟩
    · exact Or.inl h.symm
    · exact Or.inr ⟨hq, hp⟩
  · intro p q r hpq hqr
    rcases hpq with h | ⟨hp, hq⟩
    · subst p
      exact hqr
    · rcases hqr with h | ⟨_, hr⟩
      · subst r
        exact Or.inr ⟨hp, hq⟩
      · exact Or.inr ⟨hp, hr⟩

theorem pairMerge_sufficient {X : Type u} {A : Type v}
    (valid : X → A → Prop) (total : ∀ x, ∃ a, valid x a)
    (x y : X) (hxy : Compatible valid x y) : Sufficient valid (PairMerge x y) := by
  classical
  obtain ⟨a, hax, hay⟩ := hxy
  intro p
  by_cases hp : p = x ∨ p = y
  · have ha : ∀ q : X, q = x ∨ q = y → valid q a := by
      intro q hq
      rcases hq with hq | hq
      · subst q; exact hax
      · subst q; exact hay
    refine ⟨a, ?_⟩
    intro q h
    rcases h with h | h
    · subst q; exact ha p hp
    · exact ha q h.2
  · obtain ⟨b, hb⟩ := total p
    refine ⟨b, ?_⟩
    intro q h
    rcases h with h | h
    · subst q; exact hb
    · exact False.elim (hp h.1)

/-- A coarsest sufficient partition must merge every compatible pair. -/
theorem coarsest_contains_compatible {X : Type u} {A : Type v}
    {valid : X → A → Prop} {r : Relation X} (h : Coarsest valid r) :
    Refines (Compatible valid) r := by
  have total : ∀ x, ∃ a, valid x a := by
    intro x
    obtain ⟨a, ha⟩ := h.2.1 x
    exact ⟨a, ha x (h.1.refl x)⟩
  intro x y hxy
  have hm := h.2.2 (PairMerge x y) (pairMerge_equiv x y)
    (pairMerge_sufficient valid total x y hxy)
  exact hm x y (Or.inr ⟨Or.inl rfl, Or.inr rfl⟩)

/-- T03: existence iff compatibility itself is a sufficient equivalence. -/
theorem coarsest_exists_iff {X : Type u} {A : Type v} (valid : X → A → Prop) :
    (∃ r : Relation X, Coarsest valid r) ↔
      Equivalence (Compatible valid) ∧ Sufficient valid (Compatible valid) := by
  constructor
  · rintro ⟨r, hr⟩
    have hrc := sufficient_refines_compatible hr.1 hr.2.1
    have hcr := coarsest_contains_compatible hr
    constructor
    · constructor
      · intro x; exact hrc x x (hr.1.refl x)
      · intro x y hxy; exact hrc y x (hr.1.symm (hcr x y hxy))
      · intro x y z hxy hyz
        exact hrc x z (hr.1.trans (hcr x y hxy) (hcr y z hyz))
    · exact sufficient_refinement hcr hr.2.1
  · intro h
    refine ⟨Compatible valid, h.1, h.2, ?_⟩
    intro s he hs
    exact sufficient_refines_compatible he hs

/-- Uniqueness as a relation (extensional, not a particular encoding). -/
theorem coarsest_unique {X : Type u} {A : Type v}
    {valid : X → A → Prop} {r s : Relation X}
    (hr : Coarsest valid r) (hs : Coarsest valid s) : ∀ x y, r x y ↔ s x y := by
  intro x y
  exact ⟨hs.2.2 r hr.1 hr.2.1 x y, hr.2.2 s hs.1 hs.2.1 x y⟩

/-- For a single exact target, compatibility is equality of its values. -/
theorem exact_target_coarsest {X : Type u} {Y : Type v} (target : X → Y) :
    Coarsest (fun x a => target x = a) (fun x y => target x = target y) := by
  refine ⟨⟨?_, ?_, ?_⟩, ?_, ?_⟩
  · intro x; rfl
  · intro x y h; exact h.symm
  · intro x y z hxy hyz; exact hxy.trans hyz
  · intro x; exact ⟨target x, fun y hy => hy.symm⟩
  · intro r he hs x y hxy
    obtain ⟨a, ha⟩ := hs x
    exact (ha x (he.refl x)).trans (ha y hxy).symm

/-! Constructive finite counterexamples, with complete state/action types. -/
inductive Three where
  | x | y | z
  deriving DecidableEq, Repr

def pathValid : Three → Bool → Prop
  | .x, a => a = false
  | .y, _ => True
  | .z, a => a = true

theorem path_pairwise_nontransitive :
    Compatible pathValid .x .y ∧ Compatible pathValid .y .z ∧
      ¬ Compatible pathValid .x .z := by
  refine ⟨⟨false, rfl, True.intro⟩, ⟨true, True.intro, rfl⟩, ?_⟩
  rintro ⟨a, h1, h2⟩
  change a = false at h1
  change a = true at h2
  cases h1
  cases h2

theorem path_no_coarsest : ¬ ∃ r : Relation Three, Coarsest pathValid r := by
  intro h
  have he := (coarsest_exists_iff pathValid).mp h
  exact path_pairwise_nontransitive.2.2
    (he.1.trans path_pairwise_nontransitive.1 path_pairwise_nontransitive.2.1)

/-- Each world rules out one of three actions; all pairs overlap. -/
def triangleValid (world a : Three) : Prop := world ≠ a

theorem triangle_compat_all (world₁ world₂ : Three) : Compatible triangleValid world₁ world₂ := by
  cases world₁ <;> cases world₂
  · exact ⟨.y, by simp [triangleValid], by simp [triangleValid]⟩
  · exact ⟨.z, by simp [triangleValid], by simp [triangleValid]⟩
  · exact ⟨.y, by simp [triangleValid], by simp [triangleValid]⟩
  · exact ⟨.z, by simp [triangleValid], by simp [triangleValid]⟩
  · exact ⟨.x, by simp [triangleValid], by simp [triangleValid]⟩
  · exact ⟨.x, by simp [triangleValid], by simp [triangleValid]⟩
  · exact ⟨.y, by simp [triangleValid], by simp [triangleValid]⟩
  · exact ⟨.x, by simp [triangleValid], by simp [triangleValid]⟩
  · exact ⟨.x, by simp [triangleValid], by simp [triangleValid]⟩

theorem triangle_compat_equiv : Equivalence (Compatible triangleValid) := by
  constructor
  · intro world; exact triangle_compat_all world world
  · intro world₁ world₂ _h; exact triangle_compat_all world₂ world₁
  · intro world₁ world₂ world₃ _h₁₂ _h₂₃
    exact triangle_compat_all world₁ world₃

theorem triangle_no_common_action : ¬ Sufficient triangleValid (Compatible triangleValid) := by
  intro h
  obtain ⟨a, ha⟩ := h Three.x
  exact ha a (triangle_compat_all .x a) rfl

theorem triangle_no_coarsest : ¬ ∃ r : Relation Three, Coarsest triangleValid r := by
  intro h
  exact triangle_no_common_action ((coarsest_exists_iff triangleValid).mp h).2

#print axioms coarsest_exists_iff
#print axioms exact_target_coarsest
#print axioms coarsest_unique
#print axioms path_no_coarsest
#print axioms triangle_no_coarsest

end CRTT.SufficientPartitions
