# English companion source

Current English translation of the Russian companion by Aleksandr Strand.

Compile `pop-en/interface_barrier_popular_en.tex` with two passes of XeLaTeX or LuaLaTeX; Noto Serif and standard LaTeX packages including TikZ are required. Hebrew and Simplified Chinese translations are not included.
