# Recursive Switching: translation sources

These are reading translations of the current canonical editions, aligned with commit
41fa6085c6a9b110925607c6ab82b930f180a049. Canonical papers, proof artifacts,
and verification logs are separate in rs_bundle.zip.

Build each TeX from its directory with XeLaTeX twice (xelatex -halt-on-error FILE.tex).
Install TeX Live packages for fontspec, polyglossia, bidi, AMS math, unicode-math,
bookmark, hyperref and PGF/TikZ. Fonts: Noto Sans Hebrew and Liberation Serif
for Hebrew; Noto CJK Serif and Sans TTC collections for Simplified Chinese
(the SC face is index 2 in the upstream collections); Noto Serif for English;
DejaVu Sans Mono for monospace. The Hebrew sources use installed Noto Sans Hebrew
unless local font files are provided.
