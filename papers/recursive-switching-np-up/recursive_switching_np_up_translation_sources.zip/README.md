# English companion source

This archive retains the English translation of the earlier Russian companion. It predates the authorship and reference updates in the current Russian companion.

Build from `pop-en/` with two LuaLaTeX passes. The Hebrew and Simplified Chinese translations have been withdrawn.
