# Translation sources · Recursive Switching NP/UP

The two technical translations follow the canonical English TeX dated 26 November 2026. Both companion translations follow the separate Russian PDF, «Интерфейс как ресурс познания». The companion figures and tables were recreated for the translations.

Run XeLaTeX twice on each TeX file from its own directory. Standard current TeX Live packages are required. For Hebrew, install Noto Sans Hebrew (included in fonts/, under OFL) and Liberation Serif. Both Hebrew sources can also use their bundled fonts directly. For Simplified Chinese, install Noto Serif CJK SC, and any additional font named in the source. Install the Latin font named in the English companion source.

These are reading editions, not changes to the canonical proofs, claims or Lean evidence. No new Lean audit is implied.
