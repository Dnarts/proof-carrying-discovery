# Recursive Switching and Modular Oracle Separations under NP = UP: Lean 4 Verification Artifact

**Author:** Aleksandr Strand  
**Artifact version:** 1.0 · Cycle XXI  
**Toolchain:** Lean 4.36.0 · no imports in the seven modules; no Mathlib dependency  
**License:** MIT

This is the Lean-only companion to [Recursive Switching and Modular Oracle Separations under NP = UP](https://github.com/Dnarts/proof-carrying-discovery/blob/c212878f922954c95740e39421c6b138303bf686/papers/recursive-switching-np-up/recursive_switching_np_up_en.pdf).

## Contents

| Module | Audited declarations |
|---|---:|
| PersistentMarkerKnowledge.lean | 3 |
| TraceCapture.lean | 4 |
| ReachableBranch.lean | 4 |
| SingletonSwitching.lean | 8 |
| RecursiveSwitching.lean | 8 |
| ModularSeparation.lean | 6 |
| UniformRecursiveBridge.lean | 12 |

The seven current modules and four verification logs match byte for byte the [canonical GitHub bundle at commit c212878](https://github.com/Dnarts/proof-carrying-discovery/blob/c212878f922954c95740e39421c6b138303bf686/papers/recursive-switching-np-up/rs_bundle.zip). Its SHA-256 is f5d426e4427d5c62fd97227d958ccecbac7529d8defa09be9948d9ad26103203. Superseded drafts, manuscript files, typesetting logs, and the separate Python experiment are not included. The new runner uses the declaration list from the original audit scripts at that commit.

## Check the archive and run the audit

From the directory containing this README:

    sha256sum -c SHA256SUMS.txt     # Linux
    shasum -a 256 -c SHA256SUMS.txt  # macOS alternative
    lean --version
    python3 verify.py

Use Lean 4.36.0 (also pinned in lean-toolchain for elan). Python 3 uses only its standard library. By default, the verifier invokes lean on the PATH. To use a standalone toolchain, pass the absolute path to its lean executable as the only argument to verify.py.

The archived logs report 45/45 selected declarations audited under Lean 4.36.0 on arm64 macOS. The reported axiom sets are empty or contain only propext and Quot.sound; no sorryAx, ofReduceBool, or Classical.choice was reported. The TraceCapture log contains 16 nonblocking deprecation warnings. These are the original logs, not results of a fresh Lean run during ZIP assembly.

## Scope

The modules cover selected combinatorial and algebraic components and a conditional finite-stage bridge. The probability induction, infinite oracle construction, and multi-tape oracle Turing-machine bridge belong to the paper's analytic argument. This artifact does not formalize the full oracle separation end to end and makes no claim about unrelativized P versus NP.
