#!/usr/bin/env python3
"""Compile the seven standalone units and audit the same 45 declarations."""
from collections import defaultdict
from pathlib import Path
import re
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
ALLOWED = {'propext', 'Quot.sound'}
ROW = re.compile(r"^'([^']+)' (?:does not depend on any axioms|depends on axioms: \[([^\]]*)\])\s*$", re.M)


def check_audit(output, names):
    rows = ROW.findall(output)
    if len(rows) != len(names) or {name for name, _ in rows} != set(names):
        raise ValueError('Audit did not return exactly the expected declarations.')
    for name, axioms in rows:
        extras = {x.strip() for x in axioms.split(',') if x.strip()} - ALLOWED
        if extras:
            raise ValueError(f'{name}: unexpected axioms {sorted(extras)}')


def run(lean, path):
    result = subprocess.run([lean, str(path)], text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, cwd=ROOT)
    print(result.stdout, end='', flush=True)
    result.check_returncode()
    return result.stdout


def main():
    lean = sys.argv[1] if len(sys.argv) == 2 else 'lean'
    version = subprocess.check_output([lean, '--version'], cwd=ROOT, text=True)
    print(version.strip(), flush=True)
    if not re.search(r'\bversion 4\.36\.0(?:,|\s|$)', version):
        raise ValueError('Use Lean 4.36.0 to match the publication.')
    modules = defaultdict(list)
    tsv = (ROOT / 'audit_declarations.tsv').read_text(encoding='utf-8')
    for line in tsv.splitlines():
        module, name = line.split('\t')
        modules[module].append(name)
    if len(modules) != 7 or len({n for ns in modules.values() for n in ns}) != 45:
        raise ValueError('Expected seven modules and 45 distinct declarations.')
    with tempfile.TemporaryDirectory(prefix='recursive-switching-') as td:
        for module, names in modules.items():
            path = ROOT / 'lean' / module
            print(f'=== {module} ===', flush=True)
            run(lean, path)
            audit = Path(td) / module
            audit.write_bytes(path.read_bytes() + b'\n\n' +
                              ''.join(f'#print axioms {n}\n' for n in names).encode())
            check_audit(run(lean, audit), names)
    print('PASS: 7 modules; 45 audited declarations; no axioms outside propext and Quot.sound.')


if __name__ == '__main__':
    main()
