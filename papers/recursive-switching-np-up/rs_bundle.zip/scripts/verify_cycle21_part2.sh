#!/usr/bin/env bash
set -euo pipefail

echo "=== Lean version ==="
lean --version

echo "=== 1. Compile check (0 errors, 0 warnings expected) ==="
lean ReachableBranch.lean
lean SingletonSwitching.lean

echo "=== 2. Axiom audit (0 sorryAx, 0 ofReduceBool, 0 Classical.choice expected) ==="
cat ReachableBranch.lean > /tmp/audit_rb.lean
cat >> /tmp/audit_rb.lean << 'EOF'

#print axioms RecursiveSwitching.ReachableBranch.reachable_leaf_lemma_scaled
#print axioms RecursiveSwitching.ReachableBranch.reachWeight_le_auxWeight
#print axioms RecursiveSwitching.ReachableBranch.reachable_sum_le_aux_sum
#print axioms RecursiveSwitching.ReachableBranch.root_aux_norm
EOF

cat SingletonSwitching.lean > /tmp/audit_ss.lean
cat >> /tmp/audit_ss.lean << 'EOF'

#print axioms RecursiveSwitching.SingletonSwitching.weightP_norm
#print axioms RecursiveSwitching.SingletonSwitching.weightQ_norm
#print axioms RecursiveSwitching.SingletonSwitching.weight_ratio_pos_replace
#print axioms RecursiveSwitching.SingletonSwitching.weight_ratio_neg_replace
#print axioms RecursiveSwitching.SingletonSwitching.multi_row_weight_bound
#print axioms RecursiveSwitching.SingletonSwitching.decode_encode_row
#print axioms RecursiveSwitching.SingletonSwitching.false_preserved_under_spec
#print axioms RecursiveSwitching.SingletonSwitching.first_satisfied_term_unique
EOF

echo "--- ReachableBranch axioms ---"
lean /tmp/audit_rb.lean | tee /tmp/rb_axioms.log
echo "--- SingletonSwitching axioms ---"
lean /tmp/audit_ss.lean | tee /tmp/ss_axioms.log

if grep -E "sorryAx|ofReduceBool|Classical\.choice" /tmp/rb_axioms.log /tmp/ss_axioms.log; then
  echo "AXIOM AUDIT FAILED"
  exit 1
fi

echo "=== ALL CHECKS PASSED (0 errors, 0 forbidden axioms) ==="
