#!/usr/bin/env bash
set -euo pipefail

echo "=== Lean version ==="
lean --version

echo "=== 1. Compile check (0 errors, 0 warnings expected) ==="
lean RecursiveSwitching.lean
lean ModularSeparation.lean

echo "=== 2. Axiom audit (0 sorryAx, 0 ofReduceBool, 0 Classical.choice expected) ==="
cat RecursiveSwitching.lean > /tmp/audit_rs.lean
cat >> /tmp/audit_rs.lean << 'EOF'

#print axioms RecursiveSwitching.RecursiveSwitching.binSearch_finds_first
#print axioms RecursiveSwitching.RecursiveSwitching.binSearch_minimal
#print axioms RecursiveSwitching.RecursiveSwitching.event_A_bound
#print axioms RecursiveSwitching.RecursiveSwitching.event_A_B_union_bound
#print axioms RecursiveSwitching.RecursiveSwitching.event_A_B_strict
#print axioms RecursiveSwitching.RecursiveSwitching.widthAtLayer_eq
#print axioms RecursiveSwitching.RecursiveSwitching.depthRec_le_pow
#print axioms RecursiveSwitching.RecursiveSwitching.range_strictly_acyclic
EOF

cat ModularSeparation.lean > /tmp/audit_ms.lean
cat >> /tmp/audit_ms.lean << 'EOF'

#print axioms RecursiveSwitching.ModularSeparation.sumCube_eq_zero_of_indep
#print axioms RecursiveSwitching.ModularSeparation.exists_missing_index
#print axioms RecursiveSwitching.ModularSeparation.sumCube_poly_eq_zero
#print axioms RecursiveSwitching.ModularSeparation.sumCube_orPrefix
#print axioms RecursiveSwitching.ModularSeparation.no_low_deg_mod_p_OR
#print axioms RecursiveSwitching.ModularSeparation.modular_diagonalization_step
EOF

echo "--- RecursiveSwitching axioms ---"
lean /tmp/audit_rs.lean | tee /tmp/rs_axioms.log
echo "--- ModularSeparation axioms ---"
lean /tmp/audit_ms.lean | tee /tmp/ms_axioms.log

if grep -E "sorryAx|ofReduceBool|Classical\.choice" /tmp/rs_axioms.log /tmp/ms_axioms.log; then
  echo "AXIOM AUDIT FAILED"
  exit 1
fi

echo "=== ALL CHECKS PASSED (0 errors, 0 forbidden axioms) ==="
