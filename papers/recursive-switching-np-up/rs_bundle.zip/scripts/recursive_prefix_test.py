from itertools import product, permutations
from random import Random
from collections import Counter

# Literal = (layer,row,address,sign). A DNF is a tuple of terms.
# Layers 1 and 2 have arbitrary fixed DNF kernels on strictly lower layers.
N=L=3
rng=Random(210195)
counts=Counter()

def make_dnf(h, nterms):
    out=[]
    for _ in range(nterms):
        t=[]
        for j,x in rng.sample(list(product(range(h+1),range(N))),rng.randint(1,min(3,(h+1)*N))):
            t.append((j,x,rng.randrange(L),rng.randrange(2)))
        out.append(tuple(t))
    return tuple(out)

def normal(dnf):
    # Singleton semantics: reject incompatible positive addresses or a contradictory literal.
    out=[]
    for t in dnf:
        t=tuple(dict.fromkeys(t)); pos={}; bad=False
        for j,x,y,s in t:
            if s:
                if (j,x) in pos and pos[j,x]!=y:bad=True
                pos[j,x]=y
        if bad or any(not s and pos.get((j,x))==y for j,x,y,s in t):continue
        t=tuple(l for l in t if l[3] or l[:2] not in pos)
        if t not in out:out.append(t)
    return tuple(out)

def direct(F,A):
    return any(all(A.get((j,x,y),0)==s for j,x,y,s in t) for t in F)

def expand_prefix(F,h,g,Kdef,U,stop):
    out=[]
    for t in F[:stop]:
        if any(j==h and not s and (x,y) in U for j,x,y,s in t):continue
        if any(j==h and s and g[h][x]!=y for j,x,y,s in t):continue
        parts=[Kdef[h][x] if j==h and s else ((l,),) for l in t for j,x,y,s in [l] if j!=h or s]
        for terms in product(*parts):out.append(tuple(l for term in terms for l in term))
    return normal(tuple(out))

def rec(F,h,g,Kdef,A):
    F=normal(F)
    if h==0:return direct(F,A)
    U=set()
    # Every blocking round learns a new true marker.
    for _ in range(N+1):
        def test(stop):
            P=expand_prefix(F,h,g,Kdef,U,stop)
            assert all(len(t)<=3*max(1,max((len(t) for t in F),default=0)) for t in P)
            result=rec(P,h-1,g,Kdef,A)
            expected=any(all((not s and (x,y) not in U) or (s and A.get((j,x,y),0)==1) if j==h else A.get((j,x,y),0)==s for j,x,y,s in t) for t in F[:stop])
            assert result==expected
            counts['prefix_checks']+=1
            return result
        if not test(len(F)):return False
        lo,hi=1,len(F)
        while lo<hi:
            mid=(lo+hi)//2
            if test(mid):hi=mid
            else:lo=mid+1
        t=F[lo-1]
        for j,x,y,s in t:
            if j==h and s:U.add((x,y))
        blocker=None
        for j,x,y,s in t:
            if j==h and not s and g[h][x]==y and rec(Kdef[h][x],h-1,g,Kdef,A):
                blocker=(x,y);break
        if blocker is None:return True
        assert blocker not in U; U.add(blocker)
    raise AssertionError('nontermination')

# Fixed base marker positions; b is a deletion vector. Independently enumerate
# marker permutations at both upper layers. Compare exact recursive evaluation.
for fam in range(6):
    Kdef={1:[normal(make_dnf(0,5)) for _ in range(N)],2:[normal(make_dnf(1,5)) for _ in range(N)]}
    F=normal(make_dnf(2,10))
    for b in product((0,1),repeat=N):
        for g1,g2 in product(permutations(range(L)),repeat=2):
            g={1:g1,2:g2};A={(0,x,x):1-b[x] for x in range(N)}
            for h in (1,2):
                for x in range(N):
                    K=int(direct(Kdef[h][x],A));A[h,x,g[h][x]]=K
                    assert rec(Kdef[h][x],h-1,g,Kdef,A)==bool(K)
                    counts['kernel_checks']+=1
            assert rec(F,2,g,Kdef,A)==direct(F,A)
            counts['top_worlds']+=1
print('families=6 layers=2 upper_marker_model=permutation base_rows=3')
for k,v in sorted(counts.items()): print(f'{k}={v}')
print('violations=0')
