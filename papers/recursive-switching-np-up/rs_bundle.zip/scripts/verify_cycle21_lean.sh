#!/usr/bin/env bash
set -euo pipefail

echo "=== Lean version ==="
lean --version

echo "=== 1. Compile check (0 errors, 0 warnings expected) ==="
lean PersistentMarkerKnowledge.lean
lean TraceCapture.lean

echo "=== 2. Axiom audit (0 sorryAx, 0 ofReduceBool, 0 Classical.choice expected) ==="
cat > /tmp/audit_cycle21_p1.lean << 'EOF'
-- Append axiom audit to PersistentMarkerKnowledge.lean
EOF
cat PersistentMarkerKnowledge.lean > /tmp/audit_pmk.lean
cat >> /tmp/audit_pmk.lean << 'EOF'

#print axioms RecursiveSwitching.PersistentMarkerKnowledge.step_preserves_invariant
#print axioms RecursiveSwitching.PersistentMarkerKnowledge.step_lengths
#print axioms RecursiveSwitching.PersistentMarkerKnowledge.lemma_XXI_1
EOF

cat TraceCapture.lean > /tmp/audit_tc.lean
cat >> /tmp/audit_tc.lean << 'EOF'

#print axioms RecursiveSwitching.TraceCapture.findFirst_restricted_eq
#print axioms RecursiveSwitching.TraceCapture.trace_capture_step
#print axioms RecursiveSwitching.TraceCapture.trace_capture_multi_step
#print axioms RecursiveSwitching.TraceCapture.restrictedEligible_independent_of_hidden
EOF

echo "--- PersistentMarkerKnowledge axioms ---"
lean /tmp/audit_pmk.lean | tee /tmp/pmk_axioms.log
echo "--- TraceCapture axioms ---"
lean /tmp/audit_tc.lean | tee /tmp/tc_axioms.log

if grep -E "sorryAx|ofReduceBool|Classical\.choice" /tmp/pmk_axioms.log /tmp/tc_axioms.log; then
  echo "AXIOM AUDIT FAILED"
  exit 1
fi

echo "=== ALL CHECKS PASSED (0 errors, 0 forbidden axioms) ==="
