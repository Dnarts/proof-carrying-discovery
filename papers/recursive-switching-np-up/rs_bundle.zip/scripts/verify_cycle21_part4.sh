#!/usr/bin/env bash
set -euo pipefail
echo "=== Lean version ==="
lean --version
echo "=== 1. Compile check ==="
lean UniformRecursiveBridge.lean
echo "=== 2. Axiom audit ==="
cat UniformRecursiveBridge.lean > /tmp/audit_bridge.lean
cat >> /tmp/audit_bridge.lean << 'EOF'

#print axioms RecursiveSwitching.UniformRecursiveBridge.exists_good_of_bad_lt_total
#print axioms RecursiveSwitching.UniformRecursiveBridge.exists_simultaneously_good
#print axioms RecursiveSwitching.UniformRecursiveBridge.dtreeToPoly_correct
#print axioms RecursiveSwitching.UniformRecursiveBridge.dtreeToPoly_deg_le
#print axioms RecursiveSwitching.UniformRecursiveBridge.evalPoly_mul
#print axioms RecursiveSwitching.UniformRecursiveBridge.polyMul_deg_le
#print axioms RecursiveSwitching.UniformRecursiveBridge.evalPoly_pow
#print axioms RecursiveSwitching.UniformRecursiveBridge.polyPow_deg_le
#print axioms RecursiveSwitching.UniformRecursiveBridge.evalPoly_substCounter
#print axioms RecursiveSwitching.UniformRecursiveBridge.substCounter_deg_le
#print axioms RecursiveSwitching.UniformRecursiveBridge.exists_cube_disagreement
#print axioms RecursiveSwitching.UniformRecursiveBridge.uniform_recursive_modular_bridge
EOF
echo "--- UniformRecursiveBridge axioms ---"
lean /tmp/audit_bridge.lean | tee /tmp/bridge_axioms.log
if grep -E "sorryAx|ofReduceBool|Classical\.choice" /tmp/bridge_axioms.log; then
  echo "AXIOM AUDIT FAILED"; exit 1
fi
echo "=== ALL CHECKS PASSED (0 errors, 0 forbidden axioms) ==="
