/-
  ReachableBranch.lean — v0.1 (0 external imports, Lean 4.36.0 target)
  Formalizes Gate 184 (Theorem XX.1 — Reachable Leaf Lemma) and
  Gate 197 (Adaptive Reachable-Branch Bound via auxiliary distribution
  Pr[b_i = 1] = p / (1 + p)) in exact integer (`Nat`) arithmetic.

  100% constructive (0 sorryAx, 0 ofReduceBool, 0 Classical.choice, 0 warnings).
-/

namespace RecursiveSwitching.ReachableBranch

/-! ### 1. Gate 184: Reachable Leaf Lemma (Theorem XX.1) -/

inductive DTree where
  | leaf : DTree
  | branch (v : Nat) (lo hi : DTree) : DTree

def depth : DTree → Nat
  | .leaf => 0
  | .branch _ lo hi => 1 + max (depth lo) (depth hi)

/-- Exact `q^d`-scaled expected number of reachable leaves under a `0`-only
    random restriction with free probability `p = a / q` (`a ≤ q`). -/
def expectedReachableScaled (a q : Nat) : Nat → DTree → Nat
  | d, .leaf => q ^ d
  | 0, .branch _ _ _ => 1
  | d + 1, .branch _ lo hi =>
      (q - a) * expectedReachableScaled a q d lo +
      a * (expectedReachableScaled a q d lo + expectedReachableScaled a q d hi)

private theorem pow_le_pow_left_nat {x y : Nat} (h : x ≤ y) :
    ∀ n : Nat, x ^ n ≤ y ^ n
  | 0 => Nat.le_refl 1
  | n + 1 => by
      simp only [Nat.pow_succ]
      exact Nat.mul_le_mul (pow_le_pow_left_nat h n) h

/-- Theorem XX.1 (Reachable Leaf Lemma, exact `q^d`-scaled form):
    For any deterministic decision tree `T` of depth `≤ d` and `p = a / q` (`a ≤ q`),
    `q^d * E_σ[Z_σ(T)] ≤ (q + a)^d`, i.e., `E_σ[Z_σ(T)] ≤ (1 + p)^d`. -/
theorem reachable_leaf_lemma_scaled (a q : Nat) (haq : a ≤ q) :
    ∀ (d : Nat) (T : DTree),
      depth T ≤ d →
      expectedReachableScaled a q d T ≤ (q + a) ^ d
  | d, .leaf, _ => by
      have hleaf : expectedReachableScaled a q d .leaf = q ^ d := by
        cases d with
        | zero => rfl
        | succ d => rfl
      rw [hleaf]
      exact pow_le_pow_left_nat (Nat.le_add_right q a) d
  | 0, .branch _ lo hi, hdep => by
      dsimp only [depth] at hdep
      omega
  | d + 1, .branch _ lo hi, hdep => by
      dsimp only [depth] at hdep
      have hlo : depth lo ≤ d := by omega
      have hhi : depth hi ≤ d := by omega
      have ih_lo := reachable_leaf_lemma_scaled a q haq d lo hlo
      have ih_hi := reachable_leaf_lemma_scaled a q haq d hi hhi
      dsimp only [expectedReachableScaled]
      have h1 : (q - a) * expectedReachableScaled a q d lo ≤ (q - a) * (q + a) ^ d :=
        Nat.mul_le_mul_left (q - a) ih_lo
      have h2 : a * (expectedReachableScaled a q d lo + expectedReachableScaled a q d hi) ≤
          a * ((q + a) ^ d + (q + a) ^ d) :=
        Nat.mul_le_mul_left a (Nat.add_le_add ih_lo ih_hi)
      have hsum : (q - a) * expectedReachableScaled a q d lo +
          a * (expectedReachableScaled a q d lo + expectedReachableScaled a q d hi) ≤
          (q - a) * (q + a) ^ d + a * ((q + a) ^ d + (q + a) ^ d) :=
        Nat.add_le_add h1 h2
      have halg : (q - a) * (q + a) ^ d + a * ((q + a) ^ d + (q + a) ^ d) =
          (q + a) ^ (d + 1) := by
        have hstep : a * ((q + a) ^ d + (q + a) ^ d) = (a + a) * (q + a) ^ d := by
          rw [Nat.mul_add, Nat.add_mul]
        rw [hstep, ← Nat.add_mul]
        have hcoeff : q - a + (a + a) = q + a := by omega
        rw [hcoeff, Nat.pow_succ, Nat.mul_comm]
      rw [← halg]
      exact hsum

/-! ### 2. Gate 197: Auxiliary Distribution Reachable-Branch Bound -/

structure Transcript where
  len : Nat
  ones : Nat

def ValidTranscript (D : Nat) (t : Transcript) : Prop :=
  t.ones ≤ t.len ∧ t.len ≤ D

/-- `q^D`-scaled reachability probability `Pr_σ[t] * q^D = a^u * q^(D - u)`. -/
def reachWeight (a q D : Nat) (t : Transcript) : Nat :=
  a ^ t.ones * q ^ (D - t.ones)

/-- `(q + a)^D`-scaled auxiliary probability `Pr_{b̃}[t] * (q + a)^D = a^u * q^(d - u) * (q + a)^(D - d)`
    under `Pr[b̃_i = 1] = a / (q + a)`, `Pr[b̃_i = 0] = q / (q + a)`. -/
def auxWeight (a q D : Nat) (t : Transcript) : Nat :=
  a ^ t.ones * q ^ (t.len - t.ones) * (q + a) ^ (D - t.len)

/-- Exact single-transcript comparison (Gate 197 core inequality):
    `Pr_σ[t] * q^D ≤ Pr_{b̃}[t] * (q + a)^D`,
    i.e., `Pr_σ[t] ≤ (1 + p)^D * Pr_{b̃}[t]`. -/
theorem reachWeight_le_auxWeight (a q D : Nat) (t : Transcript)
    (hvalid : ValidTranscript D t) :
    reachWeight a q D t ≤ auxWeight a q D t := by
  dsimp only [reachWeight, auxWeight]
  have hsplit : D - t.ones = (t.len - t.ones) + (D - t.len) := by
    have h1 := hvalid.1
    have h2 := hvalid.2
    omega
  rw [hsplit, Nat.pow_add, ← Nat.mul_assoc]
  exact Nat.mul_le_mul_left (a ^ t.ones * q ^ (t.len - t.ones))
    (pow_le_pow_left_nat (Nat.le_add_right q a) (D - t.len))

def sumReachWeight (a q D : Nat) : List Transcript → Nat
  | [] => 0
  | t :: rest => reachWeight a q D t + sumReachWeight a q D rest

def sumAuxWeight (a q D : Nat) : List Transcript → Nat
  | [] => 0
  | t :: rest => auxWeight a q D t + sumAuxWeight a q D rest

/-- Summed Gate 197 bound over any finite list of winning transcripts:
    `q^D * E_σ[#reachable winning transcripts] ≤ (q + a)^D * Pr_{b̃}[winning]`. -/
theorem reachable_sum_le_aux_sum (a q D : Nat) :
    ∀ ts : List Transcript,
      (∀ t, t ∈ ts → ValidTranscript D t) →
      sumReachWeight a q D ts ≤ sumAuxWeight a q D ts
  | [], _ => Nat.le_refl 0
  | t :: rest, h => by
      dsimp only [sumReachWeight, sumAuxWeight]
      have ht : ValidTranscript D t := h t (List.Mem.head rest)
      have hrest : ∀ t', t' ∈ rest → ValidTranscript D t' :=
        fun t' ht' => h t' (List.Mem.tail t ht')
      exact Nat.add_le_add
        (reachWeight_le_auxWeight a q D t ht)
        (reachable_sum_le_aux_sum a q D rest hrest)

/-! ### 3. Exact Normalization of the Auxiliary Distribution on Decision Trees -/

/-- Collect all leaf transcripts of a decision tree `T` starting from `(len, ones)`. -/
def leafTranscripts : Nat → Nat → DTree → List Transcript
  | d, u, .leaf => [⟨d, u⟩]
  | d, u, .branch _ lo hi =>
      leafTranscripts (d + 1) u lo ++ leafTranscripts (d + 1) (u + 1) hi

theorem sumAuxWeight_append (a q D : Nat) :
    ∀ l₁ l₂ : List Transcript,
      sumAuxWeight a q D (l₁ ++ l₂) =
      sumAuxWeight a q D l₁ + sumAuxWeight a q D l₂
  | [], l₂ => by simp only [List.nil_append, sumAuxWeight, Nat.zero_add]
  | t :: rest, l₂ => by
      simp only [List.cons_append, sumAuxWeight]
      rw [sumAuxWeight_append a q D rest l₂, Nat.add_assoc]

/-- The auxiliary distribution `b̃` is exactly normalized on every decision tree
    of depth `≤ D`: the sum of `auxWeight` over all leaves equals `(q + a)^D`. -/
theorem leafTranscripts_aux_norm (a q D : Nat) :
    ∀ (T : DTree) (d u : Nat),
      u ≤ d →
      d + depth T ≤ D →
      sumAuxWeight a q D (leafTranscripts d u T) =
        a ^ u * q ^ (d - u) * (q + a) ^ (D - d)
  | .leaf, d, u, _, _ => by
      simp only [leafTranscripts, sumAuxWeight, auxWeight, Nat.add_zero]
  | .branch _ lo hi, d, u, hud, hdep => by
      dsimp only [depth] at hdep
      have hlo : (d + 1) + depth lo ≤ D := by omega
      have hhi : (d + 1) + depth hi ≤ D := by omega
      dsimp only [leafTranscripts]
      rw [sumAuxWeight_append]
      rw [leafTranscripts_aux_norm a q D lo (d + 1) u (by omega) hlo]
      rw [leafTranscripts_aux_norm a q D hi (d + 1) (u + 1) (by omega) hhi]
      have hd1 : d + 1 - u = (d - u) + 1 := by omega
      have hd2 : d + 1 - (u + 1) = d - u := by omega
      have hD : D - d = (D - (d + 1)) + 1 := by omega
      rw [hd1, hd2, hD, Nat.pow_succ q (d - u), Nat.pow_succ a u,
          Nat.pow_succ (q + a) (D - (d + 1))]
      -- Factor out `a^u * q^(d-u) * (q+a)^(D-(d+1))`
      have hL : a ^ u * (q ^ (d - u) * q) * (q + a) ^ (D - (d + 1)) =
          a ^ u * q ^ (d - u) * (q + a) ^ (D - (d + 1)) * q := by
        rw [← Nat.mul_assoc (a ^ u), Nat.mul_assoc (a ^ u * q ^ (d - u)),
            Nat.mul_comm q ((q + a) ^ (D - (d + 1))), ← Nat.mul_assoc]
      have hR : a ^ u * a * q ^ (d - u) * (q + a) ^ (D - (d + 1)) =
          a ^ u * q ^ (d - u) * (q + a) ^ (D - (d + 1)) * a := by
        rw [Nat.mul_assoc (a ^ u) a (q ^ (d - u)), Nat.mul_comm a (q ^ (d - u)),
            ← Nat.mul_assoc (a ^ u), Nat.mul_assoc (a ^ u * q ^ (d - u)),
            Nat.mul_comm a ((q + a) ^ (D - (d + 1))), ← Nat.mul_assoc]
      rw [hL, hR, ← Nat.mul_add, Nat.mul_assoc]

/-- Corollary: from the root `(0, 0)`, total `auxWeight` over all leaves of `T`
    (depth `≤ D`) equals `(q + a)^D` exactly. -/
theorem root_aux_norm (a q D : Nat) (T : DTree) (hdep : depth T ≤ D) :
    sumAuxWeight a q D (leafTranscripts 0 0 T) = (q + a) ^ D := by
  have h := leafTranscripts_aux_norm a q D T 0 0 (Nat.le_refl 0) (by omega)
  simp only [Nat.pow_zero, Nat.sub_zero, Nat.one_mul] at h
  exact h

end RecursiveSwitching.ReachableBranch
