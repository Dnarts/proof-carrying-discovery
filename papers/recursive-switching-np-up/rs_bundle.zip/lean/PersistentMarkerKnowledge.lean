/-
  PersistentMarkerKnowledge.lean — v0.1 (0 external imports, Lean 4.36.0 target)
  Formalizes Gate 194 & Lemma XXI.1 (Cycle XXI):
  Persistent Marker Knowledge, Role Disjointness (`B ∩ P = ∅`),
  Distinctness of Discovered Blockers (`|B| = s`), and Positive Width Bound (`|P| ≤ w * s`).

  100% constructive (0 sorryAx, 0 ofReduceBool, 0 Classical.choice).
-/

namespace RecursiveSwitching.PersistentMarkerKnowledge

abbrev Row := Nat
abbrev Addr := Nat

structure Term where
  lowerOk : Bool
  posLits : List (Row × Addr)
  negLits : List (Row × Addr)

abbrev DNF := List Term

structure MarkerModel where
  g : Row → Addr
  K : Row → Bool

def TrueMarker (M : MarkerModel) (p : Row × Addr) : Prop :=
  M.K p.1 = true ∧ M.g p.1 = p.2

def AllTrue (M : MarkerModel) (U : List (Row × Addr)) : Prop :=
  ∀ p, p ∈ U → TrueMarker M p

def MemRow (x : Row) (U : List (Row × Addr)) : Prop :=
  ∃ y : Addr, (x, y) ∈ U

def Normalized (t : Term) : Prop :=
  ∀ x y₁ y₂, (x, y₁) ∈ t.posLits → (x, y₂) ∈ t.negLits → False

def DNFNormalized (F : DNF) : Prop :=
  ∀ t, t ∈ F → Normalized t

def DNFWidth (w : Nat) (F : DNF) : Prop :=
  ∀ t, t ∈ F → t.posLits.length ≤ w

inductive NoDup {α : Type} : List α → Prop where
  | nil : NoDup []
  | cons : ∀ {a : α} {l : List α}, a ∉ l → NoDup l → NoDup (a :: l)

/-! ### 1. Constructive Boolean Membership Helpers -/

def memRowBool (x : Row) : List (Row × Addr) → Bool
  | [] => false
  | (r, _) :: rest => if r = x then true else memRowBool x rest

theorem memRowBool_eq_true (x : Row) :
    ∀ U : List (Row × Addr), memRowBool x U = true ↔ MemRow x U
  | [] => by
      constructor
      · intro h; cases h
      · rintro ⟨y, hy⟩; cases hy
  | (r, y₀) :: rest => by
      dsimp only [memRowBool]
      split
      · rename_i h
        subst h
        constructor
        · intro _; exact ⟨y₀, List.Mem.head rest⟩
        · intro _; rfl
      · rename_i h
        constructor
        · intro hm
          rcases (memRowBool_eq_true x rest).mp hm with ⟨y, hy⟩
          exact ⟨y, List.Mem.tail (r, y₀) hy⟩
        · rintro ⟨y, hy⟩
          cases hy with
          | head => exact absurd rfl h
          | tail _ htail => exact (memRowBool_eq_true x rest).mpr ⟨y, htail⟩

theorem memRowBool_eq_false (x : Row) (U : List (Row × Addr)) :
    memRowBool x U = false ↔ ¬ MemRow x U := by
  cases h : memRowBool x U
  · constructor
    · intro _ hm
      have ht : memRowBool x U = true := (memRowBool_eq_true x U).mpr hm
      rw [h] at ht; cases ht
    · intro _; rfl
  · constructor
    · intro hf; cases hf
    · intro hnm
      exact absurd ((memRowBool_eq_true x U).mp h) hnm

def memPairBool (p : Row × Addr) : List (Row × Addr) → Bool
  | [] => false
  | q :: rest => if q = p then true else memPairBool p rest

theorem memPairBool_eq_true (p : Row × Addr) :
    ∀ U : List (Row × Addr), memPairBool p U = true ↔ p ∈ U
  | [] => by
      constructor
      · intro h; cases h
      · intro h; cases h
  | q :: rest => by
      dsimp only [memPairBool]
      split
      · rename_i h
        subst h
        constructor
        · intro _; exact List.Mem.head rest
        · intro _; rfl
      · rename_i h
        constructor
        · intro hm
          exact List.Mem.tail q ((memPairBool_eq_true p rest).mp hm)
        · intro hm
          cases hm with
          | head => exact absurd rfl h
          | tail _ htail => exact (memPairBool_eq_true p rest).mpr htail

/-! ### 2. Term Eligibility and First-Blocker Search -/

def posLitsActive (M : MarkerModel) : List (Row × Addr) → Bool
  | [] => true
  | (x, y) :: rest =>
      if M.K x = true then
        if M.g x = y then posLitsActive M rest else false
      else false

theorem posLitsActive_sound (M : MarkerModel) :
    ∀ ps : List (Row × Addr), posLitsActive M ps = true → AllTrue M ps
  | [], _ => by intro p hp; cases hp
  | (x, y) :: rest, h => by
      dsimp only [posLitsActive] at h
      split at h
      · rename_i hK
        split at h
        · rename_i hg
          intro p hp
          cases hp with
          | head => exact ⟨hK, hg⟩
          | tail _ htail => exact posLitsActive_sound M rest h p htail
        · cases h
      · cases h

def posActive (M : MarkerModel) (t : Term) : Bool :=
  if t.lowerOk = true then posLitsActive M t.posLits else false

theorem posActive_allTrue (M : MarkerModel) (t : Term) (h : posActive M t = true) :
    AllTrue M t.posLits := by
  dsimp only [posActive] at h
  split at h
  · exact posLitsActive_sound M t.posLits h
  · cases h

def blockedByList (U : List (Row × Addr)) : List (Row × Addr) → Bool
  | [] => false
  | p :: rest => if memPairBool p U = true then true else blockedByList U rest

theorem blockedByList_false_not_mem (U : List (Row × Addr)) :
    ∀ ns : List (Row × Addr), blockedByList U ns = false → ∀ p, p ∈ ns → p ∉ U
  | [], _ => by intro p hp; cases hp
  | q :: rest, h => by
      dsimp only [blockedByList] at h
      split at h
      · cases h
      · rename_i hq
        intro p hp hpU
        cases hp with
        | head =>
            exact hq ((memPairBool_eq_true q U).mpr hpU)
        | tail _ htail =>
            exact blockedByList_false_not_mem U rest h p htail hpU

def eligible (M : MarkerModel) (U : List (Row × Addr)) (t : Term) : Bool :=
  if posActive M t = true then
    if blockedByList U t.negLits = false then true else false
  else false

theorem eligible_parts (M : MarkerModel) (U : List (Row × Addr)) (t : Term)
    (h : eligible M U t = true) :
    posActive M t = true ∧ blockedByList U t.negLits = false := by
  dsimp only [eligible] at h
  split at h
  · rename_i hp
    split at h
    · rename_i hb; exact ⟨hp, hb⟩
    · cases h
  · cases h

def findFirstEligible (M : MarkerModel) (U : List (Row × Addr)) : DNF → Option Term
  | [] => none
  | t :: rest => if eligible M U t = true then some t else findFirstEligible M U rest

theorem findFirstEligible_sound (M : MarkerModel) (U : List (Row × Addr)) :
    ∀ F : DNF, ∀ t : Term,
      findFirstEligible M U F = some t → t ∈ F ∧ eligible M U t = true
  | [], _, h => by cases h
  | t₀ :: rest, t, h => by
      dsimp only [findFirstEligible] at h
      split at h
      · rename_i he
        cases h
        exact ⟨List.Mem.head rest, he⟩
      · rcases findFirstEligible_sound M U rest t h with ⟨hmem, he⟩
        exact ⟨List.Mem.tail t₀ hmem, he⟩

def findFirstBlocker (M : MarkerModel) : List (Row × Addr) → Option (Row × Addr)
  | [] => none
  | (x, y) :: rest =>
      if M.K x = true then
        if M.g x = y then some (x, y) else findFirstBlocker M rest
      else findFirstBlocker M rest

theorem findFirstBlocker_sound (M : MarkerModel) :
    ∀ ns : List (Row × Addr), ∀ p : Row × Addr,
      findFirstBlocker M ns = some p → p ∈ ns ∧ TrueMarker M p
  | [], _, h => by cases h
  | (x, y) :: rest, p, h => by
      dsimp only [findFirstBlocker] at h
      split at h
      · rename_i hK
        split at h
        · rename_i hg
          cases h
          exact ⟨List.Mem.head rest, ⟨hK, hg⟩⟩
        · rcases findFirstBlocker_sound M rest p h with ⟨hmem, ht⟩
          exact ⟨List.Mem.tail (x, y) hmem, ht⟩
      · rcases findFirstBlocker_sound M rest p h with ⟨hmem, ht⟩
        exact ⟨List.Mem.tail (x, y) hmem, ht⟩

/-! ### 3. Newly Revealed Positive Rows and Canonical Process (Gate 194) -/

def newPosRows (U : List (Row × Addr)) : List (Row × Addr) → List Row
  | [] => []
  | (x, _) :: rest =>
      if memRowBool x U = true then newPosRows U rest
      else x :: newPosRows U rest

theorem newPosRows_length_le (U : List (Row × Addr)) :
    ∀ ps : List (Row × Addr), (newPosRows U ps).length ≤ ps.length
  | [] => by dsimp only [newPosRows]; omega
  | (x, _) :: rest => by
      dsimp only [newPosRows]
      have ih := newPosRows_length_le U rest
      split
      · simp only [List.length_cons]; omega
      · simp only [List.length_cons]; omega

theorem newPosRows_mem_posLits (U : List (Row × Addr)) :
    ∀ ps : List (Row × Addr), ∀ x : Row,
      x ∈ newPosRows U ps → (∃ y, (x, y) ∈ ps) ∧ ¬ MemRow x U
  | [], _, h => by cases h
  | (r, y₀) :: rest, x, h => by
      dsimp only [newPosRows] at h
      split at h
      · rename_i hIn
        rcases newPosRows_mem_posLits U rest x h with ⟨⟨y, hy⟩, hnotU⟩
        exact ⟨⟨y, List.Mem.tail (r, y₀) hy⟩, hnotU⟩
      · rename_i hnot
        cases h with
        | head =>
            have hfalse : memRowBool r U = false := by
              cases hb : memRowBool r U
              · rfl
              · exact absurd hb hnot
            exact ⟨⟨y₀, List.Mem.head rest⟩, (memRowBool_eq_false r U).mp hfalse⟩
        | tail _ htail =>
            rcases newPosRows_mem_posLits U rest x htail with ⟨⟨y, hy⟩, hnotU⟩
            exact ⟨⟨y, List.Mem.tail (r, y₀) hy⟩, hnotU⟩

structure CanonicalState where
  U : List (Row × Addr)
  B : List Row
  P : List Row

inductive StepResult where
  | done (ans : Bool)
  | cont (st : CanonicalState)

def initState : CanonicalState := ⟨[], [], []⟩

def step (M : MarkerModel) (F : DNF) (st : CanonicalState) : StepResult :=
  match findFirstEligible M st.U F with
  | none => .done false
  | some t =>
      let U₁ := t.posLits ++ st.U
      let P₁ := newPosRows st.U t.posLits ++ st.P
      match findFirstBlocker M t.negLits with
      | none => .done true
      | some blk =>
          .cont ⟨blk :: U₁, blk.1 :: st.B, P₁⟩

def run (M : MarkerModel) (F : DNF) : Nat → CanonicalState → StepResult
  | 0, st => .cont st
  | s + 1, st =>
      match step M F st with
      | .done ans => .done ans
      | .cont st' => run M F s st'

/-! ### 4. Core Invariant and Lemma XXI.1 (`B ∩ P = ∅`, `|B| = s`, `|P| ≤ w * s`) -/

structure StateInvariant (M : MarkerModel) (st : CanonicalState) : Prop where
  allTrue : AllTrue M st.U
  B_in_U : ∀ x, x ∈ st.B → MemRow x st.U
  P_in_U : ∀ x, x ∈ st.P → MemRow x st.U
  disjoint : ∀ x, x ∈ st.B → x ∉ st.P
  B_nodup : NoDup st.B

theorem initState_invariant (M : MarkerModel) : StateInvariant M initState := by
  refine ⟨?_, ?_, ?_, ?_, NoDup.nil⟩
  · intro p hp; cases hp
  · intro x hx; cases hx
  · intro x hx; cases hx
  · intro x hx; cases hx

theorem blocker_not_memRow_U (M : MarkerModel) (U : List (Row × Addr)) (t : Term)
    (hAll : AllTrue M U) (hNotBlk : blockedByList U t.negLits = false)
    (blk : Row × Addr) (hBlkMem : blk ∈ t.negLits) (hBlkTrue : TrueMarker M blk) :
    ¬ MemRow blk.1 U := by
  rintro ⟨y', hy'⟩
  have hTrue' : TrueMarker M (blk.1, y') := hAll (blk.1, y') hy'
  have hy_eq : y' = blk.2 := hTrue'.2.symm.trans hBlkTrue.2
  have hblkU : blk ∈ U := by
    cases blk with
    | mk bx by_ =>
      dsimp only at hy_eq
      rw [← hy_eq]
      exact hy'
  exact blockedByList_false_not_mem U t.negLits hNotBlk blk hBlkMem hblkU

theorem step_preserves_invariant (M : MarkerModel) (F : DNF) (st st' : CanonicalState)
    (hNorm : DNFNormalized F)
    (hInv : StateInvariant M st)
    (hStep : step M F st = .cont st') :
    StateInvariant M st' := by
  dsimp only [step] at hStep
  cases hFind : findFirstEligible M st.U F with
  | none => rw [hFind] at hStep; cases hStep
  | some t =>
      rw [hFind] at hStep
      simp only at hStep
      rcases findFirstEligible_sound M st.U F t hFind with ⟨htMem, hElig⟩
      rcases eligible_parts M st.U t hElig with ⟨hPosAct, hNotBlk⟩
      have hPosTrue : AllTrue M t.posLits := posActive_allTrue M t hPosAct
      have hNormT : Normalized t := hNorm t htMem
      cases hBlk : findFirstBlocker M t.negLits with
      | none => rw [hBlk] at hStep; cases hStep
      | some blk =>
          rw [hBlk] at hStep
          cases hStep
          rcases findFirstBlocker_sound M t.negLits blk hBlk with ⟨hBlkMem, hBlkTrue⟩
          have hBlkNotU : ¬ MemRow blk.1 st.U :=
            blocker_not_memRow_U M st.U t hInv.allTrue hNotBlk blk hBlkMem hBlkTrue
          have hBlkNotB : blk.1 ∉ st.B := fun hB => hBlkNotU (hInv.B_in_U blk.1 hB)
          have hBlkNotP : blk.1 ∉ st.P := fun hP => hBlkNotU (hInv.P_in_U blk.1 hP)
          have hBlkNotNewP : blk.1 ∉ newPosRows st.U t.posLits := by
            intro hNP
            rcases newPosRows_mem_posLits st.U t.posLits blk.1 hNP with ⟨⟨y₁, hy₁⟩, _⟩
            exact hNormT blk.1 y₁ blk.2 hy₁ hBlkMem
          refine ⟨?_, ?_, ?_, ?_, NoDup.cons hBlkNotB hInv.B_nodup⟩
          · -- AllTrue
            intro p hp
            cases hp with
            | head => exact hBlkTrue
            | tail _ htail =>
                rcases List.mem_append.mp htail with hp1 | hp2
                · exact hPosTrue p hp1
                · exact hInv.allTrue p hp2
          · -- B_in_U
            intro x hx
            cases hx with
            | head =>
                cases blk with
                | mk bx by_ =>
                  exact ⟨by_, List.Mem.head _⟩
            | tail _ htail =>
                rcases hInv.B_in_U x htail with ⟨y, hy⟩
                exact ⟨y, List.Mem.tail blk (List.mem_append.mpr (Or.inr hy))⟩
          · -- P_in_U
            intro x hx
            rcases List.mem_append.mp hx with hnp | hpOld
            · rcases newPosRows_mem_posLits st.U t.posLits x hnp with ⟨⟨y, hy⟩, _⟩
              exact ⟨y, List.Mem.tail blk (List.mem_append.mpr (Or.inl hy))⟩
            · rcases hInv.P_in_U x hpOld with ⟨y, hy⟩
              exact ⟨y, List.Mem.tail blk (List.mem_append.mpr (Or.inr hy))⟩
          · -- disjoint: B' ∩ P' = ∅
            intro x hxB hxP
            cases hxB with
            | head =>
                rcases List.mem_append.mp hxP with hnp | hpOld
                · exact hBlkNotNewP hnp
                · exact hBlkNotP hpOld
            | tail _ hxBold =>
                rcases List.mem_append.mp hxP with hnp | hpOld
                · rcases newPosRows_mem_posLits st.U t.posLits x hnp with ⟨_, hnotU⟩
                  exact hnotU (hInv.B_in_U x hxBold)
                · exact hInv.disjoint x hxBold hpOld

theorem step_lengths (M : MarkerModel) (F : DNF) (w : Nat) (st st' : CanonicalState)
    (hWidth : DNFWidth w F)
    (hStep : step M F st = .cont st') :
    st'.B.length = st.B.length + 1 ∧ st'.P.length ≤ st.P.length + w := by
  dsimp only [step] at hStep
  cases hFind : findFirstEligible M st.U F with
  | none => rw [hFind] at hStep; cases hStep
  | some t =>
      rw [hFind] at hStep
      simp only at hStep
      rcases findFirstEligible_sound M st.U F t hFind with ⟨htMem, _⟩
      have htw : t.posLits.length ≤ w := hWidth t htMem
      cases hBlk : findFirstBlocker M t.negLits with
      | none => rw [hBlk] at hStep; cases hStep
      | some blk =>
          rw [hBlk] at hStep
          cases hStep
          constructor
          · simp only [List.length_cons]
          · have hnp := newPosRows_length_le st.U t.posLits
            simp only [List.length_append]
            omega

/-- Lemma XXI.1 (Full Multi-Round Form):
    After `s` blocking rounds on a normalized DNF `F` of positive width ≤ `w`,
    the accumulated roles satisfy `|B| = s`, `NoDup B`, `|P| ≤ w * s`, and `B ∩ P = ∅`. -/
theorem lemma_XXI_1 (M : MarkerModel) (F : DNF) (w s : Nat) (st : CanonicalState)
    (hNorm : DNFNormalized F)
    (hWidth : DNFWidth w F)
    (hRun : run M F s initState = .cont st) :
    StateInvariant M st ∧ st.B.length = s ∧ st.P.length ≤ w * s := by
  suffices h : ∀ (k : Nat) (st₀ st₁ : CanonicalState),
      StateInvariant M st₀ →
      run M F k st₀ = .cont st₁ →
      StateInvariant M st₁ ∧
        st₁.B.length = st₀.B.length + k ∧
        st₁.P.length ≤ st₀.P.length + w * k by
    rcases h s initState st (initState_invariant M) hRun with ⟨hInv, hB, hP⟩
    refine ⟨hInv, ?_, ?_⟩
    · dsimp only [initState] at hB; simp only [List.length_nil] at hB; omega
    · dsimp only [initState] at hP; simp only [List.length_nil] at hP; omega
  intro k
  induction k with
  | zero =>
      intro st₀ st₁ hInv hR
      dsimp only [run] at hR
      cases hR
      exact ⟨hInv, by omega, by omega⟩
  | succ k ih =>
      intro st₀ st₁ hInv hR
      dsimp only [run] at hR
      cases hSt : step M F st₀ with
      | done _ => rw [hSt] at hR; cases hR
      | cont stMid =>
          rw [hSt] at hR
          have hInvMid := step_preserves_invariant M F st₀ stMid hNorm hInv hSt
          rcases step_lengths M F w st₀ stMid hWidth hSt with ⟨hBMid, hPMid⟩
          rcases ih stMid st₁ hInvMid hR with ⟨hInv1, hB1, hP1⟩
          refine ⟨hInv1, ?_, ?_⟩
          · omega
          · have hmul : w * (k + 1) = w * k + w := Nat.mul_succ w k
            omega

end RecursiveSwitching.PersistentMarkerKnowledge
