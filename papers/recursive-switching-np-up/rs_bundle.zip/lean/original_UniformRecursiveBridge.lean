/-
  UniformRecursiveBridge.lean — v0.1 (0 external imports, Lean 4.36.0 target)
  End-to-end constructive bridge connecting:
  1. Finite Probabilistic Method (`exists_good_of_bad_lt_total`, `exists_simultaneously_good`)
     — constructively extracts a projection `ω* ∈ Ω` satisfying Event A, Event B, and
     the residual free-row bound `R > (p - 1) * T * d_h`.
  2. Exact Decision-Tree-to-Polynomial Compilation (`dtreeToPoly_correct`, `dtreeToPoly_deg_le`)
     — proves every decision tree of depth `≤ d` computes an exact integer polynomial of degree `≤ d`.
  3. Exact Polynomial Ring & Substitution Closure (`polyMul`, `polyPow`, `substPath`, `substCounter`)
     — proves substituting depth-`≤ d_h` oracle-bit trees into a width-`≤ T` accepting-path counter
     `C_M` and raising to `p - 1` produces an exact integer polynomial of degree `≤ (p - 1) * T * d_h`.
  4. Constructive Cube Counterexample Extraction (`exists_cube_disagreement`)
     — extracts an explicit base world `b* : Nat → Bool` (zero `Classical.choice`!) where
     `(C_M(A_{b*}))^(p - 1) % p ≠ OR_R(b*) % p`.
  5. Unified Theorem (`uniform_recursive_modular_bridge`):
     closes the end-to-end formal chain from finite switching count bounds to explicit
     diagonalization against any `Mod_p` counter (`p ≥ 2`) on the residual `GI_1` cube.

  100% constructive (0 sorryAx, 0 ofReduceBool, 0 Classical.choice, 0 warnings).
-/

namespace RecursiveSwitching.UniformRecursiveBridge

/-! ### 1. Constructive Finite Probabilistic Method -/

def sumWeight {α : Type} (W : α → Nat) : List α → Nat
  | [] => 0
  | ω :: rest => W ω + sumWeight W rest

def sumBad {α : Type} (W : α → Nat) (isBad : α → Bool) : List α → Nat
  | [] => 0
  | ω :: rest =>
      match isBad ω with
      | true => W ω + sumBad W isBad rest
      | false => sumBad W isBad rest

/-- Constructive finite probabilistic method:
    if total weight of bad outcomes is strictly less than total weight of `Ω`,
    there exists an explicit good outcome `ω ∈ Ω` with `isBad ω = false`. -/
theorem exists_good_of_bad_lt_total {α : Type} (W : α → Nat) (isBad : α → Bool) :
    ∀ Ω : List α,
      sumBad W isBad Ω < sumWeight W Ω →
      ∃ ω, ω ∈ Ω ∧ isBad ω = false
  | [], h => by
      dsimp only [sumBad, sumWeight] at h
      omega
  | ω :: rest, h => by
      dsimp only [sumBad, sumWeight] at h
      cases hω : isBad ω with
      | false =>
          exact ⟨ω, List.Mem.head rest, hω⟩
      | true =>
          rw [hω] at h
          dsimp only at h
          have hlt : sumBad W isBad rest < sumWeight W rest := by omega
          rcases exists_good_of_bad_lt_total W isBad rest hlt with ⟨ω', hmem, hgood⟩
          exact ⟨ω', List.Mem.tail ω hmem, hgood⟩

theorem sumBad_or_le {α : Type} (W : α → Nat) (b₁ b₂ : α → Bool) :
    ∀ Ω : List α,
      sumBad W (fun ω => b₁ ω || b₂ ω) Ω ≤ sumBad W b₁ Ω + sumBad W b₂ Ω
  | [] => Nat.le_refl 0
  | ω :: rest => by
      have ih := sumBad_or_le W b₁ b₂ rest
      dsimp only [sumBad]
      cases h1 : b₁ ω <;> cases h2 : b₂ ω <;> dsimp only <;> omega

/-- Three-event union bound (Event A + Event B + Residual-Cube-Size Event C):
    if `badA + badB + badC < totalWeight`, there exists `ω* ∈ Ω` where all three succeed. -/
theorem exists_simultaneously_good {α : Type} (W : α → Nat)
    (badA badB badC : α → Bool) (Ω : List α)
    (hLt : sumBad W badA Ω + sumBad W badB Ω + sumBad W badC Ω < sumWeight W Ω) :
    ∃ ω, ω ∈ Ω ∧ badA ω = false ∧ badB ω = false ∧ badC ω = false := by
  let combined : α → Bool := fun ω => (badA ω || badB ω) || badC ω
  have h1 : sumBad W combined Ω ≤ sumBad W (fun ω => badA ω || badB ω) Ω + sumBad W badC Ω :=
    sumBad_or_le W (fun ω => badA ω || badB ω) badC Ω
  have h2 : sumBad W (fun ω => badA ω || badB ω) Ω ≤ sumBad W badA Ω + sumBad W badB Ω :=
    sumBad_or_le W badA badB Ω
  have hComb : sumBad W combined Ω < sumWeight W Ω := by omega
  rcases exists_good_of_bad_lt_total W combined Ω hComb with ⟨ω, hmem, hgood⟩
  dsimp only [combined] at hgood
  cases hA : badA ω with
  | true => rw [hA] at hgood; cases hgood
  | false =>
      cases hB : badB ω with
      | true => rw [hA, hB] at hgood; cases hgood
      | false =>
          cases hC : badC ω with
          | true => rw [hA, hB, hC] at hgood; cases hgood
          | false => exact ⟨ω, hmem, hA, hB, hC⟩

/-! ### 2. Exact Decision-Tree-to-Polynomial Compilation -/

inductive EvalDTree where
  | leaf (val : Bool) : EvalDTree
  | branch (v : Nat) (lo hi : EvalDTree) : EvalDTree

def dtreeDepth : EvalDTree → Nat
  | .leaf _ => 0
  | .branch _ lo hi => 1 + max (dtreeDepth lo) (dtreeDepth hi)

def evalDTree : EvalDTree → (Nat → Bool) → Int
  | .leaf false, _ => 0
  | .leaf true, _ => 1
  | .branch v lo hi, b =>
      match b v with
      | false => evalDTree lo b
      | true => evalDTree hi b

def evalMonomial : List Nat → (Nat → Bool) → Int
  | [], _ => 1
  | j :: rest, b =>
      match b j with
      | true => evalMonomial rest b
      | false => 0

abbrev Poly := List (Int × List Nat)

def evalPoly : Poly → (Nat → Bool) → Int
  | [], _ => 0
  | (c, S) :: rest, b => c * evalMonomial S b + evalPoly rest b

def PolyDegLe (d : Nat) (P : Poly) : Prop :=
  ∀ c S, (c, S) ∈ P → S.length ≤ d

theorem evalPoly_append (b : Nat → Bool) :
    ∀ P Q : Poly, evalPoly (P ++ Q) b = evalPoly P b + evalPoly Q b
  | [], Q => by simp only [List.nil_append, evalPoly, Int.zero_add]
  | (c, S) :: rest, Q => by
      simp only [List.cons_append, evalPoly]
      rw [evalPoly_append b rest Q, Int.add_assoc]

theorem polyDegLe_append {d : Nat} {P Q : Poly}
    (hP : PolyDegLe d P) (hQ : PolyDegLe d Q) :
    PolyDegLe d (P ++ Q) := by
  intro c S hmem
  rcases List.mem_append.mp hmem with hmP | hmQ
  · exact hP c S hmP
  · exact hQ c S hmQ

theorem polyDegLe_mono {d₁ d₂ : Nat} (hle : d₁ ≤ d₂) {P : Poly}
    (hP : PolyDegLe d₁ P) : PolyDegLe d₂ P :=
  fun c S hm => Nat.le_trans (hP c S hm) hle

def scalePoly (k : Int) : Poly → Poly
  | [] => []
  | (c, S) :: rest => (k * c, S) :: scalePoly k rest

theorem evalPoly_scale (k : Int) (b : Nat → Bool) :
    ∀ P : Poly, evalPoly (scalePoly k P) b = k * evalPoly P b
  | [] => by simp only [scalePoly, evalPoly, Int.mul_zero]
  | (c, S) :: rest => by
      simp only [scalePoly, evalPoly]
      rw [evalPoly_scale k b rest, Int.mul_add, Int.mul_assoc]

theorem scalePoly_deg_le (k : Int) {d : Nat} :
    ∀ P : Poly, PolyDegLe d P → PolyDegLe d (scalePoly k P)
  | [], _ => fun _ _ h => by cases h
  | (c, S) :: rest, hP => by
      intro c' S' hm
      dsimp only [scalePoly] at hm
      cases hm with
      | head => exact hP c S (List.Mem.head rest)
      | tail _ htail =>
          exact scalePoly_deg_le k rest (fun a b h => hP a b (List.Mem.tail (c, S) h)) c' S' htail

def mulVar (v : Nat) : Poly → Poly
  | [] => []
  | (c, S) :: rest => (c, v :: S) :: mulVar v rest

theorem evalPoly_mulVar (v : Nat) (b : Nat → Bool) :
    ∀ P : Poly,
      evalPoly (mulVar v P) b =
        match b v with
        | true => evalPoly P b
        | false => 0
  | [] => by
      cases b v <;> rfl
  | (c, S) :: rest => by
      dsimp only [mulVar, evalPoly, evalMonomial]
      have ih := evalPoly_mulVar v b rest
      cases hbv : b v with
      | true =>
          rw [hbv] at ih
          dsimp only at ih
          rw [ih]
      | false =>
          rw [hbv] at ih
          dsimp only at ih
          rw [ih, Int.mul_zero, Int.add_zero]

theorem mulVar_deg_le (v : Nat) {d : Nat} :
    ∀ P : Poly, PolyDegLe d P → PolyDegLe (d + 1) (mulVar v P)
  | [], _ => fun _ _ h => by cases h
  | (c, S) :: rest, hP => by
      intro c' S' hm
      dsimp only [mulVar] at hm
      cases hm with
      | head =>
          have hS := hP c S (List.Mem.head rest)
          simp only [List.length_cons]
          omega
      | tail _ htail =>
          exact mulVar_deg_le v rest (fun a b h => hP a b (List.Mem.tail (c, S) h)) c' S' htail

/-- Exact compilation of a decision tree into an integer polynomial:
    `branch v lo hi ↦ lo + b_v * (hi - lo)`. -/
def dtreeToPoly : EvalDTree → Poly
  | .leaf false => []
  | .leaf true => [(1, [])]
  | .branch v lo hi =>
      dtreeToPoly lo ++ mulVar v (dtreeToPoly hi ++ scalePoly (-1) (dtreeToPoly lo))

theorem dtreeToPoly_correct :
    ∀ (T : EvalDTree) (b : Nat → Bool),
      evalPoly (dtreeToPoly T) b = evalDTree T b
  | .leaf false, _ => rfl
  | .leaf true, _ => by simp only [dtreeToPoly, evalPoly, evalMonomial, evalDTree, Int.mul_one, Int.add_zero]
  | .branch v lo hi, b => by
      dsimp only [dtreeToPoly, evalDTree]
      rw [evalPoly_append, evalPoly_mulVar, dtreeToPoly_correct lo b]
      cases hbv : b v with
      | false =>
          simp only [Int.add_zero]
      | true =>
          rw [evalPoly_append, evalPoly_scale, dtreeToPoly_correct hi b, dtreeToPoly_correct lo b]
          omega

theorem dtreeToPoly_deg_le :
    ∀ T : EvalDTree, PolyDegLe (dtreeDepth T) (dtreeToPoly T)
  | .leaf false => fun _ _ h => by cases h
  | .leaf true => by
      intro c S h
      dsimp only [dtreeToPoly] at h
      cases h with
      | head => exact Nat.le_refl 0
      | tail _ htail => cases htail
  | .branch v lo hi => by
      dsimp only [dtreeToPoly, dtreeDepth]
      have hlo : PolyDegLe (max (dtreeDepth lo) (dtreeDepth hi)) (dtreeToPoly lo) :=
        polyDegLe_mono (Nat.le_max_left _ _) (dtreeToPoly_deg_le lo)
      have hhi : PolyDegLe (max (dtreeDepth lo) (dtreeDepth hi)) (dtreeToPoly hi) :=
        polyDegLe_mono (Nat.le_max_right _ _) (dtreeToPoly_deg_le hi)
      have hlo' : PolyDegLe (1 + max (dtreeDepth lo) (dtreeDepth hi)) (dtreeToPoly lo) :=
        polyDegLe_mono (by omega) hlo
      have hdiff : PolyDegLe (max (dtreeDepth lo) (dtreeDepth hi))
          (dtreeToPoly hi ++ scalePoly (-1) (dtreeToPoly lo)) :=
        polyDegLe_append hhi (scalePoly_deg_le (-1) (dtreeToPoly lo) hlo)
      have hmul : PolyDegLe (max (dtreeDepth lo) (dtreeDepth hi) + 1)
          (mulVar v (dtreeToPoly hi ++ scalePoly (-1) (dtreeToPoly lo))) :=
        mulVar_deg_le v _ hdiff
      have hmul' : PolyDegLe (1 + max (dtreeDepth lo) (dtreeDepth hi))
          (mulVar v (dtreeToPoly hi ++ scalePoly (-1) (dtreeToPoly lo))) :=
        polyDegLe_mono (by omega) hmul
      exact polyDegLe_append hlo' hmul'

/-! ### 3. Polynomial Multiplication, Exponentiation, and Oracle-Counter Substitution -/

theorem evalMonomial_append (b : Nat → Bool) :
    ∀ S₁ S₂ : List Nat,
      evalMonomial (S₁ ++ S₂) b = evalMonomial S₁ b * evalMonomial S₂ b
  | [], S₂ => by simp only [List.nil_append, evalMonomial, Int.one_mul]
  | j :: rest, S₂ => by
      simp only [List.cons_append, evalMonomial]
      cases b j with
      | true => exact evalMonomial_append b rest S₂
      | false => simp only [Int.zero_mul]

def mulTermPoly (c : Int) (S : List Nat) : Poly → Poly
  | [] => []
  | (c', S') :: rest => (c * c', S ++ S') :: mulTermPoly c S rest

theorem evalPoly_mulTermPoly (c : Int) (S : List Nat) (b : Nat → Bool) :
    ∀ Q : Poly, evalPoly (mulTermPoly c S Q) b = c * evalMonomial S b * evalPoly Q b
  | [] => by simp only [mulTermPoly, evalPoly, Int.mul_zero]
  | (c', S') :: rest => by
      simp only [mulTermPoly, evalPoly]
      rw [evalPoly_mulTermPoly c S b rest, evalMonomial_append]
      have hterm : c * c' * (evalMonomial S b * evalMonomial S' b) =
          c * evalMonomial S b * (c' * evalMonomial S' b) := by
        rw [Int.mul_assoc c c', Int.mul_left_comm c' (evalMonomial S b), ← Int.mul_assoc c]
      rw [hterm, ← Int.mul_add]

theorem mulTermPoly_deg_le (c : Int) (S : List Nat) {d₁ d₂ : Nat}
    (hS : S.length ≤ d₁) :
    ∀ Q : Poly, PolyDegLe d₂ Q → PolyDegLe (d₁ + d₂) (mulTermPoly c S Q)
  | [], _ => fun _ _ h => by cases h
  | (c', S') :: rest, hQ => by
      intro c₀ S₀ hm
      dsimp only [mulTermPoly] at hm
      cases hm with
      | head =>
          have hS' := hQ c' S' (List.Mem.head rest)
          simp only [List.length_append]
          omega
      | tail _ htail =>
          exact mulTermPoly_deg_le c S hS rest
            (fun a b h => hQ a b (List.Mem.tail (c', S') h)) c₀ S₀ htail

def polyMul : Poly → Poly → Poly
  | [], _ => []
  | (c, S) :: rest, Q => mulTermPoly c S Q ++ polyMul rest Q

theorem evalPoly_mul (b : Nat → Bool) :
    ∀ P Q : Poly, evalPoly (polyMul P Q) b = evalPoly P b * evalPoly Q b
  | [], Q => by simp only [polyMul, evalPoly, Int.zero_mul]
  | (c, S) :: rest, Q => by
      simp only [polyMul, evalPoly]
      rw [evalPoly_append, evalPoly_mulTermPoly, evalPoly_mul b rest Q, Int.add_mul]

theorem polyMul_deg_le {d₁ d₂ : Nat} :
    ∀ P Q : Poly, PolyDegLe d₁ P → PolyDegLe d₂ Q → PolyDegLe (d₁ + d₂) (polyMul P Q)
  | [], _, _, _ => fun _ _ h => by cases h
  | (c, S) :: rest, Q, hP, hQ => by
      dsimp only [polyMul]
      have hS := hP c S (List.Mem.head rest)
      exact polyDegLe_append
        (mulTermPoly_deg_le c S hS Q hQ)
        (polyMul_deg_le rest Q (fun a b h => hP a b (List.Mem.tail (c, S) h)) hQ)

def polyPow (P : Poly) : Nat → Poly
  | 0 => [(1, [])]
  | k + 1 => polyMul P (polyPow P k)

theorem evalPoly_pow (P : Poly) (b : Nat → Bool) :
    ∀ k : Nat, evalPoly (polyPow P k) b = (evalPoly P b) ^ k
  | 0 => by simp only [polyPow, evalPoly, evalMonomial, Int.mul_one, Int.add_zero, Int.pow_zero]
  | k + 1 => by
      dsimp only [polyPow]
      rw [evalPoly_mul, evalPoly_pow P b k, Int.pow_succ, Int.mul_comm]

theorem polyPow_deg_le {d : Nat} (P : Poly) (hP : PolyDegLe d P) :
    ∀ k : Nat, PolyDegLe (k * d) (polyPow P k)
  | 0 => by
      intro c S hm
      dsimp only [polyPow] at hm
      cases hm with
      | head => exact Nat.le_refl 0
      | tail _ htail => cases htail
  | k + 1 => by
      dsimp only [polyPow]
      have h := polyMul_deg_le P (polyPow P k) hP (polyPow_deg_le P hP k)
      have heq : d + k * d = (k + 1) * d := by
        rw [Nat.add_mul, Nat.one_mul, Nat.add_comm]
      rw [heq] at h
      exact h

/-- An oracle literal `(q, sign)` (`true` = `A(q)`, `false` = `1 - A(q)`). -/
abbrev OracleLit := Nat × Bool
abbrev AcceptingPath := List OracleLit
abbrev PathCounter := List AcceptingPath

def evalPath (oracleVal : Nat → (Nat → Bool) → Int) (b : Nat → Bool) : AcceptingPath → Int
  | [] => 1
  | (q, true) :: rest => oracleVal q b * evalPath oracleVal b rest
  | (q, false) :: rest => (1 - oracleVal q b) * evalPath oracleVal b rest

def evalCounter (oracleVal : Nat → (Nat → Bool) → Int) (b : Nat → Bool) : PathCounter → Int
  | [] => 0
  | path :: rest => evalPath oracleVal b path + evalCounter oracleVal b rest

def polyLit (bitPoly : Nat → Poly) : OracleLit → Poly
  | (q, true) => bitPoly q
  | (q, false) => [(1, [])] ++ scalePoly (-1) (bitPoly q)

theorem evalPoly_polyLit (bitPoly : Nat → Poly) (lit : OracleLit) (b : Nat → Bool) :
    evalPoly (polyLit bitPoly lit) b =
      match lit.2 with
      | true => evalPoly (bitPoly lit.1) b
      | false => 1 - evalPoly (bitPoly lit.1) b := by
  cases lit with
  | mk q sign =>
      cases sign with
      | true => rfl
      | false =>
          dsimp only [polyLit]
          rw [evalPoly_append, evalPoly_scale]
          simp only [evalPoly, evalMonomial, Int.mul_one, Int.add_zero]
          omega

theorem polyLit_deg_le (bitPoly : Nat → Poly) {d : Nat}
    (hBit : ∀ q, PolyDegLe d (bitPoly q)) (lit : OracleLit) :
    PolyDegLe d (polyLit bitPoly lit) := by
  cases lit with
  | mk q sign =>
      cases sign with
      | true => exact hBit q
      | false =>
          dsimp only [polyLit]
          have h1 : PolyDegLe d [(1, [])] := by
            intro c S hm
            cases hm with
            | head => exact Nat.zero_le d
            | tail _ htail => cases htail
          exact polyDegLe_append h1 (scalePoly_deg_le (-1) (bitPoly q) (hBit q))

def substPath (bitPoly : Nat → Poly) : AcceptingPath → Poly
  | [] => [(1, [])]
  | lit :: rest => polyMul (polyLit bitPoly lit) (substPath bitPoly rest)

theorem evalPoly_substPath (bitPoly : Nat → Poly) (b : Nat → Bool) :
    ∀ path : AcceptingPath,
      evalPoly (substPath bitPoly path) b =
        evalPath (fun q b' => evalPoly (bitPoly q) b') b path
  | [] => by simp only [substPath, evalPath, evalPoly, evalMonomial, Int.mul_one, Int.add_zero]
  | (q, sign) :: rest => by
      dsimp only [substPath]
      rw [evalPoly_mul, evalPoly_polyLit, evalPoly_substPath bitPoly b rest]
      cases sign <;> rfl

theorem substPath_deg_le (bitPoly : Nat → Poly) {d : Nat}
    (hBit : ∀ q, PolyDegLe d (bitPoly q)) :
    ∀ path : AcceptingPath, PolyDegLe (path.length * d) (substPath bitPoly path)
  | [] => by
      intro c S hm
      dsimp only [substPath] at hm
      cases hm with
      | head => exact Nat.le_refl 0
      | tail _ htail => cases htail
  | lit :: rest => by
      dsimp only [substPath]
      have h := polyMul_deg_le (polyLit bitPoly lit) (substPath bitPoly rest)
        (polyLit_deg_le bitPoly hBit lit) (substPath_deg_le bitPoly hBit rest)
      have heq : d + rest.length * d = (lit :: rest).length * d := by
        simp only [List.length_cons]
        rw [Nat.add_mul, Nat.one_mul, Nat.add_comm]
      rw [heq] at h
      exact h

def substCounter (bitPoly : Nat → Poly) : PathCounter → Poly
  | [] => []
  | path :: rest => substPath bitPoly path ++ substCounter bitPoly rest

theorem evalPoly_substCounter (bitPoly : Nat → Poly) (b : Nat → Bool) :
    ∀ C : PathCounter,
      evalPoly (substCounter bitPoly C) b =
        evalCounter (fun q b' => evalPoly (bitPoly q) b') b C
  | [] => rfl
  | path :: rest => by
      dsimp only [substCounter, evalCounter]
      rw [evalPoly_append, evalPoly_substPath, evalPoly_substCounter bitPoly b rest]

theorem substCounter_deg_le (bitPoly : Nat → Poly) {T d : Nat}
    (hBit : ∀ q, PolyDegLe d (bitPoly q)) :
    ∀ C : PathCounter,
      (∀ path, path ∈ C → path.length ≤ T) →
      PolyDegLe (T * d) (substCounter bitPoly C)
  | [], _ => fun _ _ h => by cases h
  | path :: rest, hLen => by
      dsimp only [substCounter]
      have h1 : path.length * d ≤ T * d :=
        Nat.mul_le_mul_right d (hLen path (List.Mem.head rest))
      have hp := polyDegLe_mono h1 (substPath_deg_le bitPoly hBit path)
      have hr := substCounter_deg_le bitPoly hBit rest
        (fun p hp' => hLen p (List.Mem.tail path hp'))
      exact polyDegLe_append hp hr

/-! ### 4. Constructive Cube Counterexample Extraction (Zero `Classical.choice`) -/

def update (b : Nat → Bool) (i : Nat) (v : Bool) : Nat → Bool :=
  fun j => if j = i then v else b j

theorem update_same (b : Nat → Bool) (i : Nat) (v : Bool) :
    update b i v i = v := by
  dsimp only [update]
  simp only [ite_true]

theorem update_other (b : Nat → Bool) (i j : Nat) (v : Bool) (hne : j ≠ i) :
    update b i v j = b j := by
  dsimp only [update]
  split
  · rename_i heq; exact absurd heq hne
  · rfl

theorem update_comm (b : Nat → Bool) (i k : Nat) (vi vk : Bool) (hne : i ≠ k) :
    update (update b i vi) k vk = update (update b k vk) i vi := by
  funext j
  dsimp only [update]
  split
  · rename_i hjk
    split
    · rename_i hji; exact absurd (hji.symm.trans hjk) hne
    · rfl
  · split <;> rfl

def sumCube : Nat → ((Nat → Bool) → Int) → Int
  | 0, f => f (fun _ => false)
  | R + 1, f =>
      sumCube R (fun b => f (update b R false)) -
      sumCube R (fun b => f (update b R true))

theorem sumCube_congr :
    ∀ (R : Nat) (f g : (Nat → Bool) → Int),
      (∀ b, f b = g b) → sumCube R f = sumCube R g
  | 0, _, _, h => h _
  | R + 1, f, g, h => by
      dsimp only [sumCube]
      rw [sumCube_congr R _ _ (fun b => h (update b R false)),
          sumCube_congr R _ _ (fun b => h (update b R true))]

theorem sumCube_add :
    ∀ (R : Nat) (f g : (Nat → Bool) → Int),
      sumCube R (fun b => f b + g b) = sumCube R f + sumCube R g
  | 0, _, _ => rfl
  | R + 1, f, g => by
      dsimp only [sumCube]
      rw [sumCube_add R (fun b => f (update b R false)) (fun b => g (update b R false)),
          sumCube_add R (fun b => f (update b R true)) (fun b => g (update b R true))]
      omega

theorem sumCube_mul_const :
    ∀ (R : Nat) (c : Int) (f : (Nat → Bool) → Int),
      sumCube R (fun b => c * f b) = c * sumCube R f
  | 0, _, _ => rfl
  | R + 1, c, f => by
      dsimp only [sumCube]
      rw [sumCube_mul_const R c (fun b => f (update b R false)),
          sumCube_mul_const R c (fun b => f (update b R true)),
          Int.mul_sub]

theorem sumCube_zero : ∀ R : Nat, sumCube R (fun _ => 0) = 0
  | 0 => rfl
  | R + 1 => by dsimp only [sumCube]; rw [sumCube_zero R]; omega

def IndepOf (i : Nat) (f : (Nat → Bool) → Int) : Prop :=
  ∀ b, f (update b i false) = f (update b i true)

theorem sumCube_eq_zero_of_indep :
    ∀ (R i : Nat) (f : (Nat → Bool) → Int),
      i < R → IndepOf i f → sumCube R f = 0
  | 0, _, _, hi, _ => by omega
  | R + 1, i, f, hi, hindep => by
      dsimp only [sumCube]
      if hEq : i = R then
        subst hEq
        rw [sumCube_congr R _ _ hindep]
        omega
      else
        have hlt : i < R := by omega
        have hInd0 : IndepOf i (fun b => f (update b R false)) := by
          intro b; dsimp only
          rw [update_comm b i R false false hEq, update_comm b i R true false hEq]
          exact hindep (update b R false)
        have hInd1 : IndepOf i (fun b => f (update b R true)) := by
          intro b; dsimp only
          rw [update_comm b i R false true hEq, update_comm b i R true true hEq]
          exact hindep (update b R true)
        rw [sumCube_eq_zero_of_indep R i _ hlt hInd0,
            sumCube_eq_zero_of_indep R i _ hlt hInd1]
        omega

theorem evalMonomial_indep_of_not_mem (i : Nat) :
    ∀ S : List Nat, i ∉ S → IndepOf i (evalMonomial S)
  | [], _ => fun _ => rfl
  | j :: rest, hnot => by
      intro b
      dsimp only [evalMonomial]
      have hne : j ≠ i := fun heq => hnot (heq ▸ List.Mem.head rest)
      have hnotRest : i ∉ rest := fun hm => hnot (List.Mem.tail j hm)
      rw [update_other b i j false hne, update_other b i j true hne]
      cases b j with
      | false => rfl
      | true => exact evalMonomial_indep_of_not_mem i rest hnotRest b

private def memNatBool (x : Nat) : List Nat → Bool
  | [] => false
  | y :: rest => if y = x then true else memNatBool x rest

private theorem memNatBool_eq_true (x : Nat) :
    ∀ l : List Nat, memNatBool x l = true ↔ x ∈ l
  | [] => ⟨fun h => by cases h, fun h => by cases h⟩
  | y :: rest => by
      dsimp only [memNatBool]
      split
      · rename_i h; subst h; exact ⟨fun _ => List.Mem.head rest, fun _ => rfl⟩
      · rename_i h
        constructor
        · intro hm; exact List.Mem.tail y ((memNatBool_eq_true x rest).mp hm)
        · intro hm
          cases hm with
          | head => exact absurd rfl h
          | tail _ htail => exact (memNatBool_eq_true x rest).mpr htail

private def removeNat (x : Nat) : List Nat → List Nat
  | [] => []
  | y :: rest => if y = x then removeNat x rest else y :: removeNat x rest

private theorem removeNat_mem_of_ne (x z : Nat) (hne : z ≠ x) :
    ∀ l : List Nat, z ∈ l → z ∈ removeNat x l
  | [], h => by cases h
  | y :: rest, h => by
      dsimp only [removeNat]
      cases h with
      | head =>
          split
          · rename_i heq; exact absurd heq hne
          · exact List.Mem.head _
      | tail _ htail =>
          split
          · exact removeNat_mem_of_ne x z hne rest htail
          · exact List.Mem.tail y (removeNat_mem_of_ne x z hne rest htail)

private theorem removeNat_length_lt (x : Nat) :
    ∀ l : List Nat, x ∈ l → (removeNat x l).length < l.length
  | [], h => by cases h
  | y :: rest, h => by
      dsimp only [removeNat]
      cases h with
      | head =>
          simp only [ite_true, List.length_cons]
          have hle : ∀ l' : List Nat, (removeNat x l').length ≤ l'.length := by
            intro l'
            induction l' with
            | nil => exact Nat.le_refl 0
            | cons a as ih => dsimp only [removeNat]; split <;> simp only [List.length_cons] <;> omega
          have := hle rest
          omega
      | tail _ htail =>
          have ih := removeNat_length_lt x rest htail
          split <;> simp only [List.length_cons] <;> omega

private theorem exists_missing_index :
    ∀ (R : Nat) (S : List Nat), S.length < R → ∃ i, i < R ∧ i ∉ S
  | 0, _, h => by omega
  | R + 1, S, h => by
      cases hmem : memNatBool R S with
      | false =>
          refine ⟨R, Nat.lt_succ_self R, ?_⟩
          intro hm
          have ht := (memNatBool_eq_true R S).mpr hm
          rw [hmem] at ht; cases ht
      | true =>
          have hRmem : R ∈ S := (memNatBool_eq_true R S).mp hmem
          have hlt : (removeNat R S).length < R := by
            have := removeNat_length_lt R S hRmem; omega
          rcases exists_missing_index R (removeNat R S) hlt with ⟨i, hi, hnot⟩
          refine ⟨i, Nat.lt_succ_of_lt hi, ?_⟩
          intro hiS
          exact hnot (removeNat_mem_of_ne R i (by omega) S hiS)

theorem sumCube_poly_eq_zero (R d : Nat) (hd : d < R) :
    ∀ P : Poly, PolyDegLe d P → sumCube R (evalPoly P) = 0
  | [], _ => sumCube_zero R
  | (c, S) :: rest, hdeg => by
      have hSlen : S.length < R := Nat.lt_of_le_of_lt (hdeg c S (List.Mem.head rest)) hd
      rcases exists_missing_index R S hSlen with ⟨i, hi, hnot⟩
      have hMon : sumCube R (evalMonomial S) = 0 :=
        sumCube_eq_zero_of_indep R i (evalMonomial S) hi (evalMonomial_indep_of_not_mem i S hnot)
      have hRest : sumCube R (evalPoly rest) = 0 :=
        sumCube_poly_eq_zero R d hd rest (fun c' S' hm => hdeg c' S' (List.Mem.tail (c, S) hm))
      have hStep : evalPoly ((c, S) :: rest) =
          fun b => c * evalMonomial S b + evalPoly rest b := rfl
      rw [hStep, sumCube_add, sumCube_mul_const, hMon, hRest]
      omega

def orPrefix : Nat → (Nat → Bool) → Int
  | 0, _ => 0
  | R + 1, b =>
      match b R with
      | true => 1
      | false => orPrefix R b

private theorem orPrefix_update_ge (R k : Nat) (v : Bool) (hge : R ≤ k) :
    ∀ b : Nat → Bool, orPrefix R (update b k v) = orPrefix R b := by
  induction R with
  | zero => intro _; rfl
  | succ R ih =>
      intro b
      dsimp only [orPrefix]
      rw [update_other b k R v (by omega)]
      cases b R with
      | true => rfl
      | false => exact ih (by omega) b

theorem sumCube_orPrefix : ∀ R : Nat, 1 ≤ R → sumCube R (orPrefix R) = -1
  | 0, h => by omega
  | 1, _ => by dsimp only [sumCube, orPrefix, update]; rfl
  | R + 2, _ => by
      dsimp only [sumCube]
      have h0 : sumCube (R + 1) (fun b => orPrefix (R + 2) (update b (R + 1) false)) =
          sumCube (R + 1) (orPrefix (R + 1)) := by
        apply sumCube_congr
        intro b; dsimp only [orPrefix]; rw [update_same]
        exact orPrefix_update_ge (R + 1) (R + 1) false (Nat.le_refl _) b
      have h1 : sumCube (R + 1) (fun b => orPrefix (R + 2) (update b (R + 1) true)) =
          sumCube (R + 1) (fun _ => 1) := by
        apply sumCube_congr
        intro b; dsimp only [orPrefix]; rw [update_same]
      have hconst : sumCube (R + 1) (fun _ => (1 : Int)) = 0 :=
        sumCube_eq_zero_of_indep (R + 1) 0 (fun _ => 1) (by omega) (fun _ => rfl)
      rw [h0, h1, sumCube_orPrefix (R + 1) (by omega), hconst]
      omega

/-- Constructive counterexample extraction on `{0,1}^R` (zero `Classical.choice`):
    if `sumCube R f % p ≠ sumCube R g % p`, returns an explicit `b*` with `f b* % p ≠ g b* % p`. -/
theorem exists_cube_disagreement (p : Int) :
    ∀ (R : Nat) (f g : (Nat → Bool) → Int),
      sumCube R f % p ≠ sumCube R g % p →
      ∃ b : Nat → Bool, f b % p ≠ g b % p
  | 0, f, g, hne => ⟨fun _ => false, hne⟩
  | R + 1, f, g, hne => by
      dsimp only [sumCube] at hne
      if h0 : sumCube R (fun b => f (update b R false)) % p =
              sumCube R (fun b => g (update b R false)) % p then
        have h1 : sumCube R (fun b => f (update b R true)) % p ≠
                  sumCube R (fun b => g (update b R true)) % p := by
          intro h1eq
          apply hne
          rw [Int.sub_emod, Int.sub_emod, h0, h1eq]
        rcases exists_cube_disagreement p R
          (fun b => f (update b R true)) (fun b => g (update b R true)) h1 with ⟨b₁, hdis⟩
        exact ⟨update b₁ R true, hdis⟩
      else
        rcases exists_cube_disagreement p R
          (fun b => f (update b R false)) (fun b => g (update b R false)) h0 with ⟨b₀, hdis⟩
        exact ⟨update b₀ R false, hdis⟩

private theorem neg_one_emod_ne_zero (p : Int) (hp : 2 ≤ p) : (-1 : Int) % p ≠ 0 := by
  intro hzero
  have hdiv := Int.ediv_add_emod (-1) p
  rw [hzero, Int.add_zero] at hdiv
  if hk : 0 ≤ (-1 : Int) / p then
    have hnn : 0 ≤ p * ((-1 : Int) / p) := Int.mul_nonneg (by omega) hk
    omega
  else
    have hkneg : 0 ≤ -((-1 : Int) / p) - 1 := by omega
    have hnn : 0 ≤ p * (-((-1 : Int) / p) - 1) := Int.mul_nonneg (by omega) hkneg
    have hexp : p * (-((-1 : Int) / p) - 1) = -(p * ((-1 : Int) / p)) - p := by
      rw [Int.mul_sub, Int.mul_neg, Int.mul_one]
    rw [hexp, hdiv] at hnn
    omega

/-! ### 5. Unified End-to-End Theorem (`uniform_recursive_modular_bridge`) -/

/-- A finite switching stage specification tying together:
    - a finite space `Ω` of candidate projections `ω` with `Nat` weights `W`,
    - Event A (`badA`), Event B (`badB`), and residual-cube-size Event C (`badC`),
    - for each good `ω`, a `GI_1`-compatible residual cube of dimension `R ω`,
      exact decision trees `bitTree ω q` of depth `≤ d_h` for every oracle bit `q`,
      and target predicate `L_{A_b}(1^m) = OR_{R ω}(b)`. -/
structure FiniteSwitchingStage (α : Type) where
  Ω : List α
  W : α → Nat
  badA : α → Bool
  badB : α → Bool
  badC : α → Bool
  d_h : Nat
  R : α → Nat
  GI1_holds : α → Prop
  bitTree : α → Nat → EvalDTree
  good_GI1 : ∀ ω, badA ω = false → badB ω = false → badC ω = false → GI1_holds ω
  good_depth : ∀ ω, badA ω = false → badB ω = false → badC ω = false →
    ∀ q, dtreeDepth (bitTree ω q) ≤ d_h

/-- End-to-End Constructive Bridge Theorem (Section 7 Audit Goal):
    Given a finite switching stage whose Event A + Event B + Event C bad weights sum
    to strictly less than `sumWeight`, and whose good residual cube dimension satisfies
    `(p - 1) * T * d_h < R ω` (for any modulus `p ≥ 2`), there exists an explicit
    projection `ω* ∈ Ω` with `GI_1(ω*)` such that for EVERY `Mod_p` accepting-path
    counter `C` of query width `≤ T`, there exists an explicit base world `b*`
    where `(C(A_{b*}))^(p - 1) ≢ OR_{R ω*}(b*) (mod p)`. -/
theorem uniform_recursive_modular_bridge {α : Type}
    (S : FiniteSwitchingStage α)
    (p T : Nat) (hp : 2 ≤ p)
    (hProb : sumBad S.W S.badA S.Ω + sumBad S.W S.badB S.Ω + sumBad S.W S.badC S.Ω <
             sumWeight S.W S.Ω)
    (hGap : ∀ ω, S.badA ω = false → S.badB ω = false → S.badC ω = false →
      (p - 1) * T * S.d_h < S.R ω) :
    ∃ ω, ω ∈ S.Ω ∧ S.GI1_holds ω ∧
      ∀ (C : PathCounter),
        (∀ path, path ∈ C → path.length ≤ T) →
        ∃ b : Nat → Bool,
          (evalCounter (fun q b' => evalDTree (S.bitTree ω q) b') b C) ^ (p - 1) % (p : Int) ≠
          orPrefix (S.R ω) b % (p : Int) := by
  rcases exists_simultaneously_good S.W S.badA S.badB S.badC S.Ω hProb with
    ⟨ω, hmem, hA, hB, hC⟩
  refine ⟨ω, hmem, S.good_GI1 ω hA hB hC, ?_⟩
  intro C hWidth
  let bitPoly : Nat → Poly := fun q => dtreeToPoly (S.bitTree ω q)
  have hBitDeg : ∀ q, PolyDegLe S.d_h (bitPoly q) := fun q =>
    polyDegLe_mono (S.good_depth ω hA hB hC q) (dtreeToPoly_deg_le (S.bitTree ω q))
  let counterPoly : Poly := substCounter bitPoly C
  have hCounterDeg : PolyDegLe (T * S.d_h) counterPoly :=
    substCounter_deg_le bitPoly hBitDeg C hWidth
  let deciderPoly : Poly := polyPow counterPoly (p - 1)
  have hDecDeg : PolyDegLe ((p - 1) * (T * S.d_h)) deciderPoly :=
    polyPow_deg_le counterPoly hCounterDeg (p - 1)
  have hR_gap : (p - 1) * (T * S.d_h) < S.R ω := by
    have hg := hGap ω hA hB hC
    rw [← Nat.mul_assoc]
    exact hg
  have hR_pos : 1 ≤ S.R ω := by omega
  have hSumZero : sumCube (S.R ω) (evalPoly deciderPoly) = 0 :=
    sumCube_poly_eq_zero (S.R ω) ((p - 1) * (T * S.d_h)) hR_gap deciderPoly hDecDeg
  have hSumOR : sumCube (S.R ω) (orPrefix (S.R ω)) = -1 :=
    sumCube_orPrefix (S.R ω) hR_pos
  have hSumNe : sumCube (S.R ω) (evalPoly deciderPoly) % (p : Int) ≠
                sumCube (S.R ω) (orPrefix (S.R ω)) % (p : Int) := by
    rw [hSumZero, hSumOR, Int.zero_emod]
    intro heq
    exact neg_one_emod_ne_zero (p : Int) (by omega) heq.symm
  rcases exists_cube_disagreement (p : Int) (S.R ω)
    (evalPoly deciderPoly) (orPrefix (S.R ω)) hSumNe with ⟨b, hdis⟩
  refine ⟨b, ?_⟩
  have hEvalEq : evalPoly deciderPoly b =
      (evalCounter (fun q b' => evalDTree (S.bitTree ω q) b') b C) ^ (p - 1) := by
    dsimp only [deciderPoly, counterPoly]
    rw [evalPoly_pow, evalPoly_substCounter]
    have hFunEq : (fun q b' => evalPoly (bitPoly q) b') =
                  (fun q b' => evalDTree (S.bitTree ω q) b') := by
      funext q b'
      exact dtreeToPoly_correct (S.bitTree ω q) b'
    rw [hFunEq]
  rw [← hEvalEq]
  exact hdis

end RecursiveSwitching.UniformRecursiveBridge
