/-
  TraceCapture.lean — v0.1 (0 external imports, Lean 4.36.0 target)
  Formalizes Gate 195 & Theorem XXI.2 (Cycle XXI):
  1. Exact trace reproduction of `s` blocking rounds under a random row split
     `isHid : Row → Bool` whenever `B ⊆ R_hid` and `P ∩ R_hid = ∅`
     (including positive reuse of previously discovered blockers in `U`).
  2. Formal independence certification: `restrictedEligible` never inspects
     `M.g x` on unrevealed hidden rows `x ∈ R_hid \ rows(U)`.

  100% constructive (0 sorryAx, 0 ofReduceBool, 0 Classical.choice).
-/

namespace RecursiveSwitching.TraceCapture

abbrev Row := Nat
abbrev Addr := Nat

structure Term where
  lowerOk : Bool
  posLits : List (Row × Addr)
  negLits : List (Row × Addr)

abbrev DNF := List Term

structure MarkerModel where
  g : Row → Addr
  K : Row → Bool

def TrueMarker (M : MarkerModel) (p : Row × Addr) : Prop :=
  M.K p.1 = true ∧ M.g p.1 = p.2

def AllTrue (M : MarkerModel) (U : List (Row × Addr)) : Prop :=
  ∀ p, p ∈ U → TrueMarker M p

def MemRow (x : Row) (U : List (Row × Addr)) : Prop :=
  ∃ y : Addr, (x, y) ∈ U

/-! ### 1. Constructive Boolean Helpers -/

def memRowBool (x : Row) : List (Row × Addr) → Bool
  | [] => false
  | (r, _) :: rest => if r = x then true else memRowBool x rest

theorem memRowBool_eq_true (x : Row) :
    ∀ U : List (Row × Addr), memRowBool x U = true ↔ MemRow x U
  | [] => by
      constructor
      · intro h; cases h
      · rintro ⟨y, hy⟩; cases hy
  | (r, y₀) :: rest => by
      dsimp only [memRowBool]
      split
      · rename_i h
        subst h
        constructor
        · intro _; exact ⟨y₀, List.Mem.head rest⟩
        · intro _; rfl
      · rename_i h
        constructor
        · intro hm
          rcases (memRowBool_eq_true x rest).mp hm with ⟨y, hy⟩
          exact ⟨y, List.Mem.tail (r, y₀) hy⟩
        · rintro ⟨y, hy⟩
          cases hy with
          | head => exact absurd rfl h
          | tail _ htail => exact (memRowBool_eq_true x rest).mpr ⟨y, htail⟩

def memPairBool (p : Row × Addr) : List (Row × Addr) → Bool
  | [] => false
  | q :: rest => if q = p then true else memPairBool p rest

def posLitsActive (M : MarkerModel) : List (Row × Addr) → Bool
  | [] => true
  | (x, y) :: rest =>
      if M.K x = true then
        if M.g x = y then posLitsActive M rest else false
      else false

def posActive (M : MarkerModel) (t : Term) : Bool :=
  if t.lowerOk = true then posLitsActive M t.posLits else false

def blockedByList (U : List (Row × Addr)) : List (Row × Addr) → Bool
  | [] => false
  | p :: rest => if memPairBool p U = true then true else blockedByList U rest

def eligible (M : MarkerModel) (U : List (Row × Addr)) (t : Term) : Bool :=
  if posActive M t = true then
    if blockedByList U t.negLits = false then true else false
  else false

def findFirstEligible (M : MarkerModel) (U : List (Row × Addr)) : DNF → Option Term
  | [] => none
  | t :: rest => if eligible M U t = true then some t else findFirstEligible M U rest

def findFirstBlocker (M : MarkerModel) : List (Row × Addr) → Option (Row × Addr)
  | [] => none
  | (x, y) :: rest =>
      if M.K x = true then
        if M.g x = y then some (x, y) else findFirstBlocker M rest
      else findFirstBlocker M rest

def newPosRows (U : List (Row × Addr)) : List (Row × Addr) → List Row
  | [] => []
  | (x, _) :: rest =>
      if memRowBool x U = true then newPosRows U rest
      else x :: newPosRows U rest

/-! ### 2. Original vs. Split-Restricted Canonical Process (Gate 195) -/

structure CanonicalState where
  U : List (Row × Addr)
  B : List Row
  P : List Row

inductive StepResult where
  | done (ans : Bool)
  | cont (st : CanonicalState)

inductive RestrictedResult where
  | done (ans : Bool)
  | abort
  | cont (st : CanonicalState)

def posAllowedList (isHid : Row → Bool) (U : List (Row × Addr)) : List (Row × Addr) → Bool
  | [] => true
  | (x, _) :: rest =>
      if isHid x = false then posAllowedList isHid U rest
      else if memRowBool x U = true then posAllowedList isHid U rest
      else false

def restrictedEligible (M : MarkerModel) (isHid : Row → Bool)
    (U : List (Row × Addr)) (t : Term) : Bool :=
  if posAllowedList isHid U t.posLits = true then eligible M U t else false

def findFirstRestricted (M : MarkerModel) (isHid : Row → Bool)
    (U : List (Row × Addr)) : DNF → Option Term
  | [] => none
  | t :: rest =>
      if restrictedEligible M isHid U t = true then some t
      else findFirstRestricted M isHid U rest

def step (M : MarkerModel) (F : DNF) (st : CanonicalState) : StepResult :=
  match findFirstEligible M st.U F with
  | none => .done false
  | some t =>
      let U₁ := t.posLits ++ st.U
      let P₁ := newPosRows st.U t.posLits ++ st.P
      match findFirstBlocker M t.negLits with
      | none => .done true
      | some blk =>
          .cont ⟨blk :: U₁, blk.1 :: st.B, P₁⟩

def restrictedStep (M : MarkerModel) (isHid : Row → Bool)
    (F : DNF) (st : CanonicalState) : RestrictedResult :=
  match findFirstRestricted M isHid st.U F with
  | none => .done false
  | some t =>
      let U₁ := t.posLits ++ st.U
      let P₁ := newPosRows st.U t.posLits ++ st.P
      match findFirstBlocker M t.negLits with
      | none => .done true
      | some blk =>
          if isHid blk.1 = true then
            .cont ⟨blk :: U₁, blk.1 :: st.B, P₁⟩
          else .abort

def run (M : MarkerModel) (F : DNF) : Nat → CanonicalState → StepResult
  | 0, st => .cont st
  | s + 1, st =>
      match step M F st with
      | .done ans => .done ans
      | .cont st' => run M F s st'

def runRestricted (M : MarkerModel) (isHid : Row → Bool) (F : DNF) :
    Nat → CanonicalState → RestrictedResult
  | 0, st => .cont st
  | s + 1, st =>
      match restrictedStep M isHid F st with
      | .done ans => .done ans
      | .abort => .abort
      | .cont st' => runRestricted M isHid F s st'

def Captured (isHid : Row → Bool) (B P : List Row) : Prop :=
  (∀ x, x ∈ B → isHid x = true) ∧ (∀ x, x ∈ P → isHid x = false)

/-! ### 3. Exact Trace Reproduction (Theorem XXI.2 Core) -/

theorem restrictedEligible_imp_eligible (M : MarkerModel) (isHid : Row → Bool)
    (U : List (Row × Addr)) (t : Term)
    (h : restrictedEligible M isHid U t = true) :
    eligible M U t = true := by
  dsimp only [restrictedEligible] at h
  split at h
  · exact h
  · cases h

theorem posAllowed_of_newPosRows_ext (isHid : Row → Bool) (U : List (Row × Addr)) :
    ∀ ps : List (Row × Addr),
      (∀ x, x ∈ newPosRows U ps → isHid x = false) →
      posAllowedList isHid U ps = true
  | [], _ => rfl
  | (x, _) :: rest, h => by
      dsimp only [posAllowedList]
      dsimp only [newPosRows] at h
      split at h
      · rename_i hInU
        have hRest := posAllowed_of_newPosRows_ext isHid U rest h
        split
        · exact hRest
        · split
          · exact hRest
          · rename_i hNotInU; exact absurd hInU hNotInU
      · have hxExt : isHid x = false := h x (List.Mem.head _)
        have hRest : posAllowedList isHid U rest = true :=
          posAllowed_of_newPosRows_ext isHid U rest (fun r hr => h r (List.Mem.tail x hr))
        split
        · exact hRest
        · rename_i hNotExt; exact absurd hxExt hNotExt

theorem findFirst_restricted_eq (M : MarkerModel) (isHid : Row → Bool)
    (U : List (Row × Addr)) :
    ∀ F : DNF, ∀ t : Term,
      findFirstEligible M U F = some t →
      posAllowedList isHid U t.posLits = true →
      findFirstRestricted M isHid U F = some t
  | [], _, h, _ => by cases h
  | t₀ :: rest, t, h, hAllow => by
      dsimp only [findFirstEligible] at h
      dsimp only [findFirstRestricted]
      split at h
      · rename_i hElig
        cases h
        have hRE : restrictedEligible M isHid U t = true := by
          dsimp only [restrictedEligible]
          rw [if_pos hAllow]
          exact hElig
        rw [if_pos hRE]
      · rename_i hNotElig
        have hNotRE : ¬ restrictedEligible M isHid U t₀ = true := by
          intro hRE
          exact hNotElig (restrictedEligible_imp_eligible M isHid U t₀ hRE)
        rw [if_neg hNotRE]
        exact findFirst_restricted_eq M isHid U rest t h hAllow

theorem trace_capture_step (M : MarkerModel) (isHid : Row → Bool) (F : DNF)
    (st st' : CanonicalState)
    (hStep : step M F st = .cont st')
    (hCap : Captured isHid st'.B st'.P) :
    restrictedStep M isHid F st = .cont st' := by
  dsimp only [step] at hStep
  cases hFind : findFirstEligible M st.U F with
  | none => rw [hFind] at hStep; cases hStep
  | some t =>
      rw [hFind] at hStep
      cases hBlk : findFirstBlocker M t.negLits with
      | none => rw [hBlk] at hStep; cases hStep
      | some blk =>
          rw [hBlk] at hStep
          cases hStep
          have hNewPosExt : ∀ x, x ∈ newPosRows st.U t.posLits → isHid x = false := by
            intro x hx
            exact hCap.2 x (List.mem_append.mpr (Or.inl hx))
          have hAllow : posAllowedList isHid st.U t.posLits = true :=
            posAllowed_of_newPosRows_ext isHid st.U t.posLits hNewPosExt
          have hFindR : findFirstRestricted M isHid st.U F = some t :=
            findFirst_restricted_eq M isHid st.U F t hFind hAllow
          have hBlkHid : isHid blk.1 = true := hCap.1 blk.1 (List.Mem.head st.B)
          dsimp only [restrictedStep]
          rw [hFindR, hBlk, if_pos hBlkHid]

theorem step_monotone_roles (M : MarkerModel) (F : DNF) (st st' : CanonicalState)
    (hStep : step M F st = .cont st') :
    (∀ x, x ∈ st.B → x ∈ st'.B) ∧ (∀ x, x ∈ st.P → x ∈ st'.P) := by
  dsimp only [step] at hStep
  cases hFind : findFirstEligible M st.U F with
  | none => rw [hFind] at hStep; cases hStep
  | some t =>
      rw [hFind] at hStep
      cases hBlk : findFirstBlocker M t.negLits with
      | none => rw [hBlk] at hStep; cases hStep
      | some blk =>
          rw [hBlk] at hStep
          cases hStep
          exact ⟨fun x hx => List.Mem.tail blk.1 hx,
                 fun x hx => List.mem_append.mpr (Or.inr hx)⟩

theorem run_monotone_roles (M : MarkerModel) (F : DNF) :
    ∀ (k : Nat) (st₀ st₁ : CanonicalState),
      run M F k st₀ = .cont st₁ →
      (∀ x, x ∈ st₀.B → x ∈ st₁.B) ∧ (∀ x, x ∈ st₀.P → x ∈ st₁.P)
  | 0, st₀, st₁, h => by
      dsimp only [run] at h; cases h
      exact ⟨fun _ hx => hx, fun _ hx => hx⟩
  | k + 1, st₀, st₁, h => by
      dsimp only [run] at h
      cases hSt : step M F st₀ with
      | done _ => rw [hSt] at h; cases h
      | cont stMid =>
          rw [hSt] at h
          rcases step_monotone_roles M F st₀ stMid hSt with ⟨hB1, hP1⟩
          rcases run_monotone_roles M F k stMid st₁ h with ⟨hB2, hP2⟩
          exact ⟨fun x hx => hB2 x (hB1 x hx), fun x hx => hP2 x (hP1 x hx)⟩

/-- Theorem XXI.2 (Deterministic Trace Capture):
    Whenever the split `isHid` captures the final roles `(st₁.B, st₁.P)` of an
    `s`-round blocking trace, the restricted algorithm reproduces the exact
    same `s` rounds and final state `st₁`. -/
theorem trace_capture_multi_step (M : MarkerModel) (isHid : Row → Bool) (F : DNF) :
    ∀ (s : Nat) (st₀ st₁ : CanonicalState),
      run M F s st₀ = .cont st₁ →
      Captured isHid st₁.B st₁.P →
      runRestricted M isHid F s st₀ = .cont st₁
  | 0, st₀, st₁, hRun, _ => by
      dsimp only [run] at hRun
      cases hRun
      rfl
  | s + 1, st₀, st₁, hRun, hCap => by
      dsimp only [run] at hRun
      cases hSt : step M F st₀ with
      | done _ => rw [hSt] at hRun; cases hRun
      | cont stMid =>
          rw [hSt] at hRun
          rcases run_monotone_roles M F s stMid st₁ hRun with ⟨hBMon, hPMon⟩
          have hCapMid : Captured isHid stMid.B stMid.P :=
            ⟨fun x hx => hCap.1 x (hBMon x hx), fun x hx => hCap.2 x (hPMon x hx)⟩
          have hStepR : restrictedStep M isHid F st₀ = .cont stMid :=
            trace_capture_step M isHid F st₀ stMid hSt hCapMid
          dsimp only [runRestricted]
          rw [hStepR]
          exact trace_capture_multi_step M isHid F s stMid st₁ hRun hCap

/-! ### 4. Hidden-Marker Independence Certification (for Gate 201 Event A) -/

theorem posLitsActive_agree_on_allowed (M₁ M₂ : MarkerModel) (isHid : Row → Bool)
    (U : List (Row × Addr))
    (hK : ∀ x, M₁.K x = M₂.K x)
    (hg : ∀ x, (isHid x = false ∨ MemRow x U) → M₁.g x = M₂.g x) :
    ∀ ps : List (Row × Addr),
      posAllowedList isHid U ps = true →
      posLitsActive M₁ ps = posLitsActive M₂ ps
  | [], _ => rfl
  | (x, y) :: rest, hAllow => by
      dsimp only [posAllowedList] at hAllow
      have hPerm : isHid x = false ∨ MemRow x U := by
        split at hAllow
        · rename_i hExt; exact Or.inl hExt
        · split at hAllow
          · rename_i hInU; exact Or.inr ((memRowBool_eq_true x U).mp hInU)
          · cases hAllow
      have hAllowRest : posAllowedList isHid U rest = true := by
        split at hAllow
        · exact hAllow
        · split at hAllow
          · exact hAllow
          · cases hAllow
      dsimp only [posLitsActive]
      rw [hK x, hg x hPerm]
      split
      · split
        · exact posLitsActive_agree_on_allowed M₁ M₂ isHid U hK hg rest hAllowRest
        · rfl
      · rfl

/-- Formal independence of `restrictedEligible` from unrevealed hidden markers:
    changing `M.g x` on any hidden row `x ∉ rows(U)` does not affect `restrictedEligible`. -/
theorem restrictedEligible_independent_of_hidden (M₁ M₂ : MarkerModel)
    (isHid : Row → Bool) (U : List (Row × Addr)) (t : Term)
    (hK : ∀ x, M₁.K x = M₂.K x)
    (hg : ∀ x, (isHid x = false ∨ MemRow x U) → M₁.g x = M₂.g x) :
    restrictedEligible M₁ isHid U t = restrictedEligible M₂ isHid U t := by
  dsimp only [restrictedEligible]
  split
  · rename_i hAllow
    dsimp only [eligible, posActive]
    rw [posLitsActive_agree_on_allowed M₁ M₂ isHid U hK hg t.posLits hAllow]
  · rfl

end RecursiveSwitching.TraceCapture
