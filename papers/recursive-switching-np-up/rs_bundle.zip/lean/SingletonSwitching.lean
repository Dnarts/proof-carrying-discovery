/-
  SingletonSwitching.lean — v0.1 (0 external imports, Lean 4.36.0 target)
  Formalizes Gate 118–119 (Theorem XIII.1 — Singleton-Preserving Switching Lemma):
  1. Auxiliary row-state space `{E, U j, S j}` where `E` exists only in the
     auxiliary measure `Q`, never in the original projection `P`.
  2. Exact `q * L^2`-scaled normalization of `P` and `Q`, plus the exact
     per-row and multi-row weight-ratio inequality
     `P(ρ) / Q(η) ≤ ((1 - p) / (1 - p - 1/L))^u * (2p)^t` under `p + 1/L ≤ 1/2`.
  3. Exact row-level encode/decode invertibility, specialization preservation
     of falsified terms, and unique recovery of the first satisfied term.

  100% constructive (0 sorryAx, 0 ofReduceBool, 0 Classical.choice, 0 warnings).
-/

namespace RecursiveSwitching.SingletonSwitching

/-! ### 1. Row States, Original Measure `P`, and Auxiliary Measure `Q` -/

inductive RowState where
  | E : RowState
  | U (j : Nat) : RowState
  | S (j : Nat) : RowState
  deriving DecidableEq

/-- States allowed in the actual projection `ρ` (empty rows `E` are forbidden,
    preserving the all-nonempty base world `b = 0^R`). -/
def ValidOrigState : RowState → Prop
  | .E => False
  | .U _ => True
  | .S _ => True

/-- `q * L^2`-scaled single-row weight under original measure `P` (`p = a / q`). -/
def weightP (a q L : Nat) : RowState → Nat
  | .E => 0
  | .U _ => (q - a) * L
  | .S _ => a * L

/-- `q * L^2`-scaled single-row weight under auxiliary measure `Q` (`p = a / q`). -/
def weightQ (a q L : Nat) : RowState → Nat
  | .E => q * L
  | .U _ => (q - a) * L - q
  | .S _ => a * L

/-- Exact normalization of `P` over `1` empty + `L` fixed + `L` free states:
    `0 + L * ((q - a) * L) + L * (a * L) = q * L^2`. -/
theorem weightP_norm (a q L : Nat) (haq : a ≤ q) :
    weightP a q L .E + L * weightP a q L (.U 0) + L * weightP a q L (.S 0) = q * (L * L) := by
  dsimp only [weightP]
  rw [Nat.zero_add, ← Nat.mul_add, ← Nat.add_mul]
  have hqa : q - a + a = q := Nat.sub_add_cancel haq
  rw [hqa, Nat.mul_comm L (q * L), Nat.mul_assoc]

/-- Exact normalization of `Q` over `1` empty + `L` fixed + `L` free states:
    `q * L + L * ((q - a) * L - q) + L * (a * L) = q * L^2`. -/
theorem weightQ_norm (a q L : Nat) (haq : a ≤ q) (hbound : q ≤ (q - a) * L) :
    weightQ a q L .E + L * weightQ a q L (.U 0) + L * weightQ a q L (.S 0) = q * (L * L) := by
  dsimp only [weightQ]
  have hsub : L * ((q - a) * L - q) + L * q = L * ((q - a) * L) := by
    rw [← Nat.mul_add, Nat.sub_add_cancel hbound]
  have h1 : q * L + L * ((q - a) * L - q) = L * ((q - a) * L) := by
    rw [Nat.mul_comm q L, Nat.add_comm, hsub]
  rw [h1, ← Nat.mul_add, ← Nat.add_mul]
  have hqa : q - a + a = q := Nat.sub_add_cancel haq
  rw [hqa, Nat.mul_comm L (q * L), Nat.mul_assoc]

/-! ### 2. Gate 119 Step 4: Exact Weight-Ratio Inequalities -/

/-- Positive replacement `S j ↦ U j`: `P(S j) / Q(U j) ≤ 2p = 2a / q`
    under `p + 1/L ≤ 1/2`, i.e. `2 * (a * L + q) ≤ q * L`. -/
theorem weight_ratio_pos_replace (a q L j : Nat)
    (haq : a ≤ q)
    (hhalf : 2 * (a * L + q) ≤ q * L) :
    weightP a q L (.S j) * q ≤ 2 * a * weightQ a q L (.U j) := by
  dsimp only [weightP, weightQ]
  have hsub : q * L ≤ 2 * ((q - a) * L - q) := by
    have hmul : (q - a) * L + a * L = q * L := by
      rw [← Nat.add_mul, Nat.sub_add_cancel haq]
    omega
  have h1 : a * L * q = a * (q * L) := by
    rw [Nat.mul_assoc, Nat.mul_comm L q]
  have h2 : 2 * a * ((q - a) * L - q) = a * (2 * ((q - a) * L - q)) := by
    rw [Nat.mul_assoc, Nat.mul_left_comm 2 a]
  calc a * L * q
      = a * (q * L) := h1
    _ ≤ a * (2 * ((q - a) * L - q)) := Nat.mul_le_mul_left a hsub
    _ = 2 * a * ((q - a) * L - q) := h2.symm

/-- Negative replacement `S j ↦ E`: `P(S j) / Q(E) = p ≤ 2p = 2a / q`. -/
theorem weight_ratio_neg_replace (a q L j : Nat) :
    weightP a q L (.S j) * q ≤ 2 * a * weightQ a q L .E := by
  dsimp only [weightP, weightQ]
  have h1 : a * L * q = a * (q * L) := by
    rw [Nat.mul_assoc, Nat.mul_comm L q]
  have h2 : 2 * a * (q * L) = a * (q * L) + a * (q * L) := by
    rw [Nat.mul_assoc 2 a, Nat.two_mul]
  rw [h1, h2]
  exact Nat.le_add_right _ _

/-- Unchanged free row `S j ↦ S j`: exact equality `P(S j) = Q(S j)`. -/
theorem weight_ratio_keep_S (a q L j : Nat) :
    weightP a q L (.S j) = weightQ a q L (.S j) := rfl

/-- Unchanged fixed row `U j ↦ U j`: exact cross-multiplied ratio
    `P(U j) * ((q - a) * L - q) = Q(U j) * ((q - a) * L)`. -/
theorem weight_ratio_keep_U (a q L j : Nat) :
    weightP a q L (.U j) * ((q - a) * L - q) =
    weightQ a q L (.U j) * ((q - a) * L) := by
  dsimp only [weightP, weightQ]
  exact Nat.mul_comm _ _

/-- Valid row-level encoding transition in Gate 119 Step 2. -/
inductive RowStep : RowState → RowState → Nat → Nat → Prop where
  | keepS (j : Nat) : RowStep (.S j) (.S j) 0 0
  | keepU (j : Nat) : RowStep (.U j) (.U j) 0 1
  | posReplace (j : Nat) : RowStep (.S j) (.U j) 1 0
  | negReplace (j : Nat) : RowStep (.S j) .E 1 0

/-- Multi-row product weight under `P` and `Q`. -/
def prodWeightP (a q L : Nat) : List RowState → Nat
  | [] => 1
  | r :: rs => weightP a q L r * prodWeightP a q L rs

def prodWeightQ (a q L : Nat) : List RowState → Nat
  | [] => 1
  | r :: rs => weightQ a q L r * prodWeightQ a q L rs

inductive RestrStep : List RowState → List RowState → Nat → Nat → Prop where
  | nil : RestrStep [] [] 0 0
  | cons {r e : RowState} {rs es : List RowState} {t₁ u₁ t₂ u₂ : Nat} :
      RowStep r e t₁ u₁ →
      RestrStep rs es t₂ u₂ →
      RestrStep (r :: rs) (e :: es) (t₁ + t₂) (u₁ + u₂)

/-- Gate 119 Step 4 (Multi-row Weight-Ratio Theorem):
    For any valid encoding `ρ ↦ η` replacing `t` free rows and keeping `u` fixed rows,
    `P(ρ) * q^t * ((q - a) * L - q)^u ≤ (2a)^t * ((q - a) * L)^u * Q(η)`. -/
theorem multi_row_weight_bound (a q L : Nat)
    (haq : a ≤ q)
    (hhalf : 2 * (a * L + q) ≤ q * L) :
    ∀ {ρ η : List RowState} {t u : Nat},
      RestrStep ρ η t u →
      prodWeightP a q L ρ * q ^ t * ((q - a) * L - q) ^ u ≤
        (2 * a) ^ t * ((q - a) * L) ^ u * prodWeightQ a q L η := by
  intro ρ η t u h
  induction h with
  | nil =>
      simp only [prodWeightP, prodWeightQ, Nat.pow_zero, Nat.mul_one]
      exact Nat.le_refl 1
  | @cons r e rs es t₁ u₁ t₂ u₂ hrow hrest ih =>
      cases hrow with
      | keepS j =>
          simp only [Nat.zero_add, prodWeightP, prodWeightQ]
          rw [weight_ratio_keep_S a q L j]
          calc weightQ a q L (.S j) * prodWeightP a q L rs * q ^ t₂ * ((q - a) * L - q) ^ u₂
              = weightQ a q L (.S j) *
                (prodWeightP a q L rs * q ^ t₂ * ((q - a) * L - q) ^ u₂) := by
                  simp only [Nat.mul_assoc]
            _ ≤ weightQ a q L (.S j) *
                ((2 * a) ^ t₂ * ((q - a) * L) ^ u₂ * prodWeightQ a q L es) :=
                  Nat.mul_le_mul_left _ ih
            _ = (2 * a) ^ t₂ * ((q - a) * L) ^ u₂ *
                (weightQ a q L (.S j) * prodWeightQ a q L es) := by
                  simp only [Nat.mul_comm, Nat.mul_assoc]
      | keepU j =>
          -- t₁ = 0, u₁ = 1
          simp only [Nat.zero_add, prodWeightP, prodWeightQ]
          have hb := weight_ratio_keep_U a q L j
          have hmul := Nat.mul_le_mul (Nat.le_of_eq hb) ih
          have hL : weightP a q L (.U j) * ((q - a) * L - q) *
                (prodWeightP a q L rs * q ^ t₂ * ((q - a) * L - q) ^ u₂)
              = weightP a q L (.U j) * prodWeightP a q L rs * q ^ t₂ *
                ((q - a) * L - q) ^ (u₂ + 1) := by
            rw [Nat.pow_succ]
            simp only [Nat.mul_assoc, Nat.mul_left_comm, Nat.mul_comm]
          have hR : weightQ a q L (.U j) * ((q - a) * L) *
                ((2 * a) ^ t₂ * ((q - a) * L) ^ u₂ * prodWeightQ a q L es)
              = (2 * a) ^ t₂ * ((q - a) * L) ^ (u₂ + 1) *
                (weightQ a q L (.U j) * prodWeightQ a q L es) := by
            rw [Nat.pow_succ]
            simp only [Nat.mul_assoc, Nat.mul_left_comm, Nat.mul_comm]
          rw [hL, hR] at hmul
          simpa only [Nat.add_comm] using hmul
      | posReplace j =>
          -- t₁ = 1, u₁ = 0
          simp only [Nat.zero_add, prodWeightP, prodWeightQ]
          have hb := weight_ratio_pos_replace a q L j haq hhalf
          have hmul := Nat.mul_le_mul hb ih
          have hL : weightP a q L (.S j) * q *
                (prodWeightP a q L rs * q ^ t₂ * ((q - a) * L - q) ^ u₂)
              = weightP a q L (.S j) * prodWeightP a q L rs * q ^ (t₂ + 1) *
                ((q - a) * L - q) ^ u₂ := by
            rw [Nat.pow_succ]
            simp only [Nat.mul_assoc, Nat.mul_left_comm, Nat.mul_comm]
          have hR : 2 * a * weightQ a q L (.U j) *
                ((2 * a) ^ t₂ * ((q - a) * L) ^ u₂ * prodWeightQ a q L es)
              = (2 * a) ^ (t₂ + 1) * ((q - a) * L) ^ u₂ *
                (weightQ a q L (.U j) * prodWeightQ a q L es) := by
            rw [Nat.pow_succ]
            simp only [Nat.mul_assoc, Nat.mul_left_comm, Nat.mul_comm]
          rw [hL, hR] at hmul
          simpa only [Nat.add_comm] using hmul
      | negReplace j =>
          simp only [Nat.zero_add, prodWeightP, prodWeightQ]
          have hb := weight_ratio_neg_replace a q L j
          have hmul := Nat.mul_le_mul hb ih
          have hL : weightP a q L (.S j) * q *
                (prodWeightP a q L rs * q ^ t₂ * ((q - a) * L - q) ^ u₂)
              = weightP a q L (.S j) * prodWeightP a q L rs * q ^ (1 + t₂) *
                ((q - a) * L - q) ^ u₂ := by
            rw [Nat.add_comm 1 t₂, Nat.pow_succ]
            simp only [Nat.mul_assoc, Nat.mul_left_comm, Nat.mul_comm]
          have hR : 2 * a * weightQ a q L .E *
                ((2 * a) ^ t₂ * ((q - a) * L) ^ u₂ * prodWeightQ a q L es)
              = (2 * a) ^ (1 + t₂) * ((q - a) * L) ^ u₂ *
                (weightQ a q L .E * prodWeightQ a q L es) := by
            rw [Nat.add_comm 1 t₂, Nat.pow_succ]
            simp only [Nat.mul_assoc, Nat.mul_left_comm, Nat.mul_comm]
          rw [hL, hR] at hmul
          exact hmul

/-! ### 3. Gate 119 Steps 2–3: Encode/Decode Invertibility & First-Satisfied-Term Recovery -/

def encodeRow (st : RowState) (isPos : Bool) : RowState × Option Nat :=
  match st, isPos with
  | .S j, true => (.U j, none)
  | .S j, false => (.E, some j)
  | s, _ => (s, none)

def decodeRow (st : RowState) (aux : Option Nat) : RowState :=
  match st, aux with
  | .U j, none => .S j
  | .E, some j => .S j
  | s, _ => s

/-- Exact row-level invertibility of Razborov encoding on every free row `S j`. -/
theorem decode_encode_row (j : Nat) (isPos : Bool) :
    let res := encodeRow (.S j) isPos
    decodeRow res.1 res.2 = .S j := by
  cases isPos <;> rfl

/-- Specialization order `η ⊑ ρ`: `η` is a valid specialization of `ρ`
    if every row of `η` is either equal to `ρ` or replaces `S j` by `U j` or `E`. -/
def RowSpec (r e : RowState) : Prop :=
  e = r ∨ (∃ j, r = .S j ∧ (e = .U j ∨ e = .E))

def RestrSpec (ρ η : Nat → RowState) : Prop :=
  ∀ u, RowSpec (ρ u) (η u)

/-- A concrete row assignment `w : Nat → Option Nat` (`none` = empty, `some j` = marker at `j`)
    is compatible with a partial restriction `ρ`. -/
def RowCompat (r : RowState) (w : Option Nat) : Prop :=
  match r with
  | .E => w = none
  | .U j => w = some j
  | .S j => w = some j ∨ w = none

def RestrCompat (ρ : Nat → RowState) (w : Nat → Option Nat) : Prop :=
  ∀ u, RowCompat (ρ u) (w u)

theorem spec_preserves_compat {ρ η : Nat → RowState} {w : Nat → Option Nat}
    (hSpec : RestrSpec ρ η) (hCompat : RestrCompat η w) :
    RestrCompat ρ w := by
  intro u
  have hc := hCompat u
  rcases hSpec u with heq | ⟨j, hr, hU | hE⟩
  · rw [← heq]; exact hc
  · rw [hr]
    rw [hU] at hc
    exact Or.inl hc
  · rw [hr]
    rw [hE] at hc
    exact Or.inr hc

/-- Abstract term evaluation on a concrete world `w`. -/
def TermFalseUnder (evalT : (Nat → Option Nat) → Bool) (ρ : Nat → RowState) : Prop :=
  ∀ w, RestrCompat ρ w → evalT w = false

def TermTrueUnder (evalT : (Nat → Option Nat) → Bool) (ρ : Nat → RowState) : Prop :=
  ∀ w, RestrCompat ρ w → evalT w = true

/-- Any term identically false under `ρ` stays identically false under any
    specialization `η` (Gate 119 Step 3 core monotonicity). -/
theorem false_preserved_under_spec (evalT : (Nat → Option Nat) → Bool)
    {ρ η : Nat → RowState}
    (hSpec : RestrSpec ρ η)
    (hFalse : TermFalseUnder evalT ρ) :
    TermFalseUnder evalT η := by
  intro w hw
  exact hFalse w (spec_preserves_compat hSpec hw)

/-- Unique recovery of the first satisfied term in a DNF (Gate 119 Step 3):
    If `η` is a specialization of `ρ` that has at least one compatible world `w₀`,
    every term before index `k` is identically false under `ρ`, and term `k` is
    identically true under `η`, then `k` is the unique first index whose term
    is satisfied under `η`. -/
theorem first_satisfied_term_unique
    (terms : List ((Nat → Option Nat) → Bool))
    {ρ η : Nat → RowState}
    (hSpec : RestrSpec ρ η)
    (w₀ : Nat → Option Nat) (hw₀ : RestrCompat η w₀)
    (k : Nat) (hk : k < terms.length)
    (hBefore : ∀ i (hi : i < k),
      TermFalseUnder (terms.get ⟨i, Nat.lt_trans hi hk⟩) ρ)
    (hAt : TermTrueUnder (terms.get ⟨k, hk⟩) η) :
    (∀ i (hi : i < k), ¬ TermTrueUnder (terms.get ⟨i, Nat.lt_trans hi hk⟩) η) ∧
    TermTrueUnder (terms.get ⟨k, hk⟩) η := by
  refine ⟨?_, hAt⟩
  intro i hi hTrue
  have hFalseEta : TermFalseUnder (terms.get ⟨i, Nat.lt_trans hi hk⟩) η :=
    false_preserved_under_spec _ hSpec (hBefore i hi)
  have hf : terms.get ⟨i, Nat.lt_trans hi hk⟩ w₀ = false := hFalseEta w₀ hw₀
  have ht : terms.get ⟨i, Nat.lt_trans hi hk⟩ w₀ = true := hTrue w₀ hw₀
  rw [hf] at ht
  cases ht

end RecursiveSwitching.SingletonSwitching
