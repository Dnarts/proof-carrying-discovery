/-
  RecursiveSwitching.lean — v0.1 (0 external imports, Lean 4.36.0 target)
  Formalizes Gates 199–202 (Cycle XXI):
  1. Monotone prefix binary search correctness and query bound (`binSearch_finds_first`).
  2. Exact per-round and multi-round depth recurrence (`round_depth_bound`, `depthRec_le_pow`).
  3. Exact `Nat`-scaled Event A + Event B probability union bound (`event_A_B_union_bound`)
     and width growth across logarithmic tower depth (`widthAtLayer_eq`).

  100% constructive (0 sorryAx, 0 ofReduceBool, 0 Classical.choice, 0 warnings).
-/

namespace RecursiveSwitching.RecursiveSwitching

/-! ### 1. Gate 199: Monotone Prefix Binary Search -/

def MonotonePrefix (P : Nat → Bool) (M : Nat) : Prop :=
  ∀ i j, i ≤ j → j ≤ M → P i = true → P j = true

/-- Fuel-bounded binary search on `(lo, hi]` assuming `P lo = false` and `P hi = true`.
    Uses at most `fuel` queries to `P`. -/
def binSearch (P : Nat → Bool) : Nat → Nat → Nat → Nat
  | 0, _, hi => hi
  | fuel + 1, lo, hi =>
      if hi ≤ lo + 1 then hi
      else
        let mid := (lo + hi) / 2
        match P mid with
        | true => binSearch P fuel lo mid
        | false => binSearch P fuel mid hi

/-- Correctness of `binSearch`: if `P lo = false`, `P hi = true`, `lo < hi ≤ M`,
    and `hi - lo ≤ 2^fuel`, then `k = binSearch P fuel lo hi` is the exact first
    index in `(lo, hi]` with `P k = true` (i.e. `P (k - 1) = false` and `P k = true`). -/
theorem binSearch_finds_first (P : Nat → Bool) (M : Nat) :
    ∀ (fuel lo hi : Nat),
      lo < hi →
      hi ≤ M →
      hi - lo ≤ 2 ^ fuel →
      P lo = false →
      P hi = true →
      let k := binSearch P fuel lo hi
      lo < k ∧ k ≤ hi ∧ P k = true ∧ P (k - 1) = false
  | 0, lo, hi, hlt, _, hspan, hlo, hhi => by
      dsimp only [binSearch]
      have heq : hi - 1 = lo := by
        simp only [Nat.pow_zero] at hspan
        omega
      refine ⟨hlt, Nat.le_refl hi, hhi, ?_⟩
      rw [heq]
      exact hlo
  | fuel + 1, lo, hi, hlt, hM, hspan, hlo, hhi => by
      dsimp only [binSearch]
      split
      · rename_i hle
        have heq : hi - 1 = lo := by omega
        refine ⟨hlt, Nat.le_refl hi, hhi, ?_⟩
        rw [heq]
        exact hlo
      · rename_i hgt
        have hlo_mid : lo < (lo + hi) / 2 := by omega
        have hmid_hi : (lo + hi) / 2 < hi := by omega
        have hspan_lo : (lo + hi) / 2 - lo ≤ 2 ^ fuel := by
          have hpow : 2 ^ (fuel + 1) = 2 ^ fuel * 2 := Nat.pow_succ 2 fuel
          omega
        have hspan_hi : hi - (lo + hi) / 2 ≤ 2 ^ fuel := by
          have hpow : 2 ^ (fuel + 1) = 2 ^ fuel * 2 := Nat.pow_succ 2 fuel
          omega
        cases hPmid : P ((lo + hi) / 2) with
        | true =>
            dsimp only
            have ih := binSearch_finds_first P M fuel lo ((lo + hi) / 2)
              hlo_mid (by omega) hspan_lo hlo hPmid
            rcases ih with ⟨h1, h2, h3, h4⟩
            exact ⟨h1, by omega, h3, h4⟩
        | false =>
            dsimp only
            have ih := binSearch_finds_first P M fuel ((lo + hi) / 2) hi
              hmid_hi hM hspan_hi hPmid hhi
            rcases ih with ⟨h1, h2, h3, h4⟩
            exact ⟨by omega, h2, h3, h4⟩

/-- Minimality under monotonicity: no index `j < k` with `lo ≤ j` can have `P j = true`. -/
theorem binSearch_minimal (P : Nat → Bool) (M fuel lo hi : Nat)
    (hMono : MonotonePrefix P M)
    (hlt : lo < hi) (hM : hi ≤ M) (hspan : hi - lo ≤ 2 ^ fuel)
    (hlo : P lo = false) (hhi : P hi = true) :
    ∀ j, j < binSearch P fuel lo hi → P j = false := by
  have hres := binSearch_finds_first P M fuel lo hi hlt hM hspan hlo hhi
  rcases hres with ⟨h1, h2, _, hprev⟩
  intro j hj
  cases hPj : P j with
  | false => rfl
  | true =>
      have hle : j ≤ binSearch P fuel lo hi - 1 := by omega
      have hM' : binSearch P fuel lo hi - 1 ≤ M := by omega
      have ht : P (binSearch P fuel lo hi - 1) = true := hMono j _ hle hM' hPj
      rw [hprev] at ht
      cases ht

/-! ### 2. Gate 201: Event A + Event B Failure-Budget Closure (Exact `Nat` Arithmetic) -/

/-- Exact `Nat`-scaled Trace Capture division step for Event A:
    if `q_num * badA ≤ q_den * (δ' + errA)` and each of `q_den * δ'` and `q_den * errA`
    is at most `q_num * δ / 4`, then `2 * badA ≤ δ`. -/
theorem event_A_bound (q_num q_den badA δ' errA δ : Nat)
    (hq_pos : 0 < q_num)
    (hCap : q_num * badA ≤ q_den * (δ' + errA))
    (hδ' : 4 * (q_den * δ') ≤ q_num * δ)
    (herr : 4 * (q_den * errA) ≤ q_num * δ) :
    2 * badA ≤ δ := by
  have h1 : 4 * (q_num * badA) ≤ 4 * (q_den * (δ' + errA)) :=
    Nat.mul_le_mul_left 4 hCap
  have h2 : 4 * (q_den * (δ' + errA)) = 4 * (q_den * δ') + 4 * (q_den * errA) := by
    rw [Nat.mul_add q_den δ' errA, Nat.mul_add 4]
  have h3 : 4 * (q_num * badA) ≤ q_num * δ + q_num * δ := by
    rw [h2] at h1
    exact Nat.le_trans h1 (Nat.add_le_add hδ' herr)
  have h4 : q_num * (4 * badA) ≤ q_num * (2 * δ) := by
    have hL : 4 * (q_num * badA) = q_num * (4 * badA) := by
      rw [Nat.mul_left_comm]
    have hR : q_num * δ + q_num * δ = q_num * (2 * δ) := by
      rw [← Nat.mul_add, ← Nat.two_mul]
    rw [← hL, ← hR]
    exact h3
  have h5 : 4 * badA ≤ 2 * δ := Nat.le_of_mul_le_mul_left h4 hq_pos
  omega

/-- Exact `Nat`-scaled union bound of Event A (`≤ δ / 2`) and Event B (`≤ δ / 4`):
    total failure probability satisfies `4 * (badA + badB) ≤ 3 * δ`, hence `< δ` for `δ > 0`. -/
theorem event_A_B_union_bound (badA badB δ : Nat)
    (hA : 2 * badA ≤ δ)
    (hB : 4 * badB ≤ δ) :
    4 * (badA + badB) ≤ 3 * δ := by
  omega

theorem event_A_B_strict (badA badB δ : Nat)
    (hδ : 0 < δ)
    (hA : 2 * badA ≤ δ)
    (hB : 4 * badB ≤ δ) :
    badA + badB < δ := by
  omega

/-! ### 3. Gate 202: Quantitative Width and Depth Recurrences -/

def widthAtLayer (w_top T : Nat) : Nat → Nat
  | 0 => w_top
  | k + 1 => T * widthAtLayer w_top T k

theorem widthAtLayer_eq (w_top T : Nat) :
    ∀ k : Nat, widthAtLayer w_top T k = w_top * T ^ k
  | 0 => by simp only [widthAtLayer, Nat.pow_zero, Nat.mul_one]
  | k + 1 => by
      dsimp only [widthAtLayer]
      rw [widthAtLayer_eq w_top T k, Nat.pow_succ, Nat.mul_left_comm, Nat.mul_comm T (T ^ k)]

/-- Exact per-round and `s`-round total depth bound (Gate 201 closure):
    at most `s - 1` blocking rounds + 1 final round = `s` rounds,
    each costing `≤ (v + w) * d'`. -/
theorem multi_round_depth_bound (s v w d' total : Nat)
    (h : total ≤ s * ((v + w) * d')) :
    total ≤ s * (v + w) * d' := by
  rw [Nat.mul_assoc]
  exact h

/-- Recursive depth schedule `d_{j+1} = s_j * (v_j + w_j) * d_j`. -/
def depthRec (s v w : Nat → Nat) (d₀ : Nat) : Nat → Nat
  | 0 => d₀
  | j + 1 => s j * (v j + w j) * depthRec s v w d₀ j

/-- Quantitative upper bound for Gate 202:
    if every layer factor `s_j * (v_j + w_j) ≤ B`, then `d_h ≤ d₀ * B^h`. -/
theorem depthRec_le_pow (s v w : Nat → Nat) (d₀ B : Nat) :
    ∀ h : Nat,
      (∀ j, j < h → s j * (v j + w j) ≤ B) →
      depthRec s v w d₀ h ≤ d₀ * B ^ h
  | 0, _ => by
      simp only [depthRec, Nat.pow_zero, Nat.mul_one]
      exact Nat.le_refl d₀
  | h + 1, hB => by
      dsimp only [depthRec]
      have hPrev : ∀ j, j < h → s j * (v j + w j) ≤ B :=
        fun j hj => hB j (Nat.lt_succ_of_lt hj)
      have ih := depthRec_le_pow s v w d₀ B h hPrev
      have hCur : s h * (v h + w h) ≤ B := hB h (Nat.lt_succ_self h)
      have hmul : s h * (v h + w h) * depthRec s v w d₀ h ≤ B * (d₀ * B ^ h) :=
        Nat.mul_le_mul hCur ih
      have heq : B * (d₀ * B ^ h) = d₀ * B ^ (h + 1) := by
        rw [Nat.pow_succ, Nat.mul_left_comm, Nat.mul_comm B (B ^ h)]
      rw [heq] at hmul
      exact hmul

/-- Acyclic range separation (Gate 203):
    for any coded even length `2 * r ∈ [2^j * n, 2^(j+1) * n)`,
    every strictly smaller query `|q| < r` lies strictly below `2^j * n`,
    preventing any intra-range dependency inside `I_j`. -/
theorem range_strictly_acyclic (n j r qlen : Nat)
    (hUpper : 2 * r < 2 ^ (j + 1) * n)
    (hAcyc : qlen < r) :
    qlen < 2 ^ j * n := by
  have hpow : 2 ^ (j + 1) * n = 2 * (2 ^ j * n) := by
    rw [Nat.pow_succ, Nat.mul_comm (2 ^ j) 2, Nat.mul_assoc]
  omega

end RecursiveSwitching.RecursiveSwitching
