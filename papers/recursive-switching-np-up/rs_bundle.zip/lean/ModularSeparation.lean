/-
  ModularSeparation.lean — v0.1 (0 external imports, Lean 4.36.0 target)
  Formalizes Gates 113–114 & Gates 205–208 (Theorem XXI.4 & Corollary XXI.5):
  1. Exact alternating dual functional `Λ_R(f) = ∑_{b ∈ {0,1}^R} (-1)^|b| f(b)`
     over `Int` (simultaneously certifying every modulus `p ≥ 2`).
  2. Annihilation of every function independent of some coordinate `i < R`,
     hence of every monomial and polynomial of degree `< R`.
  3. Exact non-vanishing on the target predicate `OR_R`: `Λ_R(OR_R) = -1` for all `R ≥ 1`.
  4. Universal Mod-p degree lower bound (`no_low_deg_mod_p_OR`) and
     diagonalization witness existence (`modular_diagonalization_witness`) for every `p ≥ 2`.

  100% constructive (0 sorryAx, 0 ofReduceBool, 0 Classical.choice, 0 warnings).
-/

namespace RecursiveSwitching.ModularSeparation

/-! ### 1. Cube Coordinates and Alternating Dual Functional `Λ_R` -/

def update (b : Nat → Bool) (i : Nat) (v : Bool) : Nat → Bool :=
  fun j => if j = i then v else b j

theorem update_same (b : Nat → Bool) (i : Nat) (v : Bool) :
    update b i v i = v := by
  dsimp only [update]
  simp only [ite_true]

theorem update_other (b : Nat → Bool) (i j : Nat) (v : Bool) (hne : j ≠ i) :
    update b i v j = b j := by
  dsimp only [update]
  split
  · rename_i heq; exact absurd heq hne
  · rfl

theorem update_comm (b : Nat → Bool) (i k : Nat) (vi vk : Bool) (hne : i ≠ k) :
    update (update b i vi) k vk = update (update b k vk) i vi := by
  funext j
  dsimp only [update]
  split
  · rename_i hjk
    split
    · rename_i hji; exact absurd (hji.symm.trans hjk) hne
    · rfl
  · split
    · rfl
    · rfl

/-- Exact alternating sum `Λ_R(f) = ∑_{b ∈ {0,1}^R} (-1)^{|b|} f(b)` over `Int`. -/
def sumCube : Nat → ((Nat → Bool) → Int) → Int
  | 0, f => f (fun _ => false)
  | R + 1, f =>
      sumCube R (fun b => f (update b R false)) -
      sumCube R (fun b => f (update b R true))

theorem sumCube_congr :
    ∀ (R : Nat) (f g : (Nat → Bool) → Int),
      (∀ b, f b = g b) →
      sumCube R f = sumCube R g
  | 0, f, g, h => h _
  | R + 1, f, g, h => by
      dsimp only [sumCube]
      rw [sumCube_congr R _ _ (fun b => h (update b R false)),
          sumCube_congr R _ _ (fun b => h (update b R true))]

theorem sumCube_add :
    ∀ (R : Nat) (f g : (Nat → Bool) → Int),
      sumCube R (fun b => f b + g b) = sumCube R f + sumCube R g
  | 0, _, _ => rfl
  | R + 1, f, g => by
      dsimp only [sumCube]
      rw [sumCube_add R (fun b => f (update b R false)) (fun b => g (update b R false)),
          sumCube_add R (fun b => f (update b R true)) (fun b => g (update b R true))]
      omega

theorem sumCube_mul_const :
    ∀ (R : Nat) (c : Int) (f : (Nat → Bool) → Int),
      sumCube R (fun b => c * f b) = c * sumCube R f
  | 0, _, _ => rfl
  | R + 1, c, f => by
      dsimp only [sumCube]
      rw [sumCube_mul_const R c (fun b => f (update b R false)),
          sumCube_mul_const R c (fun b => f (update b R true)),
          Int.mul_sub]

theorem sumCube_zero : ∀ R : Nat, sumCube R (fun _ => 0) = 0
  | 0 => rfl
  | R + 1 => by
      dsimp only [sumCube]
      rw [sumCube_zero R]
      omega

/-! ### 2. Annihilation of Functions Independent of a Coordinate `i < R` -/

def IndepOf (i : Nat) (f : (Nat → Bool) → Int) : Prop :=
  ∀ b, f (update b i false) = f (update b i true)

theorem sumCube_eq_zero_of_indep :
    ∀ (R i : Nat) (f : (Nat → Bool) → Int),
      i < R →
      IndepOf i f →
      sumCube R f = 0
  | 0, _, _, hi, _ => by omega
  | R + 1, i, f, hi, hindep => by
      dsimp only [sumCube]
      if hEq : i = R then
        -- `i` no longer occurs in the goal (dsimp already exposed `R`), only in `hindep`
        rw [hEq] at hindep
        have hfg : sumCube R (fun b => f (update b R false)) =
            sumCube R (fun b => f (update b R true)) :=
          sumCube_congr R _ _ hindep
        rw [hfg]
        omega
      else
        have hlt : i < R := by omega
        have hInd0 : IndepOf i (fun b => f (update b R false)) := by
          intro b
          dsimp only
          rw [update_comm b i R false false hEq, update_comm b i R true false hEq]
          exact hindep (update b R false)
        have hInd1 : IndepOf i (fun b => f (update b R true)) := by
          intro b
          dsimp only
          rw [update_comm b i R false true hEq, update_comm b i R true true hEq]
          exact hindep (update b R true)
        rw [sumCube_eq_zero_of_indep R i _ hlt hInd0,
            sumCube_eq_zero_of_indep R i _ hlt hInd1]
        omega

theorem sumCube_const (R : Nat) (c : Int) (hR : 1 ≤ R) :
    sumCube R (fun _ => c) = 0 :=
  sumCube_eq_zero_of_indep R 0 (fun _ => c) (by omega) (fun _ => rfl)

/-! ### 3. Monomials and Low-Degree Polynomials (Gate 113 & Gate 205) -/

def evalMonomial : List Nat → (Nat → Bool) → Int
  | [], _ => 1
  | j :: rest, b =>
      match b j with
      | true => evalMonomial rest b
      | false => 0

theorem evalMonomial_indep_of_not_mem (i : Nat) :
    ∀ S : List Nat, i ∉ S → IndepOf i (evalMonomial S)
  | [], _ => fun _ => rfl
  | j :: rest, hnot => by
      intro b
      dsimp only [evalMonomial]
      have hne : j ≠ i := fun heq => hnot (heq ▸ List.Mem.head rest)
      have hnotRest : i ∉ rest := fun hm => hnot (List.Mem.tail j hm)
      rw [update_other b i j false hne, update_other b i j true hne]
      cases b j with
      | false => rfl
      | true => exact evalMonomial_indep_of_not_mem i rest hnotRest b

/-- Pigeonhole on `Nat` lists: any list `S` of length `< R` misses some index `i < R`. -/
def memNatBool (x : Nat) : List Nat → Bool
  | [] => false
  | y :: rest => if y = x then true else memNatBool x rest

theorem memNatBool_eq_true (x : Nat) :
    ∀ l : List Nat, memNatBool x l = true ↔ x ∈ l
  | [] => by
      constructor
      · intro h; cases h
      · intro h; cases h
  | y :: rest => by
      dsimp only [memNatBool]
      split
      · rename_i h
        subst h
        constructor
        · intro _; exact List.Mem.head rest
        · intro _; rfl
      · rename_i h
        constructor
        · intro hm; exact List.Mem.tail y ((memNatBool_eq_true x rest).mp hm)
        · intro hm
          cases hm with
          | head => exact absurd rfl h
          | tail _ htail => exact (memNatBool_eq_true x rest).mpr htail

def removeNat (x : Nat) : List Nat → List Nat
  | [] => []
  | y :: rest => if y = x then removeNat x rest else y :: removeNat x rest

theorem removeNat_mem_of_ne (x z : Nat) (hne : z ≠ x) :
    ∀ l : List Nat, z ∈ l → z ∈ removeNat x l
  | [], h => by cases h
  | y :: rest, h => by
      dsimp only [removeNat]
      cases h with
      | head =>
          split
          · rename_i heq; exact absurd heq hne
          · exact List.Mem.head _
      | tail _ htail =>
          split
          · exact removeNat_mem_of_ne x z hne rest htail
          · exact List.Mem.tail y (removeNat_mem_of_ne x z hne rest htail)

theorem removeNat_length_lt (x : Nat) :
    ∀ l : List Nat, x ∈ l → (removeNat x l).length < l.length
  | [], h => by cases h
  | y :: rest, h => by
      dsimp only [removeNat]
      cases h with
      | head =>
          simp only [ite_true, List.length_cons]
          have hle : ∀ l' : List Nat, (removeNat x l').length ≤ l'.length := by
            intro l'
            induction l' with
            | nil => exact Nat.le_refl 0
            | cons a as ih =>
                dsimp only [removeNat]
                split <;> simp only [List.length_cons] <;> omega
          have := hle rest
          omega
      | tail _ htail =>
          have ih := removeNat_length_lt x rest htail
          split <;> simp only [List.length_cons] <;> omega

theorem exists_missing_index :
    ∀ (R : Nat) (S : List Nat), S.length < R → ∃ i, i < R ∧ i ∉ S
  | 0, _, h => absurd h (Nat.not_lt_zero _)
  | R + 1, S, h => by
      cases hmem : memNatBool R S with
      | false =>
          refine ⟨R, Nat.lt_succ_self R, ?_⟩
          intro hm
          have ht := (memNatBool_eq_true R S).mpr hm
          rw [hmem] at ht
          cases ht
      | true =>
          have hRmem : R ∈ S := (memNatBool_eq_true R S).mp hmem
          have hlt : (removeNat R S).length < R := by
            have h1 := removeNat_length_lt R S hRmem
            omega
          rcases exists_missing_index R (removeNat R S) hlt with ⟨i, hi, hnot⟩
          refine ⟨i, Nat.lt_succ_of_lt hi, ?_⟩
          intro hiS
          have hne : i ≠ R := by omega
          exact hnot (removeNat_mem_of_ne R i hne S hiS)

/-- A polynomial of degree `≤ d` represented as a list of `(coeff, monomial)` terms. -/
abbrev Poly := List (Int × List Nat)

def evalPoly : Poly → (Nat → Bool) → Int
  | [], _ => 0
  | (c, S) :: rest, b => c * evalMonomial S b + evalPoly rest b

def PolyDegLe (d : Nat) (P : Poly) : Prop :=
  ∀ c S, (c, S) ∈ P → S.length ≤ d

/-- Gate 113 core: `Λ_R(P) = 0` for every polynomial `P` of degree `< R`. -/
theorem sumCube_poly_eq_zero (R d : Nat) (hd : d < R) :
    ∀ P : Poly, PolyDegLe d P → sumCube R (evalPoly P) = 0
  | [], _ => sumCube_zero R
  | (c, S) :: rest, hdeg => by
      have hSlen : S.length < R := Nat.lt_of_le_of_lt (hdeg c S (List.Mem.head rest)) hd
      rcases exists_missing_index R S hSlen with ⟨i, hi, hnot⟩
      have hMon : sumCube R (evalMonomial S) = 0 :=
        sumCube_eq_zero_of_indep R i (evalMonomial S) hi (evalMonomial_indep_of_not_mem i S hnot)
      have hRest : sumCube R (evalPoly rest) = 0 :=
        sumCube_poly_eq_zero R d hd rest (fun c' S' hm => hdeg c' S' (List.Mem.tail (c, S) hm))
      have hStep : evalPoly ((c, S) :: rest) =
          fun b => c * evalMonomial S b + evalPoly rest b := rfl
      rw [hStep, sumCube_add, sumCube_mul_const, hMon, hRest]
      omega

/-! ### 4. Exact Evaluation on Target `OR_R` and Mod-p Lower Bound (Corollary XXI.5) -/

def orPrefix : Nat → (Nat → Bool) → Int
  | 0, _ => 0
  | R + 1, b =>
      match b R with
      | true => 1
      | false => orPrefix R b

theorem orPrefix_update_ge (R k : Nat) (v : Bool) (hge : R ≤ k) :
    ∀ b : Nat → Bool, orPrefix R (update b k v) = orPrefix R b := by
  induction R with
  | zero => intro _; rfl
  | succ R ih =>
      intro b
      dsimp only [orPrefix]
      have hne : R ≠ k := by omega
      rw [update_other b k R v hne]
      cases b R with
      | true => rfl
      | false => exact ih (by omega) b

/-- Exact dual evaluation on `OR_R`: `Λ_R(OR_R) = -1` for every `R ≥ 1`. -/
theorem sumCube_orPrefix :
    ∀ R : Nat, 1 ≤ R → sumCube R (orPrefix R) = -1
  | 0, h => by omega
  | 1, _ => by
      dsimp only [sumCube, orPrefix, update]
      rfl
  | R + 2, _ => by
      show sumCube (R + 1) (fun b => orPrefix (R + 2) (update b (R + 1) false)) -
        sumCube (R + 1) (fun b => orPrefix (R + 2) (update b (R + 1) true)) = -1
      have h0 : sumCube (R + 1) (fun b => orPrefix (R + 2) (update b (R + 1) false)) =
          sumCube (R + 1) (orPrefix (R + 1)) := by
        apply sumCube_congr
        intro b
        dsimp only [orPrefix]
        rw [update_same]
        exact orPrefix_update_ge (R + 1) (R + 1) false (Nat.le_refl _) b
      have h1 : sumCube (R + 1) (fun b => orPrefix (R + 2) (update b (R + 1) true)) =
          sumCube (R + 1) (fun _ => 1) := by
        apply sumCube_congr
        intro b
        dsimp only [orPrefix]
        rw [update_same]
      rw [h0, h1, sumCube_orPrefix (R + 1) (by omega), sumCube_const (R + 1) 1 (by omega)]
      omega

/-- Congruence preservation of `sumCube` modulo any integer `p`. -/
theorem sumCube_emod_congr (p : Int) :
    ∀ (R : Nat) (f g : (Nat → Bool) → Int),
      (∀ b, f b % p = g b % p) →
      sumCube R f % p = sumCube R g % p
  | 0, f, g, h => h _
  | R + 1, f, g, h => by
      dsimp only [sumCube]
      have h0 := sumCube_emod_congr p R
        (fun b => f (update b R false)) (fun b => g (update b R false))
        (fun b => h (update b R false))
      have h1 := sumCube_emod_congr p R
        (fun b => f (update b R true)) (fun b => g (update b R true))
        (fun b => h (update b R true))
      -- `omega` cannot reason about `%`; apply `Int.sub_emod` on both sides
      have e0 : (sumCube R (fun b => f (update b R false)) -
            sumCube R (fun b => f (update b R true))) % p =
          ((sumCube R (fun b => f (update b R false))) % p -
            (sumCube R (fun b => f (update b R true))) % p) % p :=
        Int.sub_emod _ _ p
      have e1 : (sumCube R (fun b => g (update b R false)) -
            sumCube R (fun b => g (update b R true))) % p =
          ((sumCube R (fun b => g (update b R false))) % p -
            (sumCube R (fun b => g (update b R true))) % p) % p :=
        Int.sub_emod _ _ p
      rw [e0, e1, h0, h1]

/-- Theorem XXI.4 & Corollary XXI.5 (Exact Mod-p Degree Lower Bound for `OR_R`):
    For ANY modulus `p ≥ 2` (in particular every prime `p`), ANY `R ≥ 1`, and
    ANY polynomial `P` of degree `< R`, `P` CANNOT agree with `OR_R` modulo `p`
    on the Boolean cube `{0,1}^R`. -/
theorem no_low_deg_mod_p_OR (p : Int) (hp : 2 ≤ p) (R d : Nat)
    (hR : 1 ≤ R) (hd : d < R) (P : Poly) (hdeg : PolyDegLe d P) :
    ¬ (∀ b : Nat → Bool, evalPoly P b % p = orPrefix R b % p) := by
  intro hAgree
  have hMod : sumCube R (evalPoly P) % p = sumCube R (orPrefix R) % p :=
    sumCube_emod_congr p R (evalPoly P) (orPrefix R) hAgree
  rw [sumCube_poly_eq_zero R d hd P hdeg, sumCube_orPrefix R hR] at hMod
  -- hMod : (0 : Int) % p = (-1 : Int) % p, impossible for p ≥ 2
  have hzero : (0 : Int) % p = 0 := Int.zero_emod p
  rw [hzero] at hMod
  have hdvd : p ∣ (-1 : Int) := Int.dvd_of_emod_eq_zero hMod.symm
  have hdvd1 : p ∣ (1 : Int) := by
    have h := Int.dvd_neg.mpr hdvd
    simpa using h
  have hle := Int.le_of_dvd (by omega : (0:Int) < 1) hdvd1
  omega

/-- Direct diagonalization step (Gate 205 & Gate 208):
    Any `Mod_p` decider whose output on the residual cube `{0,1}^R` has degree
    `≤ (p - 1) * T * d_h < R` cannot decide `OR_R` on `{0,1}^R`. -/
theorem modular_diagonalization_step (p : Nat) (hp : 2 ≤ p) (R T d_h : Nat)
    (hR : 1 ≤ R)
    (hGap : (p - 1) * T * d_h < R)
    (P : Poly)
    (hdeg : PolyDegLe ((p - 1) * T * d_h) P) :
    ¬ (∀ b : Nat → Bool, evalPoly P b % (p : Int) = orPrefix R b % (p : Int)) :=
  no_low_deg_mod_p_OR (p : Int) (by omega) R ((p - 1) * T * d_h) hR hGap P hdeg

end RecursiveSwitching.ModularSeparation
