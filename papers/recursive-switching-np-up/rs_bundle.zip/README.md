# Recursive Switching and Modular Oracle Separations under NP = UP — Canonical Release Bundle

## Contents (`rs_bundle/`)
- `preprints/`: Canonical English (8 pp.) and Russian (9 pp.) preprints (`.tex` sources and LuaLaTeX-compiled `.pdf` files), incorporating the authorship and scope corrections and all prior audit refinements (`NP = UP` machine formulation, base switching conditions on `L_0`, explicit fixing of even lengths `2r in (n, 2n)`, `v_max` universality, explicit `C_j`/`p_*` recurrences, 4 added classical citations, active free-row replacement in Theorem 3.1, diagonalization horizon `T(m) >= 2m + 1`, and the 7-module Lean 4.36.0 Appendix).
- `lean/`: All 7 standalone zero-import Lean 4.36.0 modules locally verified on `arm64-apple-darwin24.6.0` (`exit 0`, **45/45 audited theorems**, `0 errors`, `0 sorryAx`, `0 ofReduceBool`, `0 Classical.choice`; 6 modules compile with `0 warnings`, and `TraceCapture.lean` emits 16 non-blocking deprecation warnings on `if_pos`/`if_neg`), plus `original_*.lean` drafts for provenance.
- `scripts/`: Lean 4.36.0 verification scripts (`verify_cycle21_*.sh`) and Python finite test (`recursive_prefix_test.py`).
- `logs/`: All Lean 4.36.0 audit logs (`verify_v1.log`–`verify_v4.log`), Python finite test log (`violations=0`), and historical LuaLaTeX pass-2 logs. The LuaLaTeX logs refer to the earlier typesetting, not the replacement manuscript bytes. Lean and Python evidence is unchanged.
- `SHA256SUMS.txt`: Single canonical SHA-256 manifest for all 27 files inside `rs_bundle/`.

## Scope Boundary
The 7 Lean 4.36.0 modules machine-verify selected combinatorial, algebraic, and conditional finite-stage bridge components (`45/45` theorems). Infinite product probability measures, Chernoff bounds, the Baire Category Theorem, and the bridge to multi-tape oracle Turing machines are proved analytically in the preprints.
