# 《元同义词集与不变量》v2.5 简体中文版源文件

- 作者：Aleksandr Strand（亚历山大·斯特兰德）
- 俄语原稿 SHA-256：`8b9e143893358d6654da493b139ccaf2a78a340def2ed47bcb0f03b47a62b0a7`
- 此包包含简体中文 LaTeX、三张本地化矢量图，以及单独的编校说明。
- 构建依赖 XeLaTeX、Noto Serif CJK SC、Noto Sans CJK SC、DejaVu Sans Mono、Latin Modern Roman 和 Latin Modern Math。

```sh
xelatex -halt-on-error -interaction=nonstopmode meta_synset_invariant_preprint_v2_5_zh.tex
xelatex -halt-on-error -interaction=nonstopmode meta_synset_invariant_preprint_v2_5_zh.tex
```

两次编译用于解析图表编号与参考文献。译文不更改俄语原版或 Lean 工件。
