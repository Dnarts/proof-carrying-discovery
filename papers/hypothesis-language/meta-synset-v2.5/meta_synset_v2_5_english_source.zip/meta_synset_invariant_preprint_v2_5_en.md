# Meta-Synset and Invariant: A Typed System for Revising Research Representations

**The duality of expansion and narrowing, the algebra of the residual gap $\Delta(T)$, a dependent inference license, and a machine-verified kernel in Lean 4.36.0**

Aleksandr Strand  
23 November 2026 · English translation of preprint v2.5 · Verified kernel, Axis 2 (Gates 14–16), and unified two-axis controller in Lean 4.36.0

## Abstract

When the current hypothesis language has been refuted or ceases to distinguish mechanisms, search within a single domain runs up against conceptual fixation and is reduced to trying synonyms and local parameter values. This paper considers systematic cross-domain structural transfer as a proposed universal heuristic for escaping this impasse: deliberately comparing objects from unrelated domains breaks the inertia of the original representation and makes it possible to generate fundamentally new model classes and modes of observation. But cross-domain analogies are risky in their own right: candidate generation calls for controlled conceptual drift, while evidential verification requires referential transparency and prohibits retrospective changes to definitions. What this paper formally verifies is not the universality of heuristic search, but the typed protocol for checking it. The paper formalizes a dual architecture for the hypothesis language $L_H$. It separates two object types, the evolving meta-synset $M_t$ and the frozen invariant candidate $\Phi$, and two independent protocols: focused expansion $\mathcal P_{\rm exp}$ (Proj, Split, Merge, Freeze) and strict narrowing $\mathcal P_{\rm nar}$ (Ranker, Research-Controller). These are linked by the Freeze phase transition, the typed CertifiedTransfer with mandatory residual gap $\Delta(T)=R\setminus S_{\rm ok}$, and the StepBranch branching step.

To prevent substitution of claims and concealment of a nonempty gap under naïve scope indexing, the formal kernel follows three principles: (1) evidence `DirectEvidence s A c` is rigidly bound to the claim `c : Claim s` through the functor `Denote : Claim s → Prop`; (2) covered and total justifications are indexed by a point-dependent family `c : Q → Claim s`, so `evidenceAt` is constructed pointwise without a nonemptiness hypothesis, and `pointwise_unproved_blocks_any_total` blocks direct circumvention of the completeness bridge; (3) cross-scope lifting `liftScope` uses a conditional `ScopeBridge` (applying strictly on `ModelOk`) and leaves an explicit model gap `ModelGap`. A dependent inference license $\kappa:\mathrm{Judgement}$ is introduced, with soundness, language-restriction (`restriction_sound`), and anti-leakage theorems. For the StepBranch branching probe, full SymbolLift is shown sufficient, and each of its two conditions (`binPreserving` and `injectiveBin`) is shown separately necessary.

The second escalation axis, Axis 2 (Gates 14–16), is also formalized and verified: observation-port escalation via the gauge certificate GaugeEquivCert and exclusion of dead-end hidden variables (Gate 14); an intervention algebra with computable control mask $K$ and commutator $[T_L,T_R]$ under normalizer $N$ (Gate 15); and a quantitative residual gap $\Delta_\varepsilon$ (HasGapBound) and product certificates for two independent e-values (fixed horizon 2) on exact discrete measures (Gate 16). In the unified two-axis controller (`unified_controller_v2_5.lean`), incompatibility of Axes 1 and 2 is proved without axioms (`active_gauge_disjoint_from_empty` via ActiveGaugeCert), a third outcome `probeSamePort` is provided, the degenerate zero measure is excluded ($0<\operatorname{totalMass}\mu$), and the port-polymorphic EpistemicState satisfies the unified safety theorem `licensed_step_preserves_valid` for all three steps (probe, escalateLang, escalatePort). Across the five modules (revision kernel, Gates 14–16, and unified controller), 48 declarations were machine-verified in Lean 4.36.0 (0 sorryAx; 25 axiom-free, with the others using only propext, Classical.choice, and Quot.sound); another 12 Gate 11–12 v12.3 theorems were verified in [2]. The final section sets out the general ADT-HYPOTHESIS/1 specification (epistemic accessibility $\mathcal E(E)$ and budgeted progress $K_B(E)$) separately from its future experimental implementation.

## 1. The problem of two incompatible modes of scientific search

The formal theory of identification and proof-carrying representational change [2, 11] operates within an existing structure. Given a fixed object language $L=(G,J_G)$, observations $D$, and a semantic version space

$$\mathcal V(L,D)=\{f\in\mathcal B(L):\forall (x,y)\in D,\ f(x)=y\},\qquad \mathcal B(L)=\operatorname{im}J_G,\tag{1}$$

one can rigorously define consistency, unique identification $|\mathcal V(L,D)|=1$, the agreement set $\operatorname{Agree}(\mathcal V)$, and one-step language elimination $\mathcal V(L,D\cup\{(q,y)\})=\varnothing$. But once the old language has already been refuted, or while the conceptual framework is still forming, the researcher faces two conflicting requirements:

1. **Expansion.** To break conceptual fixation and find a nontrivial replacement class (for instance, moving from counter memory to a stack or a queue), objects from distant domains must be compared under a deliberately incomplete preliminary lens $\lambda_t$, allowing the concept’s boundaries to shift and split.
2. **Strict narrowing.** To prevent candidate comparison, alternative rejection, and experiment selection from degenerating into retrospective tuning of definitions, each claim must have a frozen version, scope, and set of premises, and every piece of evidence must be separated from the desired but as-yet unproved generalization.

Conflating the two modes creates two symmetrical pathologies: applying final-proof requirements in the generation phase traps search among synonyms within one domain, while admitting mutable definitions at verification time produces degenerative drift. To avoid tying a data structure to its processing procedure, the hypothesis language $L_H$ strictly separates objects and protocols (Table 1 and Figure 1).

**Table 1. Separation of objects and protocols on the expansion and narrowing sides.**

| Level | Expansion side | Narrowing side |
|---|---|---|
| Object | Meta-synset $M_t=\langle\lambda_t,E_t\rangle$: an evolving cross-domain operand with a preliminary lens and internal tuple $(e_1,\ldots,e_k)$ | Invariant (candidate $\Phi=(P,S,A,\bot_\Phi)$): a frozen property $P$, stable on scope $S$ under transformations $A$ |
| Protocol | Focused-expansion protocol $\mathcal P_{\rm exp}$: Proj, Split, Merge, Freeze transitions | Strict-narrowing protocol $\mathcal P_{\rm nar}$: evaluation (Ranker) and probe selection (Research-Controller) |

![](figures/fig1_dual_loop.en.pdf){width=100%}

**Figure 1. Dual architecture of objects $(M_t,\Phi)$ and protocols $(\mathcal P_{\rm exp},\mathcal P_{\rm nar})$.** The evolving meta-synset $M_t$ cannot enter narrowing protocol $\mathcal P_{\rm nar}$ directly without the Freeze phase transition, which fixes candidates $\Phi$ and residual gap $\Delta(T)$.

<!-- Figure text equivalent:
- Expansion protocol $P_{\rm exp}$ (operates on meta-synset $M_t$): Operand $M_0=\langle\lambda_0,E_0\rangle$ (cross-domain lens) → Proj($M_t,D$) → $(E_D,\delta_D)$ (projection and recording of losses) → Split($M_t,\tau_{\rm blind}/\tau_{\rm axis}$) (pruning/bifurcation).
- Freeze phase transition: $M_t\to\{\Phi_i\},\Delta(T)$.
- Narrowing protocol $P_{\rm nar}$ (operates on invariants $\Phi$): Ranker (evaluation of $\Phi$; four-valued order $\operatorname{Ent}(T_2)\subseteq\operatorname{Ent}(T_1)$) → Research-Controller (StepBranch, $\max\operatorname{Gain}_{\min}(q)$) → CertifiedRev/ScopeBridge (carrier and residual $\Delta(T)$).
- Feedback: refutation or empty menu → new branch $M_{t+1}$.
-->


## 2. The meta-synset $M_t$, internal tuple, and focused-expansion protocol $\mathcal P_{\rm exp}$

Unlike an ordinary synset (WordNet), which groups synonyms within one subject layer, a meta-synset organizes the controlled accumulation of structural analogues across domains and brings them to a bifurcation point where hidden axes of difference become visible [1].

**Definition 2.1 (Meta-synset and internal tuple).** Let $\mathcal U=\bigsqcup_{d\in\mathcal D}\operatorname{Obj}_d$ be the tagged union of domain objects. The preliminary lens at version $t$ is a partial selection procedure $\lambda_t:\mathcal U\rightharpoonup\mathcal P(\mathrm{Pred})$ that must be able to report inapplicability without choosing new features retrospectively. The version-$t$ meta-synset operand is $M_t=\langle\lambda_t,E_t\rangle$, with $\lvert\operatorname{domains}(M_t)\rvert\ge2$. The internal tuple of evidence within $M_t$ has coordinates

$$e=(d,I,s^-,s^+,u,K,\alpha,\delta,\kappa),\tag{2}$$

where $I=(X,Y,Z,B)$ specifies the interface and budget; $u:s^-\mapsto s^+$ is an admissible operation; $K$ is the mask of held, changed, and uncontrolled coordinates; $\alpha=(a,b,c,\eta)$ is the structural map; $\delta$ records lost and unverified properties; and $\kappa$ is the dependent inference license (§5).

The meta-synset $M_t$ is itself a versioned operand, not a procedure. The focused-expansion protocol $\mathcal P_{\rm exp}$ specifies all admissible transitions over $M_t$ through typed operators:

- $\operatorname{Proj}(M_t,D)\to(E_D,\delta_D)$: project lens $\lambda_t$ into a new domain $D$, with an anti-synonymy filter and immediate recording of the lost properties $\delta_D$.
- $\operatorname{Split}(M_t,\tau_{\rm blind})\to M_{t+1}$: prune an external blind counterexample without splitting the operand.
- $\operatorname{Split}(M_t,\tau_{\rm axis})\to(M^a_{t+1},M^b_{t+1})$: an axial test preserving one hidden axis and breaking the other; it records the bifurcation point, closes $M_t$, and generates two new branches.
- $\operatorname{Merge}(M_1,M_2)\to M_{12}$: merge only if the lenses are compatible and the extracted structures agree across shared domains.
- $\operatorname{Freeze}(M_t)\to\{\Phi_1,\ldots,\Phi_k\}$: a phase transition that eliminates drift and produces frozen candidates $\Phi=(P,S,A,\bot_\Phi)$.

Three axioms maintain the correctness of expansion: referential transparency (the status of $M_{t+1}$ does not carry over to $M_t$), nondegeneracy ($\lvert\operatorname{domains}(M_t)\rvert\ge2$), and termination at bifurcation ($M_t$ is closed after an axial split). Two operational gaps also maintain the distinction: the phase gap between $M_t$ and $\Phi$, and the observer-reproducibility gap. For example, starting with $M_0=\langle\lambda_{\rm filter},\{\mathrm{firewall},\ \mathrm{cell\ membrane},\ \mathrm{customs}\}\rangle$, projection to neural networks ($\delta$: “the physical barrier disappeared”) and the blind counterexample “brick wall” are followed by an axial test, “Markov blanket.” This splits the operand into two independent branches: $M_2^a$ (interface shielding) and $M_2^b$ (selective rule-based filter). Only then does Freeze($M_2^b$) hand frozen candidates over to invariant. The current Lean kernel mechanizes the basic part of $\mathcal P_{\rm exp}$ through MetaOperand, metaProj, and metaFreeze; the full semantics of Split/Merge and the seven Ranker axes remain a formal specification.

**Three concrete examples of the internal tuple $(e_1,\ldots,e_k)$.** Within a fixed version $M_t$, the internal tuple contains structured evidence from distinct domains ($d_i\ne d_j$), not meta-synsets themselves. The mandatory fields $(K,\delta,\kappa)$ prevent “empty verbal analogies”:

1. **Binary gate $F(x,\theta)=x\theta$ [1].** The pair $(e_1,e_2)$ draws from optics (optical shutter: input $x\in\{0,1\}$, switch $u:\theta\mapsto1-\theta$, $x$ held, thermal noise uncontrolled; $\delta$: diffraction and equipment cost) and threshold logic (threshold circuit $[x\ge2-\theta]$ with identity map $\alpha$; $\delta$: practical meaning of the estimate and cost of error). In both coordinates, license $\kappa=\mathrm{LocalIso}$ applies only to the four binary pairs and precludes inferring equivalence of real systems.
2. **Selective rule-based filter ($M_2^b$ after bifurcation).** The triple $(e_{\rm networks},e_{\rm biology},e_{\rm neural\ networks})$ includes a firewall ($u$: update rule table; $\kappa=\mathrm{FiniteCheck}$), a cell-membrane ion channel ($u$: change voltage/ligand; $\delta$: the symbolic rule disappeared; $\kappa$: candidate), and a guardrail ($u$: change refusal policy; $\delta$: the physical barrier disappeared; $\kappa=\mathrm{EmpiricalProtocol}$).
3. **Gauge non-identifiability (the junction of Gate 14 and LLM auditing).** The pair $(e_{\rm automata},e_{\rm LLM})$ uses the lens $Q\xrightarrow{R}Z\xrightarrow{S}Y$, observing only $S\circ R$. In $e_{\rm automata}$ (TwoStageMech Bool Bool Bool, $u=\mathrm{Bool.not}$), the license is $\kappa=\mathrm{FormalTheorem}$ (`gaugeCert_blocks_single_port_id`). In $e_{\rm LLM}$ (hidden reasoning → public summary), mask $K$ holds the public port fixed while the hidden state is uncontrolled, $\delta$ records loss of determinism and reversibility of the translation, and license $\kappa=\mathrm{NonIdent}$ permits the conclusion “the screenshot does not localize the level at which the switch occurs,” while prohibiting a conclusion about the internal language of reasoning.

## 3. Invariant $\Phi$ and strict-narrowing protocol $\mathcal P_{\rm nar}$

An invariant (initially a frozen candidate $\Phi=(P,S,A,\bot_\Phi)$) is a testable property $P$ stable under a class of transformations $A$ on scope $S$. Strict narrowing $\mathcal P_{\rm nar}$ consists of two procedures over a set of candidates $\Phi$, answering questions inaccessible to expansion $\mathcal P_{\rm exp}$: what exactly has been established (Ranker), and which experiment should be performed next (Research-Controller).

**Separating carrier from content.** The carrier of the evidence (manual derivation, Lean kernel term, finite certificate, exhaustive enumeration, or empirical protocol) does not automatically determine the strength of the conclusion. A LeanKernelTerm can prove either a particular property on four finite histories or a universal theorem on $\Sigma^*$ [1]. Ranker therefore assesses candidates along seven axes (Proof, Scope, Robustness, Causality, Transfer, Utility, Discrimination), without a synthetic aggregate score. It uses the dominance preorder $T_1\succeq T_2\iff\operatorname{Ent}(T_2)\subseteq\operatorname{Ent}(T_1)$ and a four-valued comparison outcome: dominates, is dominated, incomparable, or insufficient information. The standing of a claim is kept strictly separate from its position in the research queue: a weak hypothesis with a cheap, decisive counterexample comes first in Research-Controller’s queue.

## 4. Scope topology, sealed evidence, and the algebra of the gap $\Delta(T)$

The connecting object CertifiedTransfer (§1) is realized in the kernel by TransferCoverage and CoveredJustification. The covering partition `partition: R(q) → Sok(q) ∨ Gap(q)` guarantees the inclusion $\Delta(T)=R\setminus S_{\rm ok}\subseteq\{q\in R\mid\operatorname{Gap}(q)\}$. Exact equality with the complement requires a separate disjointness condition on $S_{\rm ok}$ and Gap. The condition `GapEmpty Gap` implies $\Delta(T)=\varnothing$.

Indexing evidence by scope alone would permit claim substitution within a scope and concealment of a nonempty gap during Lift. Conversely, even separating CoveredJustification and TotalJustification, a claim `c : Claim s` constant over $Q$ would not prevent direct construction of TotalJustification, bypassing the completeness bridge. The verified kernel (`epistemic_revision_kernel_v2_4.lean`) closes both loopholes using the point-dependent claim family `c : Q → Claim s`.

**Topology of the four scopes.** All claims are divided into four disjoint Scopes: FinitePrefix (a finite prefix of the strictly append-only RawLog), LanguageMenu (a finite menu $R$ of alternatives frozen before experimentation), InfiniteLanguage (all words of the infinite set $\Sigma^*$), and RevisionSpace (the space of traces and revision layers $\Delta_L/\Delta_D/\Delta_\pi$).

**Listing 1. Verified kernel (Lean 4.36.0): point-dependent claims `c : Q → Claim s`, pointwise evidenceAt, and a conditional ScopeBridge.**

```lean
structure CoveredJustification (Q : Type) (s : Scope) (A : Premise) (c : Q → Claim s)
    where
  R          : Q → Prop
  Covered    : Q → Prop
  Gap        : Q → Prop
  partition  : ∀ q : Q, R q → Covered q ∨ Gap q
  localProof : A → ∀ q : Q, Covered q → Denote (c q)

structure TotalJustification (Q : Type) (s : Scope) (A : Premise)
    (c : Q → Claim s) where
  R          : Q → Prop
  evidenceAt : ∀ q : Q, R q → DirectEvidence s A (c q)
  fullCover  : A → ∀ q : Q, R q → Denote (c q)

structure ScopeBridge (Q2 : Type) (s1 s2 : Scope) (A1 A2 : Premise)
    (c1 : Claim s1) (c2 : Q2 → Claim s2) (ModelOk : Q2 → Prop) where
  liftProof : A2 → Denote c1 → ∀ q : Q2, ModelOk q → Denote (c2 q)
```

![](figures/fig2_scope_lattice_v2.en.pdf){width=100%}

**Figure 2. Scope topology and two different bridges in the kernel.** The completeness bridge `bridgeComplete` closes a gap under GapEmpty within a single scope; the cross-scope lift `liftScope` carries Total in FinitePrefix into Covered in InfiniteLanguage with explicit ModelGap.

<!-- Figure text equivalent:
- Covered (FinitePrefix), partition $R\to\mathrm{Cov}\lor\mathrm{Gap}$ → bridgeComplete (GapEmpty) → Total (FinitePrefix), DirectEvidence s A c.
- Total (FinitePrefix) → liftScope (ScopeBridge), changing the kind of gap to ModelGap → Covered (InfiniteLanguage), $\forall w\in\Sigma^*$, explicit ModelGap (hasEpsilon).
- Direct transport from Covered (FinitePrefix) to Covered (InfiniteLanguage) is forbidden.
- Covered (InfiniteLanguage) → Total (InfiniteLanguage) only under GapEmpty; blocked if $\exists m,\mathrm{hasEps}(m)$.
- Total (FinitePrefix) → Menu Split → LanguageMenu (StepBranch, SymbolLift, Gain_min) → protocol observable in Obs → RevisionSpace (Obs layers $\Delta_L/\Delta_D/\Delta_\pi$).
-->


Note the asymmetry of the ScopeBridge signature: the source `c1 : Claim s1` is fixed (a single certificate for a specific trace (TraceAgrees)), whereas target `c2 : Q2 → Claim s2` is a pointwise family, because a parametric theorem lifts one finite trace-agreement certificate to an entire family $Q_2$ of target models at once.

**Theorem 4.1 (Closing the loopholes and pointwise algebra of gaps; verified in Lean 4.36.0).** The following are proved in EpistemicRevisionV2 (without kernel axioms):

1. **Intensionality** (`claim_distinct_not_reusable`): evidence for cTrue cannot be used to construct DirectEvidence for cFalse in the same scope.
2. **Pointwise bridge without a nonemptiness hypothesis** (bridgeComplete): given GapEmpty Gap, `evidenceAt q hRq` is constructed pointwise from partition and localProof, with no additional nonemptiness hypothesis on the query set.
3. **Blocking any direct total justification** (`pointwise_unproved_blocks_any_total`): if $\exists q_0\in Q,\ R(q_0)\land A\land\neg\operatorname{Denote}(c\,q_0)$, no TotalJustification with exactly the same scope `tot.R = R` exists at all (it cannot be constructed even by bypassing bridgeComplete). A total justification on a narrowed scope $R'\subset R$ excluding $q_0$ is not ruled out.
4. **Composition of gaps** (`composeCoverage_gap_empty_iff`): along $f:Q_1\to Q_2$, the composite covered scope is $S_{{\rm ok},1}(q)\land S_{{\rm ok},2}(f(q))$; the composite gap is $\operatorname{Gap}_1(q)\lor\operatorname{Gap}_2(f(q))$.
5. **Conditional lift** (`liftScope`, `gate12_13_epsilon_blocks_any_total`): ScopeBridge operates strictly on ModelOk. If there exists a model $m_0$ with $\varepsilon$-transitions for which the claim does not follow from $A_1\land A_2$, TotalJustification with `tot.R = (fun _ => True)` over the entire model space $Q_{\rm mod}$ is impossible.

**The fundamental difference between the two bridges.** In the formal kernel, bridgeComplete and liftScope are different mathematical operations. The first closes the residual $\Delta(T)=\varnothing$ within a fixed scope. The second transfers a result across scopes and changes the nature of the gap (from a finite word sample to a model judgment about real-time StackProgram versus general PDA).

## 5. Dependent inference license $\kappa:\mathrm{Judgement}$ and RawLog dynamics

Rather than enumerating method labels, coordinate $\kappa$ in the meta-synset tuple is formalized as an independent inductive license type Judgement (in the current implementation, without explicit syntactic parameters $\alpha,\delta$), with an allowed-conclusions operator $\Gamma(\kappa)=\operatorname{AllowedConclusion}(\kappa)$. Constructors include Transport, LocalIso, Refutation, NonIdent, Expansion, Restriction, FormalTheorem, and FiniteCheck. For precise statements of the license theorems, recall the kernel definitions:
$\operatorname{LangEmbed}(L_2,L_1)\iff\forall h_2,\exists h_1,\forall w,\ L_1.\operatorname{eval}(h_1,w)=L_2.\operatorname{eval}(h_2,w)$ and
$\operatorname{VersionSpaceUnique}(L,D)\iff\forall h_1,h_2,\ (\operatorname{agreesOn}\ L\ D\ h_1\land\operatorname{agreesOn}\ L\ D\ h_2\to\forall w,\ L.\operatorname{eval}(h_1,w)=L.\operatorname{eval}(h_2,w))$,
i.e., $|\widetilde{\mathcal V}(L,D)|\le1$, including the empty version space.

**Theorem 5.1 (Restriction soundness and anti-leakage theorems; verified in Lean 4.36.0).**

1. **Restriction soundness** (`restriction_sound`, 0 axioms): for any languages with semantic embedding $\operatorname{LangEmbed}(L_2,L_1)$ (every program of $L_2$ is equivalent to some $L_1$ program), narrowing the language preserves both refutation (`VersionSpaceEmpty L1 D → VersionSpaceEmpty L2 D`) and semantic uniqueness (`VersionSpaceUnique L1 D → VersionSpaceUnique L2 D`).
2. **Anti-leakage for a finite check** (`finiteCheck_blocks_universal`, propext): there exist a bound $B$ and predicate $P$ for which $\Gamma(\operatorname{FiniteCheck}\ B\ P)$ holds but $\forall w\in\Sigma^*,\ P(w)=\mathrm{true}$ is false.
3. **Anti-leakage for refutation** (`refutation_blocks_extended`, propext): there are languages $L_1,L_2$ and a log $D$ for which $\Gamma(\operatorname{Refutation}\ L_1\ D)$ holds but $L_2$ is not refuted by $D$.
4. **Prefix monotonicity** (`versionSpaceEmpty_monotone`, 0 axioms): if language $L$ is refuted on prefix $l_1$ of a strictly append-only log (`PrefixOf l1 l2`), it remains refuted on any extension $l_2$.

On top of prefix monotonicity, the system defines the irreversibly FrozenMenu (bound to prefix frozenAt), CertifiedRev (before and after states, proof of PrefixOf, list of raw revisions $\Delta_L/\Delta_D/\Delta_\pi$, and CoveredJustification), and an end-to-end DiscoveryChain. Together with the revision-layer theorem [1, Theorem 3], this establishes that external responses without a grammar and data log do not localize the revision.

## 6. Branching controller StepBranch, SymbolLift, and the minimal probe $\operatorname{Gain}_{\min}(q)$

StepBranch replaces a rigid linear ladder (DFA → 1-DCA → DPDA) with a tree of alternatives. After the current class is refuted on prefix $D_{\le t}$, Freeze ends the work of $\mathcal P_{\rm exp}$ on meta-synset $M_t$ and supplies a frozen menu $R$ to $\mathcal P_{\rm nar}$, where Research-Controller selects probe $q$ by its guaranteed minimum elimination:

$$\operatorname{Gain}_{\min}(q)=|R|-\max_y|R_{q,y}|.\tag{3}$$

For the three-point probe that separates a stack (LIFO) from a queue (FIFO), knowing only $f(0)=b_0$ and $f(1)=b_1$ does not suffice. The explicit specification object SymbolLift $f$ is needed to certify symbolwise homomorphic extension $f(u\cdot v)=f(u)\cdot f(v)$ (where $\cdot$ denotes word concatenation), preservation of the binary alphabet (`binPreserving`: $f(0),f(1)\in\{0,1\}$), and injectivity (`injectiveBin`: $f(0)\ne f(1)$).

**Theorem 6.1 (Dependence of the probe on the null class and the necessity of SymbolLift).**

1. **Rule 110 on infinite $\mathbb Z$** [1, Theorems 4–5]: against an arbitrary effective affine map $A_t$, the minimum preparation weight is 2 ($F_t(a,b)=a\lor b$ versus $A_t(a,b)=a\oplus b$). Restricting the null class to the iterate $U^t$ of one translation-invariant affine rule at an even horizon lowers the minimum weight to 1.
2. **LIFO/FIFO separation in StepBranch** (`stepBranch_order_probe_splits`, Lean 4.36.0): given SymbolLift $f$, the five-symbol order probe $q^*=[0,1,\#,f(1),f(0)]$ returns true on the canonical stack branch and false on the canonical queue branch ($\operatorname{Gain}_{\min}(q^*)=1$).
3. **Necessity of binPreserving** (`stepBranch_fails_without_binPreserving`, Lean 4.36.0): for $f_{\rm bad}(0)=\#$ and $f_{\rm bad}(1)=0$, injectivity $f_{\rm bad}(0)\ne f_{\rm bad}(1)$ holds, but both branches return false on $q^*$ ($\operatorname{Gain}_{\min}(q^*)=0$).
4. **Necessity of injectiveBin** (`stepBranch_fails_without_injectiveBin`, Lean 4.36.0): for $f_{\rm const}(0)=f_{\rm const}(1)=0$, binPreserving holds, but both branches return true on $q^*$ ($\operatorname{Gain}_{\min}(q^*)=0$).

## 7. Axis 2: port escalation (Gate 14), intervention algebra (Gate 15), and the quantitative residual (Gate 16)

The memory hierarchy DFA → 1-DCA → DPDA → Queue (Axis 1) is triggered when the version space becomes empty ($|\mathcal V|=0$) at a fixed observation port. The dual problem arises when analyzing multicomponent systems and large language models: the version space does not shrink ($|\mathcal V|>1$), regardless of the number of queries through the same public port. This requires an orthogonal Axis 2: escalation of the observation interface itself, an algebra of interventions, and a move to probabilistic bounds on the residual gap (Figure 3).

![](figures/fig3_two_axis_roadmap_v2_5.en.pdf){width=100%}

**Figure 3. Two-axis map of research escalations.** Axis 1 changes the memory class when $|\mathcal V|=0$. Axis 2, verified in Lean 4.36.0, covers port escalation, intervention algebra, and the quantitative residual when $|\mathcal V|>1$ or noise is present.

<!-- Figure text equivalent:
- Axis 1: Gate 11 (verified), MNCert: DFA(k) → 1-DCA; Gate 12 v12.3 (verified), 1DCACert + $\forall m\ \neg$1-DCA → DPDA; Gate 13 (candidate), StepBranch + Queue ($\forall m\ \neg$DPDA).
- Kernel v2.4 (verified, 15 declarations): Scope + $c:Q\to\mathrm{Claim}\ s$ + Covered/Total + $\Delta(T)$. Unified Controller v2.5 (verified, 4 declarations): ActiveGaugeCert + $0<\mathrm{totalMass}$ + LicensedStep (probe/escalateLang/escalatePort) → Valid.
- Axis 2: Gate 14 v2.4 (verified), GaugeEquivCert → tapPort + exclusion of SpuriousExtension; Gate 15 v2.4 (verified), local mask $K(x_0)$ + commutator $[T_L,T_R]$; Gate 16 v2.4 (verified), HasGapBound $(0<\mathrm{den})$ + Markov + two-step e-value.
- In the figure, Gate 12, Kernel v2.4, and Gate 14 also lead to the unified controller; the Gate 16 link to the controller is dashed.
-->


**Theorem 7.1 (Axis 2: port, interventions, and quantitative residual; verified in Lean 4.36.0).** Three independent modules in pure Lean 4 Core (without sorry) prove these results:

1. **Gate 14** (`gate14_port_escalation_v2_4.lean`, 10 theorems [4]). For a two-stage mechanism $Q\xrightarrow R Z\xrightarrow S Y$ and reversible transformation $T$ (GaugeEquivCert: $T(R(q_0))\ne R(q_0)$), gauge twin $M_2=(T\circ R,S\circ T^{-1})$ differs from $M_1$ but is completely indistinguishable on any log through publicPort (`gaugeCert_blocks_single_port_id`). PortRefinement (the non-strict condition $\operatorname{proj}\circ P_2=P_1$) preserves prior refutations, while extended tapPort splits the gauge fiber in a single query $q_0$ (`tapPort_breaks_gaugeCert`). Separately, a dead-end SpuriousExtension with unchanged observable image cannot repair a refuted class on any log (`spurious_extension_cannot_repair_refutation`).
2. **Gate 15** (`gate15_intervention_algebra_v2_4.lean`, 8 theorems [5]). For interventions $(T_L,T_R)$ under a formal normalizer $N$, the local orthogonality of mask $K$ at $x_0$ is checked by the computable predicate checkOrthogonalControl (by decide). If $T_L$ preserves $N$ globally, commutation $N(T_L(T_Rx))=N(T_R(T_Lx))$ is equivalent to language invariance of strategy $T_R$; one noncommutation witness refutes joint invariance (`noncomm_refutes_joint_invariance`). The anti-leakage theorems `confounded_TL_fakes_noncomm_without_mask_K` and `unaligned_normalizer_fakes_semantic_shift` show that a failure to hold Held fixed, or language dependence of $N$, produces spurious noncommutation even for independent operators.
3. **Gate 16** (`gate16_stochastic_gap_evalue_v2_4.lean`, 10 theorems [6]). On exact discrete measures with weights in $\mathbb N$, the module proves Markov’s inequality (`markov_ineq`), a false rejection bound for valid e-variables $\mathbb E_\mu[E/D]\le1$: $K\cdot\operatorname{eventMass}(\mu,\{E\ge KD\})\le\operatorname{totalMass}(\mu)$ (`evalue_false_rejection_bound`), and validity of the product of two independent e-variables (`indep_two_step_evalue_product_valid`). The quantitative gap

   $$\operatorname{HasGapBound}(\mu,\operatorname{Gap},\mathrm{num},\mathrm{den})\iff(0<\mathrm{den})\land\bigl(\operatorname{eventMass}(\mu,\operatorname{Gap})\,\mathrm{den}\le\mathrm{num}\,\operatorname{totalMass}(\mu)\bigr)$$

   excludes a vacuous zero denominator (`den_zero_rejected_by_HasGapBound`, 0 axioms), generalizes GapEmpty (`gapEmpty_implies_zero_gapBound`), and satisfies subadditivity for a common denominator (`union_gap_bound`).

**Meta-synset operators and the conditional Axis 1/Axis 2 branch.** The formal kernel also defines the basic MetaOperand structure (with nondegeneracy invariant $2\le\mathrm{domainCount}$), metaProj, and metaFreeze (`metaFreeze_preserves_candidates`). It also defines the conditional branch chooseConditionalTwoAxisAction / `conditional_two_axis_routing_blocks_spurious_memory_escalation`: given postulated incompatibility of causes (disjointCause), gauge non-identifiability (axis2Gauge) blocks blind memory escalation on Axis 1. The limitation is that axis1Refuted and axis2Gauge are free predicates here. They have not yet been derived inside a unified type from VersionSpaceEmpty and GaugeEquivCert, so this theorem gives a conditional connection between the axes.

## 8. Unified two-axis controller v2.5: port polymorphism and safety on both axes

A full two-axis controller must meet four structural requirements at once: derive incompatibility of Axes 1 and 2 as a theorem from basic certificates rather than postulate it over free predicates; designate an explicit third outcome when neither escalation is sufficiently justified; exclude the degenerate zero measure $\operatorname{totalMass}\mu=0$ from gap bounds; and incorporate changes of observation port into the common transition relation LicensedStep. The self-contained module `unified_controller_v2_5.lean` (386 lines, Lean 4.36.0, EXIT_CODE: 0, 0 sorryAx [7]) implements all four.

**Listing 2. Polymorphic state EpistemicState, invariant Valid, and three licensed steps (`unified_controller_v2_5.lean`).**

```lean
structure ActiveGaugeCert (InClass : Mech Q Z Y → Prop) (D : ObsLog Q Y) where
  cert     : GaugeEquivCert Q Z Y
  inClass1 : InClass cert.M
  inClass2 : InClass (gaugeTransform cert.M cert.T)
  agreesD  : agreesPort publicPort cert.M D

inductive LicensedStep : EpistemicState Q Z Y → EpistemicState Q Z Y → Prop where
  | probe        (E) (q : Q) (o : E.O)
  | escalateLang (E) (NewClass)
                 (hRefuted     : VersionSpaceEmpty E.InClass E.port E.D)
                 (hNotSpurious : ¬ (SpuriousExtension E.port E.InClass NewClass))
  | escalatePort (E) (O' : Type) (P' : Port Q Z Y O') (proj : O' → E.O)
                 (hComm  : ∀ M q, proj (P' M q) = E.port M q)
                 (D'     : ObsLog Q O')
                 (hPref  : PrefixOf E.D (projectLog proj D'))
                 (hGauge : ActiveGaugeCert E.InClass (projectLog E.projToPublic E.D))
```

**Theorem 8.1 (Unified controller v2.5: incompatibility, measure nondegeneracy, and safety; Lean 4.36.0).** The UnifiedControllerV25 module proves four key results:

1. **Axiom-free incompatibility of the axes** (`active_gauge_disjoint_from_empty`, 0 axioms): for any class InClass and log $D$,
   $$\neg\bigl(\mathrm{VersionSpaceEmpty}\ \mathrm{InClass}\ \mathrm{publicPort}\ D\ \land\ \mathrm{Nonempty}(\mathrm{ActiveGaugeCert}\ \mathrm{InClass}\ D)\bigr).$$
   An explicit third outcome probeSamePort is introduced (`routeTwoAxis false false = .probeSamePort`).
2. **Measure nondegeneracy** (`zero_mass_rejected_by_HasGapBound`, 0 axioms): HasGapBound gains a field `mass_pos : 0 < totalMass µ`, preventing division by a zero measure.
3. **Safety on both axes** (`licensed_step_preserves_valid`, propext): each of the three steps (probe, escalateLang, escalatePort) preserves the invariant Valid: monotonicity of RefutedHistory, prefix anchoring of FrozenTransfer, integrity of the $\Delta(T)$ partition, and consistency of the axes on the public projection.
4. **Axis 2 pairwise separation** (`two_axis_beats_fixed_public_port`, propext): the gauge twins idMech and twinMech are indistinguishable on any log through publicPort, but a single tapPort query separates them.

## 9. Machine-verification status in Lean 4.36.0 and precise limits

Table 2 separates results already checked by the Lean 4.36.0 kernel (exit code 0, 0 sorryAx) from components that remain specifications, candidates, or open empirical tasks.

**Remark 9.1 (Exact limits of v2.5 established by the formal audit).**

1. **Gate 14.** PortRefinement formalizes non-strict refinement ($\operatorname{proj}\circ P_2=P_1$). The strictness of escalation is established separately in `tapPort_breaks_gaugeCert`. In SpuriousExtension, sameObs is an assumption over all $f:Q\to O$, not a syntactic consequence of grammar form.
2. **Gate 15.** Orthogonality of mask $K$ is checked locally at the specified point $x_0$. The layer-confounding theorems establish the existence of false noncommutation if Held or alignment of $N$ is violated.
3. **Limits of the Gate 16 module.** HasGapBound incorporates $0<\mathrm{den}$, confirmed by `den_zero_rejected_by_HasGapBound`. A probabilistic interpretation of the bounds additionally requires $\operatorname{totalMass}\mu>0$ (the current definition does not rule out a zero measure). The `union_gap_bound` rule needs a common denominator $q$. The `indep_two_step_evalue_product_valid` theorem proves a product for a fixed pair of steps, not arbitrary data-dependent stopping (Ville’s theorem).

**Table 2. Full map of verified modules in the v2.5 architecture (5 modules, 48 declarations, 25 axiom-free, 0 sorryAx).**

| Layer/module | Key theorems | Lean 4.36.0 axioms | Actual status |
|---|---|---|---|
| Revision kernel v2.4 | 15 declarations (`pointwise_unproved_blocks_any_total`, `stepBranch_fails_without_injectiveBin`, `metaFreeze_preserves_candidates`, `conditional_two_axis_routing...`, and others) | 9 axiom-free; 2 propext; 1 Quot.sound; 3 standard | Verified [3] (1bb76af2..., 605 lines, 0 warnings) |
| Gate 11–12 v12.3 | 12 theorems (`checkMNCert_sound`, `check1DCACert_sound`, `checkFullChomskyProtocol_sound`) | propext, Classical.choice, Quot.sound | Verified [2] (763f59d7...) |
| Gate 14 v2.4 (Port) | 10 declarations (`gaugeCert_blocks_single_port_id`, `tapPort_breaks_gaugeCert`, `spurious_extension_cannot_repair_refutation`) | 8 axiom-free; 2 propext, Quot.sound | Verified [4] (34397f38..., 272 lines, 0 warnings) |
| Gate 15 v2.4 (Operators) | 8 declarations (`checkNonCommProtocol_sound`, `noncomm_refutes_joint_invariance`, Held/N anti-leakage) | 5 axiom-free; 3 propext | Verified [5] (67fbae74..., 231 lines, 0 warnings) |
| Gate 16 v2.4 (Gap $\Delta_\varepsilon$) | 11 declarations (`markov_ineq`, `evalue_false_rejection_bound`, `indep_two_step_evalue_product_valid`, `den_zero_rejected_by_HasGapBound`) | 1 axiom-free; 3 propext; 7 propext, Quot.sound | Verified [6] (9cf958f2..., 304 lines, 0 warnings) |
| Controller v2.5 | 4 declarations (`active_gauge_disjoint_from_empty`, `zero_mass_rejected_by_HasGapBound`, `licensed_step_preserves_valid`, `two_axis_beats_fixed_public_port`) | 2 axiom-free; 2 propext | Verified [7] (2b367e23..., 386 lines, 0 warnings) |
| Gate 13 (Level 4) | QueueProgram, $\forall m\ \neg\mathrm{StackProgram}(m)$ | — | Candidate (awaiting Lean run) |
| Testbed and transfer | Budget $K_B(E)$, memory $H_9$, and transfer $H_{10}$–$H_{11}$ | — | Open program (§10) |

**Table 3. Coverage matrix for ADT-HYPOTHESIS/1 hypotheses ($H_1$–$H_{11}$) in the verified v2.5 base.**

| Hyp. | Status | Established in Lean 4.36.0 | Still open |
|---|---|---|---|
| $H_1$ | PARTIAL | Separation $X_E\nRightarrow D_E$ (Gate 14) and $D_E\nRightarrow J_E$ (kernel v2.4) | Unified three-state model $(E_1,E_2,E_3)$ |
| $H_2$ | PROVED | Refutation of DFA(k), 1-DCA(m) (Gates 11–12 [2]) | Level 4 (QueueProgram) is a candidate |
| $H_3$ | PROVED | GaugeEquivCert, tapPort, escalatePort (Gate 14, v2.5) | Non-postulated syntactic sameObs detector |
| $H_4$ | PARTIAL | Local mask $K$ at $x_0$, commutator $[T_L,T_R]$ (Gate 15) | Integration of interventions into LicensedStep |
| $H_5$ | PARTIAL | $0<\mathrm{den}$, $0<\mathrm{totalMass}\,\mu$, Markov, two-step e-value | Ville’s theorem (optional stopping) and a LicensedStep step |
| $H_6$ | PROVED | `licensed_step_preserves_valid` (probe, escalateLang, escalatePort) | Direct import of v2.4 files instead of the local kernel |
| $H_7/H_{7+}$ | PARTIAL | Qualitative separation of classes and ports | Explicit cost model $\operatorname{Cost}(s)\le B$ and $K_B(E)$ |
| $H_8$–$H_{11}$ | PROPOSED | Basic MetaOperand, metaFreeze, FrozenTransfer | Store/Recover, transfer $H_{10}$, cumulative testbed $H_{11}$ |

4. **Limits of the base kernel.** All four modules compile with 0 warnings in the combined log `ALL_4_MODULES_v2_4_VERIFICATION.log`. However, `conditional_two_axis_routing...` remains a conditional branch with postulated disjointCause over the free predicates axis1Refuted/axis2Gauge. When both are false, the default branch returns Axis 2, whereas the unified controller `unified_controller_v2_5.lean` implements the separate probeSamePort outcome. metaFreeze carries over the candidate list and log prefix but does not yet carry a full gap and provenance certificate. In `gate12_13_parametric_lift`, hPart takes premise `True ->` over all $Q_{\rm mod}$, and `pointwise_unproved_blocks_any_total` proves nonexistence for total justifications with exact scope equality `tot.R = R`.
5. **Limits of the unified controller.** The module `unified_controller_v2_5.lean` is self-contained (it reproduces core types locally without importing the v2.4 files directly). Intervention steps (Gate 15) and statistical estimation steps (Gate 16) are not yet included as separate LicensedStep constructors. Verification concerns the formal transition model, not the log of an external Python/LLM controller.

## 10. Open program ADT-HYPOTHESIS/1: from transition safety to cumulative discovery

The verified v2.5 base proves transition safety ($H_6$) and constructive barriers of expressivity and observability ($H_2,H_3$), but does not yet prove that a computable policy $\Pi$ can systematically acquire, retain, and transfer new research abilities under finite budget $B$. To separate the formalization from its upcoming implementation, we specify the objectives of the next stage (v3.0 and the experimental testbed):

1. **Epistemic accessibility.** A state $E=\langle L,P,A,D,C,W,\Delta,M,B\rangle$ has three epistemic accessibility coordinates $\mathcal E(E)=\langle X_E,D_E,J_E\rangle$ (expressibility, distinguishability within budget $B$, and justifiability), with independence laws $X_E\nRightarrow D_E$, $D_E\nRightarrow J_E$, and $J_E\subseteq X_E$.
2. **Budgeted capability progress** ($H_7,H_{7+}$). Define $K_B(E)$ as the set of tasks that can be solved and certified at total cost $\operatorname{Cost}(s)\le B$ (including probes, synthesis, port changes, and verification). A substantive revision must satisfy $\mathcal E(E')\ne\mathcal E(E)$ and $K_B(E')\setminus K_B(E)\ne\varnothing$. This rules out the trivially safe policy that always returns UNKNOWN.
3. **Memory, transfer, and cumulative discovery** ($H_9$–$H_{11}$). The typed RevisionMemory with Store/Recover operations must preserve provenance, scope, and residual gap $\Delta$. Transfer to a new domain $d_2\ne d_1$ is tested by the controlled comparison $\operatorname{SuccessRate}(\Pi,T,B)>\operatorname{SuccessRate}(\Pi_0,T,B)$ against a baseline policy $\Pi_0$ without memory or transfer.

Building a minimum reproducible testbed without an LLM for empirical tests of $H_7,H_9,H_{10},H_{11}$ is a separate next stage, deliberately kept distinct from the formal proofs in this preprint.

## 11. Conclusion

The formal perimeter of the dual architecture of objects $(M_t,\Phi)$ and protocols $(\mathcal P_{\rm exp},\mathcal P_{\rm nar})$ includes 48 machine-checked declarations across five modules in Lean 4.36.0 (25 axiom-free, 0 sorryAx): the revision kernel, Axis 2 (Gates 14–16), and the unified two-axis controller `unified_controller_v2_5.lean`, with safety proved for all three steps (probe, escalateLang, escalatePort). Central objects are sealed evidence DirectEvidence s A c; the mandatory residual gap $\Delta(T)$, with partition proof; the separation of completeness bridge bridgeComplete from cross-scope lift liftScope; the dependent inference license $\Gamma(\kappa)$; and branching selection from menu $R$ with the essential premises of SymbolLift. The two immediate next steps are local verification of Level 4 (Gate 13, QueueProgram) and a held-out testbed comparing the total cost of the branching StepBranch controller with that of linear escalation.

## References

[1] A. Strand. *Meta-Synset II: Certified Revision of the Hypothesis Language. Typed Transfer, Scope of Inference, and Verifiable Representational Change*, v0.3, manuscript, 2026.

[2] A. Strand. *Hypothesis Languages and Proof-Carrying Representational Escalation. From Finite Impossibility Certificates to Parametric Theorems on Counter and Stack Automata*, Gates 11–12 v12.3, 2026.

[3] A. Strand. `epistemic_revision_kernel_v2_4.lean`: Formal kernel of the v2.4 revision system (Lean 4.36.0, SHA-256 `1bb76af2f6cc03348fa35e605d6ce41dfbd35cfcb9f5ae2a0ec8491c792319c7`, 15 declarations, 0 warnings), 2026.

[4] A. Strand. `gate14_port_escalation_v2_4.lean`: Observation-port escalation and exclusion of dead-end extensions (Lean 4.36.0, SHA-256 `34397f3839bcc9cdb06335b1ca959e2f983dbad1635edf7430cb7d767e0ddcc6`, 10 declarations, 0 warnings), 2026.

[5] A. Strand. `gate15_intervention_algebra_v2_4.lean`: Intervention algebra, locally computable mask $K$, and commutator $[T_L,T_R]$ (Lean 4.36.0, SHA-256 `67fbae749cc0ab163468879396bca8e6f14f38f881ef63b78119888c4bad9c22`, 8 declarations, 0 warnings), 2026.

[6] A. Strand. `gate16_stochastic_gap_evalue_v2_4.lean`: Quantitative residual gap $\Delta_\varepsilon$ ($0<\mathrm{den}$) and product of two independent e-values (Lean 4.36.0, SHA-256 `9cf958f26f67e4112367090ff5fbbcd895dcf9db849886494164a2b9fc640d99`, 11 declarations, 0 warnings), 2026.

[7] A. Strand. `unified_controller_v2_5.lean`: Unified two-axis controller with ActiveGaugeCert, $0<\operatorname{totalMass}\mu$, and polymorphic escalatePort step (Lean 4.36.0, SHA-256 `2b367e23a3b6b0c43196027799881db2a6a75b38f1965cbb7855ef9bfc6cf1a5`, 4 declarations, 0 warnings), 2026.

[8] D. Gentner. Structure-Mapping: A Theoretical Framework for Analogy. *Cognitive Science*, 7:155–170, 1983.

[9] J. A. Goguen and R. M. Burstall. Institutions: Abstract Model Theory for Specification and Programming. *Journal of the ACM*, 39(1):95–146, 1992.

[10] D. Blackwell. Equivalent Comparisons of Experiments. *Annals of Mathematical Statistics*, 24(2):265–272, 1953.

[11] D. Angluin. Learning Regular Sets from Queries and Counterexamples. *Information and Computation*, 75(2):87–106, 1987.

[12] J. Myhill. Finite Automata and the Representation of Events. WADC Technical Report, 57–624, 1957.

[13] A. Nerode. Linear Automaton Transformations. *Proceedings of the American Mathematical Society*, 9(4):541–544, 1958.

[14] I. Lakatos. *Proofs and Refutations: The Logic of Mathematical Discovery*. Cambridge University Press, 1976.

[15] B. Huffman and O. Kunčar. Lifting and Transfer: A Modular Design for Quotients. *CPP 2013*, LNCS 8307, pp. 131–146, 2013.

[16] S. Jha and S. A. Seshia. A Theory of Formal Synthesis via Inductive Learning. *Acta Informatica*, 54:693–726, 2017.
