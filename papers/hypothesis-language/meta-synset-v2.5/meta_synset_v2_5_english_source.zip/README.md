# English source — Meta-Synset and Invariant v2.5

Aleksandr Strand, 23 November 2026.

Translated from the revised 15-page Russian v2.5 PDF submitted by the author at
20:09 UTC on 23 November 2026:
`8b9e143893358d6654da493b139ccaf2a78a340def2ed47bcb0f03b47a62b0a7`
(SHA-256; matches the supplied manifest). The earlier files bearing the same
version number were not used as the source of final wording.

The ready-to-build LaTeX file and editable Markdown are included. For the
provided LaTeX edition, use XeLaTeX with Noto Serif and DejaVu Sans Mono, keeping
the figures in the adjacent `figures/` directory:

```sh
xelatex -halt-on-error -interaction=nonstopmode meta_synset_invariant_preprint_v2_5_en.tex
xelatex -halt-on-error -interaction=nonstopmode meta_synset_invariant_preprint_v2_5_en.tex
```

The translation preserves the author's claims and version labels. This package
is not an independently recompiled Lean verification bundle.
