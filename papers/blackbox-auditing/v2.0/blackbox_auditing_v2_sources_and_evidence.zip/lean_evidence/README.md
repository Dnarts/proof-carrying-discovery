# MULTILINEAR_W10 — Level 0/1 + Level 1/2 Root Composition

Verified in Lean Lean (version 4.36.0, arm64-apple-darwin24.6.0, commit 611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9, Release)

## Status

| | |
|---|---|
| Modules | 6 / 6 compile |
| Declarations audited | 40 / 40 |
| Axiom-free declarations | 4 |
| errors | 0 |
| warnings | 0 |
| `sorryAx` | 0 |
| `Lean.ofReduceBool` | 0 |
| `Classical.choice` | 0 |
| Gate exit code | 0 |

Remaining axioms across all 40 declarations: `propext` and `Quot.sound` only.
Zero external imports. Pure Lean 4 core — no Mathlib, no Std.

## Modules

Group 1 — Level 0/1 kernel (compiles standalone):

- `F3Multilinear.lean` — multilinear extension over F_3, Boolean agreement, uniqueness,
  single-query row-sum decoding at `(x, 2, …, 2)`.
- `HiddenRow.lean` — constructive finite pigeonhole, unqueried word inside a row,
  `pointUpdate` locality, unique-witness row invariant GI_1 / GI_2.
- `AcyclicKernel.lean` — concrete `encode`/`decode`, roundtrip, soundness, strict fuel bound,
  oracle locality `K^A_r = K^B_r`.
- `OracleDiagonal.lean` — constructive `pickWord` / `pickRowSlot`, explicit `chooseDiagLen`,
  surjective `unpairNat`, layered `fillRange` / `stepStage`, infinite-limit `globalOracle`;
  roots `stage_monotone`, `globalOracle_agrees_stage`, `globalOracle_GI1`,
  `globalOracle_GI2`, `globalOracle_defeats_all_P`.

Group 2 — composition and profile topology (qualified namespaces):

- `AsymmetricCollapse.lean` (`MultilinearW10.AsymmetricCollapse`) — root theorem
  `asymmetric_collapse_root` over `namespace MultilinearW10.AsymmetricCollapse`.
  Parameterized by the `VerifiedLevel01` interface matching the verified Level 0/1
  signatures; it does not import them.
- `ProfileTopology.lean` (`MultilinearW10.ProfileTopology`) — `v ≤ u`,
  `exactly_three_valid_profiles`, `c_min(W_10) = 1`, persistent target ambiguity on
  tail sequences.

## Reproduction

```bash
shasum -a 256 -c SHA256SUMS.txt
bash verify_release.sh
```

The gate exits `0` only when every module compiles with no errors, no warnings, no
`sorryAx`, no `Lean.ofReduceBool`, no `Classical.choice`, and no forbidden tokens in code
(comments stripped before the token scan). It also fails on any leftover debug `#print`
line in a source file (exit 4).

## On module composability — read this before adding files

The six modules are each **self-contained and separately verified**. They are not a single
library:

- `F3Multilinear`, `HiddenRow`, `AcyclicKernel` and `OracleDiagonal` each declare
  `MultilinearW10.Word` and `MultilinearW10.Oracle` in the bare `MultilinearW10` namespace.
  `AcyclicKernel` and `OracleDiagonal` additionally declare `MultilinearW10.Code`.
- `AsymmetricCollapse` and `ProfileTopology` use qualified namespaces and therefore compose
  with anything in this bundle.
- Concatenating two of the first four produces duplicate-declaration errors. That is by
  design of the "zero imports" style, not a defect in any individual proof.

Verified pairwise: `OD+AC`, `OD+PT`, `AC+PT`, `F3+AC`, `F3+PT`, `HR+AC`, `HR+PT`,
`AK+AC`, `AK+PT` all concatenate clean. Only the four core modules clash with each other.
If a future module needs to reference these definitions, qualify its namespace and treat
the core vocabulary as a documented signature rather than re-declaring it.

## Notes on the proof style

`Classical.choice` was removed at its actual source, measured rather than guessed:

1. Bare `simp at h` (no lemma list) on a `List.length` equality imports `Classical.choice`.
   `simp only [...] at h; omega` does not. Affected `HiddenRow`, `F3Multilinear`.
2. `omega` closing a goal whose *conclusion is an existential* emits
   `Classical.byContradiction`; the same goal reduced with `exfalso; omega` does not.
   Affected `OracleDiagonal.stageState_invariants` and therefore both GI roots.
3. In `ProfileTopology.le_listMax`, `cases h with | head =>` substitutes `a := b`, so the
   list head is no longer in the context — the goal becomes `a ≤ max a (listMax bs)`.

No theorem statement was weakened to make a gate pass; only proof bodies changed.

## Hashes

```
F3Multilinear.lean       eb37a377aa7dbf24f58c1094049fd3fd454a17e06a3aa076a9f69c2fd57138f1
HiddenRow.lean           8d80d618f611f4e68b0104352e6af9de007515cbbbe680e31c48c3b7e5a0746e
AcyclicKernel.lean       f0d873487b419207a9bd8a55f36763c611b6294bf35f057f8ce7d79d7014db0a
OracleDiagonal.lean      7bff2ef97995baf974cac4558ebb7b393855905223dcfb05f58fc10c5e8afedd
AsymmetricCollapse.lean  3e9c83638a54d8a1bf5ac2cb7bc15e84c3de4311ab5a064db31a0c1e3e71bdc7
ProfileTopology.lean     f9cf22a3a9cacc27c4821af905517f70fe13a8230771c6fd624d035ecbed6a58
```

Log timestamp: 2026-11-25 20:03:08 IST
