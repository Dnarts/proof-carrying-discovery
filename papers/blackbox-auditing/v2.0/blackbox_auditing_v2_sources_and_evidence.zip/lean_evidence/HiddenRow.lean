/-
  HiddenRow.lean — v0.4 (0 external imports, Lean 4.36.0 target)
  Level 0 (Unconditional Combinatorial Kernel) for MULTILINEAR_W10 (c = 1).

  Proves constructively (without Classical.choice):
  1. `exists_unqueried_word`: if Q.length < 2^k, there exists y of length k with y ∉ Q.
  2. `exists_unqueried_in_row`: if Q.length < 2^k, there exists y of length k with x ++ y ∉ Q.
  3. `pointUpdate` locality and unique-witness row invariant GI_1 / GI_2.
-/

namespace MultilinearW10

abbrev Word := List Bool
abbrev Oracle := Word → Bool

def allWordsH : Nat → List Word
  | 0 => [[]]
  | n + 1 => (allWordsH n).map (false :: ·) ++ (allWordsH n).map (true :: ·)

theorem nodup_map_of_inj_H {α β : Type} (f : α → β) (hf : ∀ a b, f a = f b → a = b)
    (xs : List α) (hnd : xs.Nodup) : (xs.map f).Nodup := by
  induction xs with
  | nil => simp
  | cons a as ih =>
    have hnd' := List.nodup_cons.mp hnd
    refine List.nodup_cons.mpr ⟨?_, ih hnd'.2⟩
    intro hmem
    rcases List.mem_map.mp hmem with ⟨x, hx, hfx⟩
    exact hnd'.1 (hf x a hfx ▸ hx)

theorem allWordsH_length (n : Nat) : (allWordsH n).length = 2 ^ n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [allWordsH, List.length_append, List.length_map, ih, Nat.pow_succ]
    omega

theorem mem_allWordsH (n : Nat) (w : Word) : w ∈ allWordsH n ↔ w.length = n := by
  induction n generalizing w with
  | zero =>
    simp only [allWordsH, List.mem_singleton, List.length_eq_zero_iff]
  | succ n ih =>
    simp only [allWordsH, List.mem_append, List.mem_map]
    constructor
    · rintro (⟨u, hu, rfl⟩ | ⟨u, hu, rfl⟩) <;> simp [(ih u).mp hu]
    · intro hlen
      cases w with
      | nil => simp only [List.length_nil] at hlen; omega
      | cons b u =>
        have hu : u ∈ allWordsH n := (ih u).mpr (by simpa using hlen)
        cases b
        · exact Or.inl ⟨u, hu, rfl⟩
        · exact Or.inr ⟨u, hu, rfl⟩

theorem allWordsH_nodup (n : Nat) : (allWordsH n).Nodup := by
  induction n with
  | zero => simp [allWordsH]
  | succ n ih =>
    simp only [allWordsH]
    refine List.nodup_append.mpr ⟨?_, ?_, ?_⟩
    · exact nodup_map_of_inj_H (false :: ·) (fun _ _ h => (List.cons.inj h).2) (allWordsH n) ih
    · exact nodup_map_of_inj_H (true :: ·) (fun _ _ h => (List.cons.inj h).2) (allWordsH n) ih
    · intro x hx y hy hxy
      simp only [List.mem_map] at hx hy
      rcases hx with ⟨u, _, rfl⟩
      rcases hy with ⟨v, _, rfl⟩
      cases hxy

/-! ### 1. Constructive finite pigeonhole (0 Classical.choice) -/

def eraseOne {α : Type} [DecidableEq α] (a : α) : List α → List α
  | [] => []
  | y :: ys => if y = a then ys else y :: eraseOne a ys

theorem length_eraseOne_lt {α : Type} [DecidableEq α] (a : α) (ys : List α) (hmem : a ∈ ys) :
    (eraseOne a ys).length + 1 = ys.length := by
  induction ys with
  | nil => cases hmem
  | cons y ys ih =>
    if hya : y = a then
      subst hya
      simp only [eraseOne, ↓reduceIte, List.length_cons]
    else
      have hmem' : a ∈ ys := by
        cases hmem with
        | head => exact absurd rfl hya
        | tail _ h => exact h
      simp only [eraseOne, hya, ↓reduceIte, List.length_cons]
      have := ih hmem'
      omega

theorem mem_eraseOne_of_ne {α : Type} [DecidableEq α] {x a : α} {ys : List α}
    (hne : x ≠ a) (hmem : x ∈ ys) : x ∈ eraseOne a ys := by
  induction ys with
  | nil => cases hmem
  | cons y ys ih =>
    if hya : y = a then
      subst hya
      simp only [eraseOne, ↓reduceIte]
      cases hmem with
      | head => exact absurd rfl hne
      | tail _ h => exact h
    else
      simp only [eraseOne, hya, ↓reduceIte]
      cases hmem with
      | head => exact List.Mem.head _
      | tail _ h => exact List.Mem.tail _ (ih h)

theorem exists_not_mem_of_nodup_lt {α : Type} [DecidableEq α] (xs ys : List α)
    (hnd : xs.Nodup) (hlt : ys.length < xs.length) :
    ∃ x ∈ xs, x ∉ ys := by
  induction xs generalizing ys with
  | nil => simp only [List.length_nil] at hlt; omega
  | cons a as ih =>
    have hnd' := List.nodup_cons.mp hnd
    if ha : a ∈ ys then
      have hlen := length_eraseOne_lt a ys ha
      have hlt' : (eraseOne a ys).length < as.length := by
        simp only [List.length_cons] at hlt; omega
      rcases ih (eraseOne a ys) hnd'.2 hlt' with ⟨x, hx_as, hx_not⟩
      refine ⟨x, List.Mem.tail _ hx_as, ?_⟩
      intro hx_ys
      have hne : x ≠ a := fun heq => hnd'.1 (heq ▸ hx_as)
      exact hx_not (mem_eraseOne_of_ne hne hx_ys)
    else
      exact ⟨a, List.Mem.head _, ha⟩

theorem exists_unqueried_word (k : Nat) (Q : List Word) (hQ : Q.length < 2 ^ k) :
    ∃ y : Word, y.length = k ∧ y ∉ Q := by
  have hlt : Q.length < (allWordsH k).length := by
    rw [allWordsH_length]; exact hQ
  rcases exists_not_mem_of_nodup_lt (allWordsH k) Q (allWordsH_nodup k) hlt with ⟨y, hymem, hynot⟩
  exact ⟨y, (mem_allWordsH k y).mp hymem, hynot⟩

theorem exists_unqueried_in_row (x : Word) (k : Nat) (Q : List Word) (hQ : Q.length < 2 ^ k) :
    ∃ y : Word, y.length = k ∧ x ++ y ∉ Q := by
  have hmap_len : ((allWordsH k).map (x ++ ·)).length = 2 ^ k := by
    rw [List.length_map, allWordsH_length]
  have hmap_nodup : ((allWordsH k).map (x ++ ·)).Nodup :=
    nodup_map_of_inj_H (x ++ ·) (fun _ _ h => List.append_cancel_left h) (allWordsH k) (allWordsH_nodup k)
  have hlt : Q.length < ((allWordsH k).map (x ++ ·)).length := by
    rw [hmap_len]; exact hQ
  rcases exists_not_mem_of_nodup_lt _ Q hmap_nodup hlt with ⟨w, hwmem, hwnot⟩
  rcases List.mem_map.mp hwmem with ⟨y, hymem, rfl⟩
  exact ⟨y, (mem_allWordsH k y).mp hymem, hwnot⟩

/-! ### 2. Single-point oracle update and unique-witness row invariant -/

def pointUpdate (A : Oracle) (wStar : Word) (val : Bool) : Oracle :=
  fun w => if w = wStar then val else A w

theorem pointUpdate_preserves_queries (A : Oracle) (wStar : Word) (val : Bool)
    (Q : List Word) (hnot : wStar ∉ Q) :
    ∀ q ∈ Q, pointUpdate A wStar val q = A q := by
  intro q hq
  unfold pointUpdate
  have hne : q ≠ wStar := fun h => hnot (h ▸ hq)
  simp [hne]

theorem pointUpdate_row_unique (A : Oracle) (x yStar : Word) (k : Nat) (val : Bool)
    (hyStar : yStar.length = k)
    (hzero : ∀ y, y.length = k → A (x ++ y) = false) :
    ∀ y, y.length = k →
      (pointUpdate A (x ++ yStar) val (x ++ y) = true ↔ val = true ∧ y = yStar) := by
  intro y hy
  unfold pointUpdate
  if h : y = yStar then
    subst h
    simp
  else
    have hne : x ++ y ≠ x ++ yStar := fun heq => h (List.append_cancel_left heq)
    simp [hne, hzero y hy, h]

theorem pointUpdate_row_at_most_one (A : Oracle) (x yStar : Word) (k : Nat) (val : Bool)
    (hyStar : yStar.length = k)
    (hzero : ∀ y, y.length = k → A (x ++ y) = false) :
    ∀ y1 y2, y1.length = k → y2.length = k →
      pointUpdate A (x ++ yStar) val (x ++ y1) = true →
      pointUpdate A (x ++ yStar) val (x ++ y2) = true →
      y1 = y2 := by
  intro y1 y2 h1 h2 ha1 ha2
  have e1 := (pointUpdate_row_unique A x yStar k val hyStar hzero y1 h1).mp ha1
  have e2 := (pointUpdate_row_unique A x yStar k val hyStar hzero y2 h2).mp ha2
  rw [e1.2, e2.2]

end MultilinearW10
