/-
  OracleDiagonal.lean — v0.3 (0 external imports, Lean 4.36.0 target)
  Level 1 (Parametric Oracle Diagonalization) for MULTILINEAR_W10 (c = 1).

  Constructs `globalOracle M` constructively (without Classical.choice) for any
  `M : OracleMachineModel` and any local kernel `K` satisfying `kernel_local`,
  and proves:
  1. `stage_monotone` (GI_3): later stages preserve all words of length ≤ bound.
  2. `globalOracle_agrees_stage`: `globalOracle M` extends every finite stage.
  3. `globalOracle_GI1` (GI_1): for every r ≥ 1 and x of length r, row (x, ·) at
     length 2*r has a unique witness yStar iff K (globalOracle M) x = true.
  4. `globalOracle_GI2` (GI_2): every odd length 2*r+1 has at most one true entry.
  5. `globalOracle_defeats_all_P`: for every (i, k), there exists odd n such that
     `(M.runD i (clock k n) (globalOracle M) (replicate n true)).answer ≠ diagBit (globalOracle M) n`.
-/

namespace MultilinearW10

abbrev Word := List Bool
abbrev Oracle := Word → Bool
abbrev Code := Nat

def clock (k n : Nat) : Nat :=
  (n + 2) ^ k

structure DetRun where
  answer : Bool
  queries : List Word

structure OracleMachineModel where
  runD : Code → Nat → Oracle → Word → DetRun
  runN : Code → Nat → Oracle → Word → Bool
  d_count : ∀ i fuel A x, (runD i fuel A x).queries.length ≤ fuel
  d_length : ∀ i fuel A x q, q ∈ (runD i fuel A x).queries → q.length ≤ fuel
  d_replay : ∀ i fuel A B x,
    (∀ q, q ∈ (runD i fuel A x).queries → A q = B q) →
    runD i fuel A x = runD i fuel B x
  n_local : ∀ i fuel A B x,
    (∀ q : Word, q.length ≤ fuel → A q = B q) →
    runN i fuel A x = runN i fuel B x

structure LocalKernel where
  eval : Oracle → Word → Bool
  local_dep : ∀ r A B, (∀ q : Word, q.length < r → A q = B q) →
    ∀ x : Word, x.length = r → eval A x = eval B x

/-! ### 1. Constructive word enumeration and slot selection (0 Classical.choice) -/

def allWordsD : Nat → List Word
  | 0 => [[]]
  | n + 1 => (allWordsD n).map (false :: ·) ++ (allWordsD n).map (true :: ·)

theorem nodup_map_of_inj_D {α β : Type} (f : α → β) (hf : ∀ a b, f a = f b → a = b)
    (xs : List α) (hnd : xs.Nodup) : (xs.map f).Nodup := by
  induction xs with
  | nil => simp only [List.map_nil, List.nodup_nil]
  | cons a as ih =>
    have hnd' := List.nodup_cons.mp hnd
    refine List.nodup_cons.mpr ⟨?_, ih hnd'.2⟩
    intro hmem
    rcases List.mem_map.mp hmem with ⟨x, hx, hfx⟩
    exact hnd'.1 (hf x a hfx ▸ hx)

theorem allWordsD_length (n : Nat) : (allWordsD n).length = 2 ^ n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [allWordsD, List.length_append, List.length_map, ih, Nat.pow_succ]
    omega

theorem mem_allWordsD (n : Nat) (w : Word) : w ∈ allWordsD n ↔ w.length = n := by
  induction n generalizing w with
  | zero =>
    simp only [allWordsD, List.mem_singleton, List.length_eq_zero_iff]
  | succ n ih =>
    simp only [allWordsD, List.mem_append, List.mem_map]
    constructor
    · rintro (⟨u, hu, rfl⟩ | ⟨u, hu, rfl⟩)
      · simp only [List.length_cons]; rw [(ih u).mp hu]
      · simp only [List.length_cons]; rw [(ih u).mp hu]
    · intro hlen
      cases w with
      | nil => simp only [List.length_nil] at hlen; omega
      | cons b u =>
        have hu : u ∈ allWordsD n := (ih u).mpr (by simp only [List.length_cons] at hlen; omega)
        cases b
        · exact Or.inl ⟨u, hu, rfl⟩
        · exact Or.inr ⟨u, hu, rfl⟩

theorem allWordsD_nodup (n : Nat) : (allWordsD n).Nodup := by
  induction n with
  | zero => simp only [allWordsD, List.nodup_cons, List.not_mem_nil, not_false_eq_true, List.nodup_nil, and_self]
  | succ n ih =>
    simp only [allWordsD]
    refine List.nodup_append.mpr ⟨?_, ?_, ?_⟩
    · exact nodup_map_of_inj_D (false :: ·) (fun _ _ h => (List.cons.inj h).2) (allWordsD n) ih
    · exact nodup_map_of_inj_D (true :: ·) (fun _ _ h => (List.cons.inj h).2) (allWordsD n) ih
    · intro x hx y hy hxy
      simp only [List.mem_map] at hx hy
      rcases hx with ⟨u, _, rfl⟩
      rcases hy with ⟨v, _, rfl⟩
      cases hxy

def eraseOneD {α : Type} [DecidableEq α] (a : α) : List α → List α
  | [] => []
  | y :: ys => if y = a then ys else y :: eraseOneD a ys

theorem length_eraseOneD_lt {α : Type} [DecidableEq α] (a : α) (ys : List α) (hmem : a ∈ ys) :
    (eraseOneD a ys).length + 1 = ys.length := by
  induction ys with
  | nil => cases hmem
  | cons y ys ih =>
    if hya : y = a then
      subst hya
      simp only [eraseOneD, ↓reduceIte, List.length_cons]
    else
      have hmem' : a ∈ ys := by
        cases hmem with
        | head => exact absurd rfl hya
        | tail _ h => exact h
      simp only [eraseOneD, hya, ↓reduceIte, List.length_cons]
      have := ih hmem'
      omega

theorem mem_eraseOneD_of_ne {α : Type} [DecidableEq α] {x a : α} {ys : List α}
    (hne : x ≠ a) (hmem : x ∈ ys) : x ∈ eraseOneD a ys := by
  induction ys with
  | nil => cases hmem
  | cons y ys ih =>
    if hya : y = a then
      subst hya
      simp only [eraseOneD, ↓reduceIte]
      cases hmem with
      | head => exact absurd rfl hne
      | tail _ h => exact h
    else
      simp only [eraseOneD, hya, ↓reduceIte]
      cases hmem with
      | head => exact List.Mem.head _
      | tail _ h => exact List.Mem.tail _ (ih h)

def firstNotMem {α : Type} [DecidableEq α] : List α → List α → Option α
  | [], _ => none
  | a :: as, ys => if a ∈ ys then firstNotMem as ys else some a

theorem firstNotMem_spec {α : Type} [DecidableEq α] (xs ys : List α) (x : α)
    (h : firstNotMem xs ys = some x) : x ∈ xs ∧ x ∉ ys := by
  induction xs with
  | nil => simp only [firstNotMem] at h; cases h
  | cons a as ih =>
    simp only [firstNotMem] at h
    if ha : a ∈ ys then
      simp only [ha, ↓reduceIte] at h
      rcases ih h with ⟨hx_as, hx_not⟩
      exact ⟨List.Mem.tail _ hx_as, hx_not⟩
    else
      simp only [ha, ↓reduceIte, Option.some.injEq] at h
      subst h
      exact ⟨List.Mem.head _, ha⟩

theorem firstNotMem_none_all {α : Type} [DecidableEq α] (xs ys : List α)
    (hnone : firstNotMem xs ys = none) : ∀ x ∈ xs, x ∈ ys := by
  induction xs with
  | nil => intro x hx; cases hx
  | cons b bs ih =>
    simp only [firstNotMem] at hnone
    if hb : b ∈ ys then
      simp only [hb, ↓reduceIte] at hnone
      intro x hx
      cases hx with
      | head => exact hb
      | tail _ hx' => exact ih hnone x hx'
    else
      simp only [hb, ↓reduceIte] at hnone
      cases hnone

theorem firstNotMem_isSome_of_nodup_lt {α : Type} [DecidableEq α] (xs ys : List α)
    (hnd : xs.Nodup) (hlt : ys.length < xs.length) :
    ∃ x, firstNotMem xs ys = some x := by
  induction xs generalizing ys with
  | nil => simp only [List.length_nil] at hlt; exact absurd hlt (Nat.not_lt_zero _)
  | cons a as ih =>
    have hnd' := List.nodup_cons.mp hnd
    simp only [firstNotMem]
    if ha : a ∈ ys then
      simp only [ha, ↓reduceIte]
      have hlen := length_eraseOneD_lt a ys ha
      have hlt' : (eraseOneD a ys).length < as.length := by
        simp only [List.length_cons] at hlt; omega
      have hne_none : firstNotMem as ys ≠ none := by
        intro hnone
        have hall := firstNotMem_none_all as ys hnone
        rcases ih (eraseOneD a ys) hnd'.2 hlt' with ⟨x, hx⟩
        rcases firstNotMem_spec as (eraseOneD a ys) x hx with ⟨hx_as, hx_not⟩
        have hne : x ≠ a := fun heq => hnd'.1 (heq ▸ hx_as)
        exact hx_not (mem_eraseOneD_of_ne hne (hall x hx_as))
      cases hres : firstNotMem as ys with
      | none => exact absurd hres hne_none
      | some x => exact ⟨x, rfl⟩
    else
      simp only [ha, ↓reduceIte]
      exact ⟨a, rfl⟩

def pickWord (k : Nat) (Q : List Word) : Word :=
  match firstNotMem (allWordsD k) Q with
  | some y => y
  | none => List.replicate k false

theorem pickWord_spec (k : Nat) (Q : List Word) (hQ : Q.length < 2 ^ k) :
    (pickWord k Q).length = k ∧ pickWord k Q ∉ Q := by
  have hlt : Q.length < (allWordsD k).length := by rw [allWordsD_length]; exact hQ
  rcases firstNotMem_isSome_of_nodup_lt (allWordsD k) Q (allWordsD_nodup k) hlt with ⟨y, hy⟩
  unfold pickWord
  rw [hy]
  dsimp only
  rcases firstNotMem_spec (allWordsD k) Q y hy with ⟨hmem, hnot⟩
  exact ⟨(mem_allWordsD k y).mp hmem, hnot⟩

def pickRowSlot (x : Word) (k : Nat) (Q : List Word) : Word :=
  match firstNotMem ((allWordsD k).map (x ++ ·)) Q with
  | some w => w.drop x.length
  | none => List.replicate k false

theorem pickRowSlot_spec (x : Word) (k : Nat) (Q : List Word) (hQ : Q.length < 2 ^ k) :
    (pickRowSlot x k Q).length = k ∧ x ++ pickRowSlot x k Q ∉ Q := by
  have hlen : ((allWordsD k).map (x ++ ·)).length = 2 ^ k := by
    rw [List.length_map, allWordsD_length]
  have hnd : ((allWordsD k).map (x ++ ·)).Nodup :=
    nodup_map_of_inj_D (x ++ ·) (fun _ _ h => List.append_cancel_left h) (allWordsD k) (allWordsD_nodup k)
  have hlt : Q.length < ((allWordsD k).map (x ++ ·)).length := by rw [hlen]; exact hQ
  rcases firstNotMem_isSome_of_nodup_lt _ Q hnd hlt with ⟨w, hw⟩
  unfold pickRowSlot
  rw [hw]
  dsimp only
  rcases firstNotMem_spec _ Q w hw with ⟨hmem, hnot⟩
  rcases List.mem_map.mp hmem with ⟨y, hy, rfl⟩
  have hdrop : (x ++ y).drop x.length = y := List.drop_left
  rw [hdrop]
  exact ⟨(mem_allWordsD k y).mp hy, hnot⟩

/-! ### 2. Explicit computable diagonal length `chooseDiagLen` (0 Classical.choice) -/

theorem sq_lt_two_pow (t : Nat) (ht : 5 ≤ t) : t * t < 2 ^ t := by
  induction t with
  | zero => omega
  | succ t ih =>
    if ht5 : t < 5 then
      have : t = 4 := by omega
      subst this
      decide
    else
      have hge : 5 ≤ t := by omega
      have hih : t * t < 2 ^ t := ih hge
      have h2t : 2 * t + 1 ≤ t * t := by
        have : 3 ≤ t := by omega
        calc
          2 * t + 1 ≤ 3 * t := by omega
          _ ≤ t * t := Nat.mul_le_mul_right t this
      have hstep : (t + 1) * (t + 1) = t * t + (2 * t + 1) := by
        rw [Nat.add_mul, Nat.mul_add, Nat.mul_one, Nat.one_mul]
        omega
      rw [hstep, Nat.pow_succ]
      omega

theorem pow_lt_pow_left {a b k : Nat} (h : a < b) (hk : 1 ≤ k) : a ^ k < b ^ k := by
  induction k with
  | zero => omega
  | succ k ih =>
    if hk0 : k = 0 then
      subst hk0
      simp only [Nat.zero_add, Nat.pow_one]
      exact h
    else
      have h1 : 1 ≤ k := by omega
      have hih : a ^ k < b ^ k := ih h1
      rw [Nat.pow_succ, Nat.pow_succ]
      have hpos : 0 < b ^ k := Nat.pow_pos (by omega)
      calc
        a ^ k * a ≤ a ^ k * b := Nat.mul_le_mul_left (a ^ k) (Nat.le_of_lt h)
        _ < b ^ k * b := Nat.mul_lt_mul_of_pos_right hih (by omega)

def chooseDiagLen (B k : Nat) : Nat :=
  if k = 0 then
    2 * (B + 1) + 1
  else
    let t := max (B + 5) (2 * k + 5)
    2 * (k * t) + 1

theorem chooseDiagLen_odd (B k : Nat) : chooseDiagLen B k % 2 = 1 := by
  unfold chooseDiagLen
  if hk : k = 0 then
    simp only [hk, ↓reduceIte]; omega
  else
    simp only [hk, ↓reduceIte]; omega

theorem chooseDiagLen_gt (B k : Nat) : B < chooseDiagLen B k := by
  unfold chooseDiagLen
  if hk : k = 0 then
    simp only [hk, ↓reduceIte]; omega
  else
    simp only [hk, ↓reduceIte]
    have h1 : 1 ≤ k := by omega
    have ht : B + 5 ≤ max (B + 5) (2 * k + 5) := Nat.le_max_left _ _
    have hkt : max (B + 5) (2 * k + 5) ≤ k * max (B + 5) (2 * k + 5) :=
      Nat.le_mul_of_pos_left _ (by omega)
    omega

theorem chooseDiagLen_clock_lt (B k : Nat) :
    clock k (chooseDiagLen B k) < 2 ^ (chooseDiagLen B k / 2) := by
  unfold clock chooseDiagLen
  if hk : k = 0 then
    simp only [hk, ↓reduceIte, Nat.pow_zero]
    have hdiv : (2 * (B + 1) + 1) / 2 = B + 1 := by omega
    rw [hdiv, Nat.pow_succ]
    have hpos : 1 ≤ 2 ^ B := Nat.one_le_pow B 2 (by omega)
    omega
  else
    simp only [hk, ↓reduceIte]
    let t := max (B + 5) (2 * k + 5)
    have hdiv : (2 * (k * t) + 1) / 2 = k * t := by omega
    rw [hdiv]
    have ht5 : 5 ≤ t := by
      have : B + 5 ≤ t := Nat.le_max_left _ _
      omega
    have ht2k : 2 * k + 5 ≤ t := Nat.le_max_right _ _
    have hbase : 2 * (k * t) + 1 + 2 < 2 ^ t := by
      have hsq : t * t < 2 ^ t := sq_lt_two_pow t ht5
      have hmul : (2 * k + 3) * t ≤ t * t := Nat.mul_le_mul_right t (by omega)
      have hlin : 2 * (k * t) + 1 + 2 ≤ (2 * k + 3) * t := by
        rw [Nat.add_mul, Nat.mul_assoc]
        omega
      omega
    have hpow : (2 * (k * t) + 1 + 2) ^ k < (2 ^ t) ^ k :=
      pow_lt_pow_left hbase (by omega)
    rw [← Nat.pow_mul, Nat.mul_comm t k] at hpow
    exact hpow

/-! ### 3. Surjective pairing `unpair : Nat → Nat × Nat` -/

def pairNat (i k : Nat) : Nat :=
  (i + k) * (i + k + 1) / 2 + k

def unpairStep : Nat → Nat → Nat × Nat
  | d, r =>
    if r ≤ d then (d - r, r)
    else unpairStep (d + 1) (r - (d + 1))

def unpairNat (s : Nat) : Nat × Nat :=
  unpairStep 0 s

theorem unpairStep_tri (d k : Nat) :
    unpairStep 0 (d * (d + 1) / 2 + k) = unpairStep d k := by
  induction d generalizing k with
  | zero => simp only [Nat.zero_mul, Nat.zero_div, Nat.zero_add]
  | succ d ih =>
    have htri : (d + 1) * (d + 2) / 2 = d * (d + 1) / 2 + (d + 1) := by
      have hmul : (d + 1) * (d + 2) = d * (d + 1) + 2 * (d + 1) := by
        rw [Nat.mul_add (d + 1) d 2, Nat.mul_comm (d + 1) d, Nat.mul_comm (d + 1) 2]
      rw [hmul, Nat.add_mul_div_left _ _ (by omega)]
    rw [htri, Nat.add_assoc, ih (d + 1 + k)]
    have hnot : ¬ (d + 1 + k ≤ d) := by omega
    rw [unpairStep.eq_1]
    simp only [hnot, ↓reduceIte]
    have hsub : d + 1 + k - (d + 1) = k := by omega
    rw [hsub]

theorem unpairNat_pairNat (i k : Nat) : unpairNat (pairNat i k) = (i, k) := by
  unfold unpairNat pairNat
  rw [unpairStep_tri (i + k) k]
  unfold unpairStep
  have hle : k ≤ i + k := by omega
  simp only [hle, ↓reduceIte]
  have hsub : i + k - k = i := by omega
  rw [hsub]

/-! ### 4. Layer-by-layer oracle construction (`fillLayer`, `fillRange`, `stepStage`) -/

def fillLayer (K : LocalKernel) (Q : List Word) (m : Nat) (A : Oracle) : Oracle :=
  if m = 0 then A
  else if m % 2 = 0 then
    let r := m / 2
    fun w =>
      if w.length = m then
        let x := w.take r
        let y := w.drop r
        if y = pickRowSlot x r Q then K.eval A x else false
      else A w
  else
    A

def fillRange (K : LocalKernel) (Q : List Word) (lo : Nat) : Nat → Oracle → Oracle
  | 0, A => A
  | steps + 1, A => fillLayer K Q (lo + steps) (fillRange K Q lo steps A)

theorem fillLayer_preserves_ne (K : LocalKernel) (Q : List Word) (m : Nat) (A : Oracle)
    (w : Word) (hne : w.length ≠ m) :
    fillLayer K Q m A w = A w := by
  unfold fillLayer
  if hm0 : m = 0 then
    simp only [hm0, ↓reduceIte]
  else
    simp only [hm0, ↓reduceIte]
    if hmev : m % 2 = 0 then
      simp only [hmev, ↓reduceIte, hne]
    else
      simp only [hmev, ↓reduceIte]

theorem fillRange_preserves_lt (K : LocalKernel) (Q : List Word) (lo steps : Nat) (A : Oracle)
    (w : Word) (hlt : w.length < lo) :
    fillRange K Q lo steps A w = A w := by
  induction steps with
  | zero => rfl
  | succ steps ih =>
    simp only [fillRange]
    rw [fillLayer_preserves_ne K Q (lo + steps) _ w (by omega), ih]

theorem fillRange_preserves_ge (K : LocalKernel) (Q : List Word) (lo steps : Nat) (A : Oracle)
    (w : Word) (hge : lo + steps ≤ w.length) :
    fillRange K Q lo steps A w = A w := by
  induction steps with
  | zero => rfl
  | succ steps ih =>
    simp only [fillRange]
    rw [fillLayer_preserves_ne K Q (lo + steps) _ w (by omega)]
    exact ih (by omega)

theorem fillLayer_preserves_queries (K : LocalKernel) (Q : List Word) (m : Nat) (A : Oracle)
    (hQ : m % 2 = 0 → m ≠ 0 → Q.length < 2 ^ (m / 2))
    (hzero : ∀ q ∈ Q, q.length = m → A q = false) :
    ∀ q ∈ Q, fillLayer K Q m A q = A q := by
  intro q hq
  if hlen : q.length = m then
    unfold fillLayer
    if hm0 : m = 0 then
      simp only [hm0, ↓reduceIte]
    else
      simp only [hm0, ↓reduceIte]
      if hmev : m % 2 = 0 then
        simp only [hmev, ↓reduceIte, hlen]
        have hlt : Q.length < 2 ^ (m / 2) := hQ hmev hm0
        have hspec := pickRowSlot_spec (q.take (m / 2)) (m / 2) Q hlt
        have hne_slot : q.drop (m / 2) ≠ pickRowSlot (q.take (m / 2)) (m / 2) Q := by
          intro heq
          have hcat : q.take (m / 2) ++ pickRowSlot (q.take (m / 2)) (m / 2) Q = q := by
            rw [← heq, List.take_append_drop]
          rw [← hcat] at hq; exact hspec.2 hq
        simp only [hne_slot, ↓reduceIte]
        exact (hzero q hq hlen).symm
      else
        simp only [hmev, ↓reduceIte]
  else
    exact fillLayer_preserves_ne K Q m A q hlen

theorem fillRange_preserves_queries (K : LocalKernel) (Q : List Word) (lo steps : Nat) (A : Oracle)
    (hQ : ∀ m, lo ≤ m → m < lo + steps → m % 2 = 0 → m ≠ 0 → Q.length < 2 ^ (m / 2))
    (hzero : ∀ q ∈ Q, lo ≤ q.length → q.length < lo + steps → A q = false) :
    ∀ q ∈ Q, fillRange K Q lo steps A q = A q := by
  induction steps with
  | zero => intro q _; rfl
  | succ steps ih =>
    intro q hq
    simp only [fillRange]
    have hih : ∀ q' ∈ Q, fillRange K Q lo steps A q' = A q' :=
      ih (fun m h1 h2 => hQ m h1 (by omega)) (fun q' hq' h1 h2 => hzero q' hq' h1 (by omega))
    have hlayer := fillLayer_preserves_queries K Q (lo + steps) (fillRange K Q lo steps A)
      (fun hev hne => hQ (lo + steps) (by omega) (by omega) hev hne)
      (fun q' hq' hlen => by
        rw [fillRange_preserves_ge K Q lo steps A q' (by omega)]
        exact hzero q' hq' (by omega) (by omega))
      q hq
    rw [hlayer, hih q hq]

/-! ### 5. Stage state, global invariants GI_1 / GI_2 / GI_3, and diagonalization -/

structure StageState where
  bound : Nat
  oracle : Oracle

def diagBit (A : Oracle) (n : Nat) : Bool :=
  (allWordsD n).any A

theorem diagBit_true_iff (A : Oracle) (n : Nat) :
    diagBit A n = true ↔ ∃ y : Word, y.length = n ∧ A y = true := by
  unfold diagBit
  rw [List.any_eq_true]
  constructor
  · rintro ⟨y, hymem, hAy⟩
    exact ⟨y, (mem_allWordsD n y).mp hymem, hAy⟩
  · rintro ⟨y, hylen, hAy⟩
    exact ⟨y, (mem_allWordsD n y).mpr hylen, hAy⟩

def stepStage (M : OracleMachineModel) (K : LocalKernel) (s : Nat) (st : StageState) : StageState :=
  let (i, k) := unpairNat s
  let B := st.bound
  let n := chooseDiagLen B k
  let pre := fillRange K [] (B + 1) (n - (B + 1)) st.oracle
  let run := M.runD i (clock k n) pre (List.replicate n true)
  let yStar := pickWord n run.queries
  let diagOracle : Oracle := fun w => if w = yStar then !run.answer else pre w
  let B' := max n (clock k n) + 1
  let post := fillRange K run.queries (n + 1) (B' - n) diagOracle
  ⟨B', post⟩

def stageState (M : OracleMachineModel) (K : LocalKernel) : Nat → StageState
  | 0 => ⟨0, fun _ => false⟩
  | s + 1 => stepStage M K s (stageState M K s)

def globalOracle (M : OracleMachineModel) (K : LocalKernel) (w : Word) : Bool :=
  (stageState M K w.length).oracle w

/-! ### 6. Monotonicity (`GI_3`) and zero-above-bound invariant -/

theorem stepStage_bound_gt (M : OracleMachineModel) (K : LocalKernel) (s : Nat) (st : StageState) :
    st.bound < (stepStage M K s st).bound := by
  unfold stepStage
  dsimp only
  have hgt := chooseDiagLen_gt st.bound (unpairNat s).2
  have hle : chooseDiagLen st.bound (unpairNat s).2 ≤
      max (chooseDiagLen st.bound (unpairNat s).2) (clock (unpairNat s).2 (chooseDiagLen st.bound (unpairNat s).2)) :=
    Nat.le_max_left _ _
  omega

theorem stageState_bound_ge (M : OracleMachineModel) (K : LocalKernel) (s : Nat) :
    s ≤ (stageState M K s).bound := by
  induction s with
  | zero => exact Nat.zero_le _
  | succ s ih =>
    have hgt := stepStage_bound_gt M K s (stageState M K s)
    simp only [stageState]
    omega

theorem stepStage_preserves_le (M : OracleMachineModel) (K : LocalKernel) (s : Nat) (st : StageState)
    (w : Word) (hle : w.length ≤ st.bound) :
    (stepStage M K s st).oracle w = st.oracle w := by
  unfold stepStage
  dsimp only
  let k := (unpairNat s).2
  let n := chooseDiagLen st.bound k
  have hgt : st.bound < n := chooseDiagLen_gt st.bound k
  have hlt_post : w.length < n + 1 := by omega
  rw [fillRange_preserves_lt K _ (n + 1) _ _ w hlt_post]
  have hQlt : (M.runD (unpairNat s).1 (clock k n)
      (fillRange K [] (st.bound + 1) (n - (st.bound + 1)) st.oracle)
      (List.replicate n true)).queries.length < 2 ^ n := by
    have hc := M.d_count (unpairNat s).1 (clock k n)
      (fillRange K [] (st.bound + 1) (n - (st.bound + 1)) st.oracle) (List.replicate n true)
    have hcl : clock k n < 2 ^ (n / 2) := chooseDiagLen_clock_lt st.bound k
    have hpow : 2 ^ (n / 2) ≤ 2 ^ n := Nat.pow_le_pow_right (by omega) (by omega)
    omega
  have hys := (pickWord_spec n (M.runD (unpairNat s).1 (clock k n)
      (fillRange K [] (st.bound + 1) (n - (st.bound + 1)) st.oracle)
      (List.replicate n true)).queries hQlt).1
  have hne : w ≠ pickWord n (M.runD (unpairNat s).1 (clock k n)
      (fillRange K [] (st.bound + 1) (n - (st.bound + 1)) st.oracle)
      (List.replicate n true)).queries := by
    intro heq
    rw [heq, hys] at hle
    omega
  dsimp only [n, k] at hne
  simp only [hne, ↓reduceIte]
  exact fillRange_preserves_lt K [] (st.bound + 1) _ st.oracle w (by omega)

theorem stage_monotone (M : OracleMachineModel) (K : LocalKernel) {s1 s2 : Nat} (hle : s1 ≤ s2) :
    ∀ w : Word, w.length ≤ (stageState M K s1).bound →
      (stageState M K s2).oracle w = (stageState M K s1).oracle w := by
  induction hle with
  | refl => intro _ _; rfl
  | step h ih =>
    rename_i m
    intro w hw
    have hbm : (stageState M K s1).bound ≤ (stageState M K m).bound := by
      clear ih hw
      induction h with
      | refl => exact Nat.le_refl _
      | @step m' _ ihb =>
        have hgt := stepStage_bound_gt M K m' (stageState M K m')
        simp only [stageState]
        omega
    simp only [stageState]
    rw [stepStage_preserves_le M K m (stageState M K m) w (Nat.le_trans hw hbm)]
    exact ih w hw

theorem globalOracle_agrees_stage (M : OracleMachineModel) (K : LocalKernel) (s : Nat)
    (w : Word) (hw : w.length ≤ (stageState M K s).bound) :
    globalOracle M K w = (stageState M K s).oracle w := by
  unfold globalOracle
  if hle : w.length ≤ s then
    have hbw : w.length ≤ (stageState M K w.length).bound := stageState_bound_ge M K w.length
    exact (stage_monotone M K hle w hbw).symm
  else
    exact stage_monotone M K (by omega) w hw

theorem stepStage_zero_above (M : OracleMachineModel) (K : LocalKernel) (s : Nat) (st : StageState)
    (hzero : ∀ w : Word, st.bound < w.length → st.oracle w = false) :
    ∀ w : Word, (stepStage M K s st).bound < w.length → (stepStage M K s st).oracle w = false := by
  intro w hw
  unfold stepStage at hw ⊢
  dsimp only at hw ⊢
  let k := (unpairNat s).2
  let n := chooseDiagLen st.bound k
  let B' := max n (clock k n) + 1
  have hw' : B' < w.length := hw
  have hgt : st.bound < n := chooseDiagLen_gt st.bound k
  have hB' : n < B' := by
    have : n ≤ max n (clock k n) := Nat.le_max_left _ _
    omega
  have hge_post : n + 1 + (B' - n) ≤ w.length := by omega
  rw [fillRange_preserves_ge K _ (n + 1) (B' - n) _ w hge_post]
  have hQlt : (M.runD (unpairNat s).1 (clock k n)
      (fillRange K [] (st.bound + 1) (n - (st.bound + 1)) st.oracle)
      (List.replicate n true)).queries.length < 2 ^ n := by
    have hc := M.d_count (unpairNat s).1 (clock k n)
      (fillRange K [] (st.bound + 1) (n - (st.bound + 1)) st.oracle) (List.replicate n true)
    have hcl : clock k n < 2 ^ (n / 2) := chooseDiagLen_clock_lt st.bound k
    have hpow : 2 ^ (n / 2) ≤ 2 ^ n := Nat.pow_le_pow_right (by omega) (by omega)
    omega
  have hys := (pickWord_spec n (M.runD (unpairNat s).1 (clock k n)
      (fillRange K [] (st.bound + 1) (n - (st.bound + 1)) st.oracle)
      (List.replicate n true)).queries hQlt).1
  have hne : w ≠ pickWord n (M.runD (unpairNat s).1 (clock k n)
      (fillRange K [] (st.bound + 1) (n - (st.bound + 1)) st.oracle)
      (List.replicate n true)).queries := by
    intro heq
    rw [heq, hys] at hw'
    omega
  dsimp only [n, k] at hne
  simp only [hne, ↓reduceIte]
  rw [fillRange_preserves_ge K [] (st.bound + 1) (n - (st.bound + 1)) st.oracle w (by omega)]
  exact hzero w (by omega)

theorem stageState_zero_above (M : OracleMachineModel) (K : LocalKernel) (s : Nat) :
    ∀ w : Word, (stageState M K s).bound < w.length → (stageState M K s).oracle w = false := by
  induction s with
  | zero => intro _ _; rfl
  | succ s ih => exact stepStage_zero_above M K s (stageState M K s) ih

/-! ### 7. Proof of `GI_1` (even-length unique witness) and `GI_2` (odd-length ≤ 1) -/

def HasGI1 (K : LocalKernel) (B : Nat) (A : Oracle) : Prop :=
  ∀ r : Nat, 1 ≤ r → 2 * r ≤ B → ∀ x : Word, x.length = r →
    ∃ yStar : Word, yStar.length = r ∧
      ∀ y : Word, y.length = r → (A (x ++ y) = true ↔ K.eval A x = true ∧ y = yStar)

def HasGI2 (B : Nat) (A : Oracle) : Prop :=
  ∀ r : Nat, 2 * r + 1 ≤ B → ∀ y1 y2 : Word,
    y1.length = 2 * r + 1 → y2.length = 2 * r + 1 →
    A y1 = true → A y2 = true → y1 = y2

theorem fillLayer_preserves_GI1 (K : LocalKernel) (Q : List Word) (m : Nat) (A : Oracle)
    (hprev : HasGI1 K (m - 1) A)
    (hQ : m % 2 = 0 → m ≠ 0 → Q.length < 2 ^ (m / 2)) :
    HasGI1 K m (fillLayer K Q m A) := by
  intro r hr1 h2r x hx
  if hlt : 2 * r ≤ m - 1 then
    rcases hprev r hr1 hlt x hx with ⟨yStar, hyStar, hspec⟩
    refine ⟨yStar, hyStar, ?_⟩
    intro y hy
    have hlen : (x ++ y).length ≠ m := by simp only [List.length_append, hx, hy]; omega
    rw [fillLayer_preserves_ne K Q m A (x ++ y) hlen]
    have hK : K.eval (fillLayer K Q m A) x = K.eval A x :=
      K.local_dep r _ A (fun q hq => fillLayer_preserves_ne K Q m A q (by omega)) x hx
    rw [hK]
    exact hspec y hy
  else
    have hm_eq : 2 * r = m := by omega
    have hm0 : m ≠ 0 := by omega
    have hmev : m % 2 = 0 := by omega
    have hdiv : m / 2 = r := by omega
    have hQlt : Q.length < 2 ^ r := by rw [← hdiv]; exact hQ hmev hm0
    have hslot := pickRowSlot_spec x r Q hQlt
    refine ⟨pickRowSlot x r Q, hslot.1, ?_⟩
    intro y hy
    have hK : K.eval (fillLayer K Q m A) x = K.eval A x :=
      K.local_dep r _ A (fun q hq => fillLayer_preserves_ne K Q m A q (by omega)) x hx
    rw [hK]
    unfold fillLayer
    simp only [hm0, hmev, ↓reduceIte]
    have hlen : (x ++ y).length = m := by simp only [List.length_append, hx, hy]; omega
    simp only [hlen, ↓reduceIte, hdiv]
    have htake : (x ++ y).take r = x := by rw [← hx, List.take_left]
    have hdrop : (x ++ y).drop r = y := by rw [← hx, List.drop_left]
    rw [htake, hdrop]
    if heq : y = pickRowSlot x r Q then
      simp only [heq, ↓reduceIte, and_true]
    else
      simp only [heq, ↓reduceIte, and_false, Bool.false_eq_true]

theorem fillRange_preserves_GI1 (K : LocalKernel) (Q : List Word) (lo steps : Nat) (A : Oracle)
    (hlo : 1 ≤ lo)
    (hprev : HasGI1 K (lo - 1) A)
    (hQ : ∀ m, lo ≤ m → m < lo + steps → m % 2 = 0 → m ≠ 0 → Q.length < 2 ^ (m / 2)) :
    HasGI1 K (lo + steps - 1) (fillRange K Q lo steps A) := by
  induction steps with
  | zero =>
    simpa only [Nat.add_zero, fillRange] using hprev
  | succ steps ih =>
    simp only [fillRange]
    have heq1 : lo + (steps + 1) - 1 = lo + steps := by omega
    rw [heq1]
    have hih : HasGI1 K (lo + steps - 1) (fillRange K Q lo steps A) :=
      ih (fun m h1 h2 => hQ m h1 (by omega))
    exact fillLayer_preserves_GI1 K Q (lo + steps) (fillRange K Q lo steps A) hih
      (fun hev hne => hQ (lo + steps) (by omega) (by omega) hev hne)

theorem fillRange_preserves_GI2 (K : LocalKernel) (Q : List Word) (lo steps : Nat) (A : Oracle)
    (hB : HasGI2 (lo - 1) A)
    (hzero : ∀ w : Word, lo ≤ w.length → w.length < lo + steps → w.length % 2 = 1 → A w = false) :
    HasGI2 (lo + steps - 1) (fillRange K Q lo steps A) := by
  intro r h2r y1 y2 hy1 hy2 ha1 ha2
  if hlt : 2 * r + 1 ≤ lo - 1 then
    rw [fillRange_preserves_lt K Q lo steps A y1 (by omega)] at ha1
    rw [fillRange_preserves_lt K Q lo steps A y2 (by omega)] at ha2
    exact hB r hlt y1 y2 hy1 hy2 ha1 ha2
  else
    have hodd_pres : ∀ (st : Nat) (w : Word), w.length % 2 = 1 → fillRange K Q lo st A w = A w := by
      intro st w hodd
      induction st with
      | zero => rfl
      | succ st ihst =>
        simp only [fillRange]
        unfold fillLayer
        if hm0 : lo + st = 0 then
          simp only [hm0, ↓reduceIte]; exact ihst
        else
          simp only [hm0, ↓reduceIte]
          if hmev : (lo + st) % 2 = 0 then
            have hne : w.length ≠ lo + st := by omega
            simp only [hmev, hne, ↓reduceIte]; exact ihst
          else
            simp only [hmev, ↓reduceIte]; exact ihst
    rw [hodd_pres steps y1 (by omega)] at ha1
    have hf := hzero y1 (by omega) (by omega) (by omega)
    rw [hf] at ha1
    cases ha1

theorem stageState_invariants (M : OracleMachineModel) (K : LocalKernel) (s : Nat) :
    HasGI1 K (stageState M K s).bound (stageState M K s).oracle ∧
    HasGI2 (stageState M K s).bound (stageState M K s).oracle := by
  induction s with
  | zero =>
    constructor
    · intro r hr1 h2r
      simp only [stageState] at h2r
      exfalso; omega
    · intro r h2r
      simp only [stageState] at h2r
      exfalso; omega
  | succ s ih =>
    rcases ih with ⟨hGI1, hGI2⟩
    let st := stageState M K s
    have hzero_st := stageState_zero_above M K s
    simp only [stageState]
    unfold stepStage
    dsimp only
    let i := (unpairNat s).1
    let k := (unpairNat s).2
    let B := st.bound
    let n := chooseDiagLen B k
    let pre := fillRange K [] (B + 1) (n - (B + 1)) st.oracle
    let run := M.runD i (clock k n) pre (List.replicate n true)
    let yStar := pickWord n run.queries
    let diagOracle : Oracle := fun w => if w = yStar then !run.answer else pre w
    let B' := max n (clock k n) + 1
    let post := fillRange K run.queries (n + 1) (B' - n) diagOracle
    have hgt : B < n := chooseDiagLen_gt B k
    have hodd : n % 2 = 1 := chooseDiagLen_odd B k
    have hB' : n < B' := by
      have : n ≤ max n (clock k n) := Nat.le_max_left _ _
      omega
    have hzero_B : ∀ w : Word, B < w.length → st.oracle w = false := hzero_st
    have hQlt_half : run.queries.length < 2 ^ (n / 2) := by
      have hc : run.queries.length ≤ clock k n := M.d_count i (clock k n) pre (List.replicate n true)
      have hcl : clock k n < 2 ^ (n / 2) := chooseDiagLen_clock_lt B k
      omega
    have hQlt_n : run.queries.length < 2 ^ n := by
      have hpow : 2 ^ (n / 2) ≤ 2 ^ n := Nat.pow_le_pow_right (by omega) (by omega)
      omega
    have hys_len : yStar.length = n := (pickWord_spec n run.queries hQlt_n).1
    -- Pre-fill GI1 up to n - 1
    have hpre_GI1 : HasGI1 K (n - 1) pre := by
      have h := fillRange_preserves_GI1 K [] (B + 1) (n - (B + 1)) st.oracle (by omega)
        (by simpa only [Nat.add_sub_cancel] using hGI1)
        (fun m _ _ _ _ => by simp only [List.length_nil]; exact Nat.pow_pos (by omega))
      have heq : B + 1 + (n - (B + 1)) - 1 = n - 1 := by omega
      rw [heq] at h
      exact h
    -- diagOracle preserves GI1 up to n (since n is odd, no even 2*r = n)
    have hdiag_GI1 : HasGI1 K n diagOracle := by
      intro r hr1 h2r x hx
      have hlt : 2 * r ≤ n - 1 := by omega
      rcases hpre_GI1 r hr1 hlt x hx with ⟨y0, hy0, hspec⟩
      refine ⟨y0, hy0, ?_⟩
      intro y hy
      have hne_ys : x ++ y ≠ yStar := by
        intro heq
        have hl : (x ++ y).length = yStar.length := congrArg List.length heq
        simp only [List.length_append, hx, hy, hys_len] at hl
        omega
      have hK : K.eval diagOracle x = K.eval pre x := by
        refine K.local_dep r diagOracle pre ?_ x hx
        intro q hq
        have hqne : q ≠ yStar := by
          intro heq; rw [heq, hys_len] at hq; omega
        simp only [diagOracle, hqne, ↓reduceIte]
      simp only [diagOracle, hne_ys, ↓reduceIte, hK]
      exact hspec y hy
    -- Post-fill GI1 up to B'
    have hpost_GI1 : HasGI1 K B' post := by
      have h := fillRange_preserves_GI1 K run.queries (n + 1) (B' - n) diagOracle (by omega)
        (by simpa only [Nat.add_sub_cancel] using hdiag_GI1)
        (fun m hm1 _ hmev _ => by
          have hdiv : n / 2 < m / 2 := by omega
          have hpow : 2 ^ (n / 2) ≤ 2 ^ (m / 2) := Nat.pow_le_pow_right (by omega) (by omega)
          omega)
      have heq : n + 1 + (B' - n) - 1 = B' := by omega
      rw [heq] at h
      exact h
    -- Pre-fill GI2 up to n - 1
    have hpre_GI2 : HasGI2 (n - 1) pre := by
      have h := fillRange_preserves_GI2 K [] (B + 1) (n - (B + 1)) st.oracle
        (by simpa only [Nat.add_sub_cancel] using hGI2)
        (fun w hw1 _ _ => hzero_B w (by omega))
      have heq : B + 1 + (n - (B + 1)) - 1 = n - 1 := by omega
      rw [heq] at h
      exact h
    -- diagOracle GI2 up to n
    have hdiag_GI2 : HasGI2 n diagOracle := by
      intro r h2r y1 y2 hy1 hy2 ha1 ha2
      if hlt : 2 * r + 1 ≤ n - 1 then
        have hne1 : y1 ≠ yStar := by intro heq; rw [heq, hys_len] at hy1; omega
        have hne2 : y2 ≠ yStar := by intro heq; rw [heq, hys_len] at hy2; omega
        simp only [diagOracle, hne1, hne2, ↓reduceIte] at ha1 ha2
        exact hpre_GI2 r hlt y1 y2 hy1 hy2 ha1 ha2
      else
        have hpre0 : ∀ w : Word, w.length = n → pre w = false := by
          intro w hw
          dsimp only [pre]
          rw [fillRange_preserves_ge K [] (B + 1) (n - (B + 1)) st.oracle w (by omega)]
          exact hzero_B w (by omega)
        have heq1 : y1 = yStar := by
          if h1 : y1 = yStar then exact h1
          else
            simp only [diagOracle, h1, ↓reduceIte] at ha1
            rw [hpre0 y1 (by omega)] at ha1
            cases ha1
        have heq2 : y2 = yStar := by
          if h2 : y2 = yStar then exact h2
          else
            simp only [diagOracle, h2, ↓reduceIte] at ha2
            rw [hpre0 y2 (by omega)] at ha2
            cases ha2
        rw [heq1, heq2]
    -- Post-fill GI2 up to B'
    have hpost_GI2 : HasGI2 B' post := by
      have h := fillRange_preserves_GI2 K run.queries (n + 1) (B' - n) diagOracle
        (by simpa only [Nat.add_sub_cancel] using hdiag_GI2)
        (fun w hw1 _ _ => by
          have hne : w ≠ yStar := by intro heq; rw [heq, hys_len] at hw1; omega
          simp only [diagOracle, hne, ↓reduceIte]
          dsimp only [pre]
          rw [fillRange_preserves_ge K [] (B + 1) (n - (B + 1)) st.oracle w (by omega)]
          exact hzero_B w (by omega))
      have heq : n + 1 + (B' - n) - 1 = B' := by omega
      rw [heq] at h
      exact h
    exact ⟨hpost_GI1, hpost_GI2⟩

/-! ### 8. Root Theorems on `globalOracle` -/

theorem globalOracle_GI1 (M : OracleMachineModel) (K : LocalKernel) :
    ∀ r : Nat, 1 ≤ r → ∀ x : Word, x.length = r →
      ∃ yStar : Word, yStar.length = r ∧
        ∀ y : Word, y.length = r →
          (globalOracle M K (x ++ y) = true ↔ K.eval (globalOracle M K) x = true ∧ y = yStar) := by
  intro r hr1 x hx
  let s := 2 * r
  have hbs : 2 * r ≤ (stageState M K s).bound := stageState_bound_ge M K s
  rcases (stageState_invariants M K s).1 r hr1 hbs x hx with ⟨yStar, hyStar, hspec⟩
  refine ⟨yStar, hyStar, ?_⟩
  intro y hy
  have hxy : (x ++ y).length ≤ (stageState M K s).bound := by
    simp only [List.length_append, hx, hy]; omega
  rw [globalOracle_agrees_stage M K s (x ++ y) hxy]
  have hK : K.eval (globalOracle M K) x = K.eval (stageState M K s).oracle x :=
    K.local_dep r _ _ (fun q hq => globalOracle_agrees_stage M K s q (by omega)) x hx
  rw [hK]
  exact hspec y hy

theorem globalOracle_GI2 (M : OracleMachineModel) (K : LocalKernel) :
    ∀ r : Nat, ∀ y1 y2 : Word,
      y1.length = 2 * r + 1 → y2.length = 2 * r + 1 →
      globalOracle M K y1 = true → globalOracle M K y2 = true → y1 = y2 := by
  intro r y1 y2 hy1 hy2 ha1 ha2
  let s := 2 * r + 1
  have hbs : 2 * r + 1 ≤ (stageState M K s).bound := stageState_bound_ge M K s
  rw [globalOracle_agrees_stage M K s y1 (by omega)] at ha1
  rw [globalOracle_agrees_stage M K s y2 (by omega)] at ha2
  exact (stageState_invariants M K s).2 r hbs y1 y2 hy1 hy2 ha1 ha2

theorem globalOracle_defeats_all_P (M : OracleMachineModel) (K : LocalKernel) :
    ∀ (i k : Nat), ∃ n : Nat, n % 2 = 1 ∧
      (M.runD i (clock k n) (globalOracle M K) (List.replicate n true)).answer ≠
        diagBit (globalOracle M K) n := by
  intro i k
  let s := pairNat i k
  let st := stageState M K s
  let B := st.bound
  let n := chooseDiagLen B k
  have hunp : unpairNat s = (i, k) := unpairNat_pairNat i k
  have hgt : B < n := chooseDiagLen_gt B k
  have hodd : n % 2 = 1 := chooseDiagLen_odd B k
  refine ⟨n, hodd, ?_⟩
  let pre := fillRange K [] (B + 1) (n - (B + 1)) st.oracle
  let run := M.runD i (clock k n) pre (List.replicate n true)
  let yStar := pickWord n run.queries
  let diagOracle : Oracle := fun w => if w = yStar then !run.answer else pre w
  let B' := max n (clock k n) + 1
  let post := fillRange K run.queries (n + 1) (B' - n) diagOracle
  have hB'_eq : (stageState M K (s + 1)).bound = B' := by
    simp only [stageState, stepStage, hunp]; rfl
  have hpost_eq : (stageState M K (s + 1)).oracle = post := by
    simp only [stageState, stepStage, hunp]; rfl
  have hzero_B : ∀ w : Word, B < w.length → st.oracle w = false := stageState_zero_above M K s
  have hQlt_half : run.queries.length < 2 ^ (n / 2) := by
    have hc : run.queries.length ≤ clock k n := M.d_count i (clock k n) pre (List.replicate n true)
    have hcl : clock k n < 2 ^ (n / 2) := chooseDiagLen_clock_lt B k
    omega
  have hQlt_n : run.queries.length < 2 ^ n := by
    have hpow : 2 ^ (n / 2) ≤ 2 ^ n := Nat.pow_le_pow_right (by omega) (by omega)
    omega
  have hys : yStar.length = n ∧ yStar ∉ run.queries := pickWord_spec n run.queries hQlt_n
  -- 1. globalOracle agrees with pre on all queries of run
  have hreplay : M.runD i (clock k n) (globalOracle M K) (List.replicate n true) = run := by
    symm
    refine M.d_replay i (clock k n) pre (globalOracle M K) (List.replicate n true) ?_
    intro q hq
    have hqlen : q.length ≤ clock k n := M.d_length i (clock k n) pre (List.replicate n true) q hq
    have hqB' : q.length ≤ (stageState M K (s + 1)).bound := by
      rw [hB'_eq]
      have : clock k n ≤ max n (clock k n) := Nat.le_max_right _ _
      omega
    rw [globalOracle_agrees_stage M K (s + 1) q hqB', hpost_eq]
    have hpost_q : post q = diagOracle q := by
      refine fillRange_preserves_queries K run.queries (n + 1) (B' - n) diagOracle ?_ ?_ q hq
      · intro m hm1 _ hmev _
        have hdiv : n / 2 < m / 2 := by omega
        have hpow : 2 ^ (n / 2) ≤ 2 ^ (m / 2) := Nat.pow_le_pow_right (by omega) (by omega)
        omega
      · intro q' _ hq1 _
        have hne : q' ≠ yStar := by intro heq; rw [heq, hys.1] at hq1; omega
        simp only [diagOracle, hne, ↓reduceIte]
        dsimp only [pre]
        rw [fillRange_preserves_ge K [] (B + 1) (n - (B + 1)) st.oracle q' (by omega)]
        exact hzero_B q' (by omega)
    rw [hpost_q]
    have hne_ys : q ≠ yStar := by
      intro heq
      rw [heq] at hq
      exact hys.2 hq
    simp only [diagOracle, hne_ys, ↓reduceIte]
  -- 2. diagBit (globalOracle M K) n = !run.answer
  have hdiag : diagBit (globalOracle M K) n = !run.answer := by
    have hB'n : n ≤ (stageState M K (s + 1)).bound := by
      rw [hB'_eq]
      have : n ≤ max n (clock k n) := Nat.le_max_left _ _
      omega
    have hval : ∀ y : Word, y.length = n → globalOracle M K y = if y = yStar then !run.answer else false := by
      intro y hy
      rw [globalOracle_agrees_stage M K (s + 1) y (by omega), hpost_eq]
      dsimp only [post]
      rw [fillRange_preserves_lt K run.queries (n + 1) (B' - n) diagOracle y (by omega)]
      if heq : y = yStar then
        simp only [diagOracle, heq, ↓reduceIte]
      else
        simp only [diagOracle, heq, ↓reduceIte]
        dsimp only [pre]
        rw [fillRange_preserves_ge K [] (B + 1) (n - (B + 1)) st.oracle y (by omega)]
        exact hzero_B y (by omega)
    cases hdb : diagBit (globalOracle M K) n
    · cases hra : run.answer
      · exfalso
        have ht : diagBit (globalOracle M K) n = true := by
          rw [diagBit_true_iff]
          refine ⟨yStar, hys.1, ?_⟩
          rw [hval yStar hys.1]
          simp only [↓reduceIte, hra, Bool.not_false]
        rw [hdb] at ht
        cases ht
      · rfl
    · rcases (diagBit_true_iff (globalOracle M K) n).mp hdb with ⟨y, hylen, hAy⟩
      rw [hval y hylen] at hAy
      if heq : y = yStar then
        simp only [heq, ↓reduceIte] at hAy
        exact hAy.symm
      else
        simp only [heq, ↓reduceIte] at hAy
        cases hAy
  rw [hreplay, hdiag]
  cases run.answer <;> decide

end MultilinearW10
