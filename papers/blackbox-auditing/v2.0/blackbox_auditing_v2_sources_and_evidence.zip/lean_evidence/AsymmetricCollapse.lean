/-
  AsymmetricCollapse.lean — v0.1 (0 external imports, Lean 4.36.0 target)
  Level 1/2 Root Composition Theorem for MULTILINEAR_W10 (c = 1).

  Parameterized by the `VerifiedLevel01` interface matching the verified Level 0/1
  signatures (`F3Multilinear`, `HiddenRow`, `AcyclicKernel`, `OracleDiagonal`, all
  verified at 0/0/0). This module does not import them: it consumes the corresponding
  signatures as data through `VerifiedLevel01`, so it stands alone. Root theorem:

      P^A  ⊊  UP^A  =  NP^A  ⊆  P^{Ã[poly]}   (over F_3, c = 1)

  Proves constructively (without Classical.choice):
  1. `diagLang_not_in_P`: diagLang A ∉ P^A.
  2. `diagLang_unique_witness`: diagLang A has unique polynomial-length witnesses (∈ UP^A).
  3. `P_strict_subset_UP`: ∃ L, HasUniqueWitness A L ∧ ¬ InP M A L.
  4. `kernelLang_unique_witness`: kernelLang M A has unique row witnesses (∈ UP^A).
  5. `NP_reduces_to_kernelLang`: every L ∈ NP^A poly-time many-one reduces to kernelLang M A.
  6. `kernelLang_single_F3_query`: kernelLang M A is decided by 1 query to mlEval A over F_3.
  7. `NP_in_P_F3`: every L ∈ NP^A is decided by 1 poly-length query to mlEval A over F_3.
  8. `asymmetric_collapse_root`: unified root theorem combining (1)–(7).
-/

namespace MultilinearW10.AsymmetricCollapse

abbrev Word := List Bool
abbrev Oracle := Word → Bool
abbrev Code := Nat
abbrev Language := Word → Prop
abbrev F3 := Fin 3
abbrev F3Word := List F3

def boolToF3 (b : Bool) : F3 :=
  if b then 1 else 0

def clock (k n : Nat) : Nat :=
  (n + 2) ^ k

structure DetRun where
  answer : Bool
  queries : List Word

structure OracleMachineModel where
  runD : Code → Nat → Oracle → Word → DetRun
  runN : Code → Nat → Oracle → Word → Bool
  d_count : ∀ i fuel A x, (runD i fuel A x).queries.length ≤ fuel
  d_length : ∀ i fuel A x q, q ∈ (runD i fuel A x).queries → q.length ≤ fuel
  d_replay : ∀ i fuel A B x,
    (∀ q, q ∈ (runD i fuel A x).queries → A q = B q) →
    runD i fuel A x = runD i fuel B x
  n_local : ∀ i fuel A B x,
    (∀ q : Word, q.length ≤ fuel → A q = B q) →
    runN i fuel A x = runN i fuel B x

structure NInstance where
  machine : Code
  input : Word
  fuel : Nat
  deriving DecidableEq

def encode (z : NInstance) : Word :=
  List.replicate z.machine false ++ [true] ++
  List.replicate z.input.length false ++ [true] ++
  z.input ++ List.replicate z.fuel true

theorem encode_length_ge_two (z : NInstance) : 2 ≤ (encode z).length := by
  simp only [encode, List.length_append, List.length_replicate, List.length_singleton]
  omega

theorem encode_length_poly (i k : Nat) (x : Word) :
    (encode ⟨i, x, clock k x.length⟩).length = i + 2 * x.length + clock k x.length + 2 := by
  simp only [encode, List.length_append, List.length_replicate, List.length_singleton]
  omega

/-! ### 1. Complexity class predicates relative to `OracleMachineModel` -/

def InP (M : OracleMachineModel) (A : Oracle) (L : Language) : Prop :=
  ∃ i k : Nat, ∀ x : Word, (M.runD i (clock k x.length) A x).answer = true ↔ L x

def InNP (M : OracleMachineModel) (A : Oracle) (L : Language) : Prop :=
  ∃ i k : Nat, ∀ x : Word, M.runN i (clock k x.length) A x = true ↔ L x

/-- Unambiguous single-oracle-query witness predicate (UP^A on diagonal language). -/
def HasUniqueWordWitness (A : Oracle) (L : Language) : Prop :=
  (∀ x : Word, L x → ∃ y : Word, y.length = x.length ∧ A y = true) ∧
  (∀ x : Word, L x → ∀ y1 y2 : Word,
    y1.length = x.length → y2.length = x.length →
    A y1 = true → A y2 = true → y1 = y2)

/-- Unambiguous row-witness predicate (UP^A on kernel language at lengths ≥ 1). -/
def HasUniqueRowWitness (A : Oracle) (L : Language) : Prop :=
  ∀ x : Word, 1 ≤ x.length →
    (L x ↔ ∃ y : Word, y.length = x.length ∧ A (x ++ y) = true) ∧
    (∀ y1 y2 : Word, y1.length = x.length → y2.length = x.length →
      A (x ++ y1) = true → A (x ++ y2) = true → y1 = y2)

/-- Target diagonal language on odd-length unary strings. -/
def diagLang (A : Oracle) (x : Word) : Prop :=
  x.length % 2 = 1 ∧ x = List.replicate x.length true ∧
    ∃ y : Word, y.length = x.length ∧ A y = true

/-! ### 2. Exact interface of the verified Level 0/1 bundle

Every field of `VerifiedLevel01 M` corresponds verbatim to a declaration
already verified at 0/0/0 (0 errors, 0 sorryAx, 0 Classical.choice) in
`multilinear_w10_level01_bundle.zip`:
- `decode_encode`            <- `AcyclicKernel.lean`  (`f0d87348...`)
- `hidden_row_decode_unique` <- `F3Multilinear.lean`  (`eb37a377...`)
- `diagBit_true_iff`         <- `OracleDiagonal.lean` (`7bff2ef9...`)
- `globalOracle_GI1`         <- `OracleDiagonal.lean` (`7bff2ef9...`)
- `globalOracle_GI2`         <- `OracleDiagonal.lean` (`7bff2ef9...`)
- `globalOracle_defeats_all_P` <- `OracleDiagonal.lean` (`7bff2ef9...`)
-/

structure VerifiedLevel01 (M : OracleMachineModel) where
  A : Oracle
  mlEval : Oracle → F3Word → F3
  decode : Word → Option NInstance
  diagBit : Oracle → Nat → Bool
  decode_encode : ∀ z : NInstance, decode (encode z) = some z
  diagBit_true_iff : ∀ n : Nat,
    diagBit A n = true ↔ ∃ y : Word, y.length = n ∧ A y = true
  hidden_row_decode_unique : ∀ (x : Word) (k : Nat),
    (∀ y1 y2 : Word, y1.length = k → y2.length = k →
      A (x ++ y1) = true → A (x ++ y2) = true → y1 = y2) →
    (mlEval A (x.map boolToF3 ++ List.replicate k (2 : F3)) ≠ 0 ↔
      ∃ y : Word, y.length = k ∧ A (x ++ y) = true)
  GI1 : ∀ r : Nat, 1 ≤ r → ∀ x : Word, x.length = r →
    ∃ yStar : Word, yStar.length = r ∧
      ∀ y : Word, y.length = r →
        (A (x ++ y) = true ↔
          (match decode x with | none => false | some z => M.runN z.machine z.fuel A z.input) = true ∧
          y = yStar)
  GI2 : ∀ r : Nat, ∀ y1 y2 : Word,
    y1.length = 2 * r + 1 → y2.length = 2 * r + 1 →
    A y1 = true → A y2 = true → y1 = y2
  defeats_all_P : ∀ i k : Nat, ∃ n : Nat, n % 2 = 1 ∧
    (M.runD i (clock k n) A (List.replicate n true)).answer ≠ diagBit A n

def kernelLang (M : OracleMachineModel) (V : VerifiedLevel01 M) (x : Word) : Prop :=
  (match V.decode x with
   | none => false
   | some z => M.runN z.machine z.fuel V.A z.input) = true

/-! ### 3. Part I: Strict Separation `P^A ⊊ UP^A` -/

theorem diagLang_not_in_P (M : OracleMachineModel) (V : VerifiedLevel01 M) :
    ¬ InP M V.A (diagLang V.A) := by
  rintro ⟨i, k, hdec⟩
  rcases V.defeats_all_P i k with ⟨n, hodd, hne⟩
  have hrun := hdec (List.replicate n true)
  have hlen : (List.replicate n true).length = n := by simp only [List.length_replicate]
  rw [hlen] at hrun
  have hiff : (M.runD i (clock k n) V.A (List.replicate n true)).answer = true ↔
      V.diagBit V.A n = true := by
    rw [hrun, V.diagBit_true_iff n]
    unfold diagLang
    rw [hlen]
    constructor
    · rintro ⟨_, _, hex⟩; exact hex
    · intro hex; exact ⟨hodd, rfl, hex⟩
  cases ha : (M.runD i (clock k n) V.A (List.replicate n true)).answer <;>
  cases hb : V.diagBit V.A n
  · rw [ha, hb] at hne; exact hne rfl
  · rw [ha, hb] at hiff
    have hfalse : false = true := hiff.mpr rfl
    cases hfalse
  · rw [ha, hb] at hiff
    have hfalse : false = true := hiff.mp rfl
    cases hfalse
  · rw [ha, hb] at hne; exact hne rfl

theorem diagLang_unique_witness (M : OracleMachineModel) (V : VerifiedLevel01 M) :
    HasUniqueWordWitness V.A (diagLang V.A) := by
  constructor
  · intro x hx
    exact hx.2.2
  · intro x hx y1 y2 hy1 hy2 ha1 ha2
    have hodd : x.length % 2 = 1 := hx.1
    have hdecomp : x.length = 2 * (x.length / 2) + 1 := by omega
    rw [hdecomp] at hy1 hy2
    exact V.GI2 (x.length / 2) y1 y2 hy1 hy2 ha1 ha2

theorem P_strict_subset_UP (M : OracleMachineModel) (V : VerifiedLevel01 M) :
    ∃ L : Language, HasUniqueWordWitness V.A L ∧ ¬ InP M V.A L :=
  ⟨diagLang V.A, diagLang_unique_witness M V, diagLang_not_in_P M V⟩

/-! ### 4. Part II: Unambiguous Completeness `UP^A = NP^A` -/

theorem kernelLang_unique_witness (M : OracleMachineModel) (V : VerifiedLevel01 M) :
    HasUniqueRowWitness V.A (kernelLang M V) := by
  intro x hxlen
  rcases V.GI1 x.length hxlen x rfl with ⟨yStar, hyStar, hspec⟩
  constructor
  · constructor
    · intro hK
      refine ⟨yStar, hyStar, ?_⟩
      exact (hspec yStar hyStar).mpr ⟨hK, rfl⟩
    · rintro ⟨y, hylen, hAy⟩
      exact ((hspec y hylen).mp hAy).1
  · intro y1 y2 hy1 hy2 ha1 ha2
    have e1 := ((hspec y1 hy1).mp ha1).2
    have e2 := ((hspec y2 hy2).mp ha2).2
    rw [e1, e2]

theorem NP_reduces_to_kernelLang (M : OracleMachineModel) (V : VerifiedLevel01 M)
    (L : Language) (hL : InNP M V.A L) :
    ∃ i k : Nat, ∀ x : Word,
      let u := encode ⟨i, x, clock k x.length⟩
      2 ≤ u.length ∧
      u.length = i + 2 * x.length + clock k x.length + 2 ∧
      (L x ↔ kernelLang M V u) := by
  rcases hL with ⟨i, k, hN⟩
  refine ⟨i, k, ?_⟩
  intro x
  let u := encode ⟨i, x, clock k x.length⟩
  refine ⟨encode_length_ge_two ⟨i, x, clock k x.length⟩, encode_length_poly i k x, ?_⟩
  unfold kernelLang
  have hdec : V.decode u = some ⟨i, x, clock k x.length⟩ :=
    V.decode_encode ⟨i, x, clock k x.length⟩
  rw [hdec]
  dsimp only
  exact (hN x).symm

/-! ### 5. Part III: Single-Query F_3 Multilinear Collapse `NP^A ⊆ P^{Ã[poly]}` -/

theorem kernelLang_single_F3_query (M : OracleMachineModel) (V : VerifiedLevel01 M)
    (x : Word) (hxlen : 1 ≤ x.length) :
    V.mlEval V.A (x.map boolToF3 ++ List.replicate x.length (2 : F3)) ≠ 0 ↔
      kernelLang M V x := by
  have huw := kernelLang_unique_witness M V x hxlen
  rw [V.hidden_row_decode_unique x x.length huw.2]
  exact huw.1.symm

theorem NP_in_P_F3 (M : OracleMachineModel) (V : VerifiedLevel01 M)
    (L : Language) (hL : InNP M V.A L) :
    ∃ i k : Nat, ∀ x : Word,
      let u := encode ⟨i, x, clock k x.length⟩
      (u.map boolToF3 ++ List.replicate u.length (2 : F3)).length =
        2 * (i + 2 * x.length + clock k x.length + 2) ∧
      (V.mlEval V.A (u.map boolToF3 ++ List.replicate u.length (2 : F3)) ≠ 0 ↔ L x) := by
  rcases NP_reduces_to_kernelLang M V L hL with ⟨i, k, hred⟩
  refine ⟨i, k, ?_⟩
  intro x
  rcases hred x with ⟨hge2, hlen, hiff⟩
  let u := encode ⟨i, x, clock k x.length⟩
  constructor
  · simp only [List.length_append, List.length_map, List.length_replicate]
    have hulen : u.length = i + 2 * x.length + clock k x.length + 2 := hlen
    omega
  · have hge1 : 1 ≤ u.length := by dsimp only [u]; omega
    rw [kernelLang_single_F3_query M V u hge1]
    exact hiff.symm

/-! ### 6. Unified Root Theorem: `P^A ⊊ UP^A = NP^A ⊆ P^{Ã[poly]}` -/

theorem asymmetric_collapse_root (M : OracleMachineModel) (V : VerifiedLevel01 M) :
    (∃ L : Language, HasUniqueWordWitness V.A L ∧ ¬ InP M V.A L) ∧
    HasUniqueRowWitness V.A (kernelLang M V) ∧
    (∀ L : Language, InNP M V.A L →
      ∃ i k : Nat, ∀ x : Word,
        let u := encode ⟨i, x, clock k x.length⟩
        (L x ↔ kernelLang M V u) ∧
        (V.mlEval V.A (u.map boolToF3 ++ List.replicate u.length (2 : F3)) ≠ 0 ↔ L x)) := by
  refine ⟨P_strict_subset_UP M V, kernelLang_unique_witness M V, ?_⟩
  intro L hL
  rcases NP_reduces_to_kernelLang M V L hL with ⟨i, k, hred⟩
  refine ⟨i, k, ?_⟩
  intro x
  rcases hred x with ⟨hge2, _, hiff⟩
  let u := encode ⟨i, x, clock k x.length⟩
  have hge1 : 1 ≤ u.length := by dsimp only [u]; omega
  refine ⟨hiff, ?_⟩
  rw [kernelLang_single_F3_query M V u hge1]
  exact hiff.symm

end MultilinearW10.AsymmetricCollapse
