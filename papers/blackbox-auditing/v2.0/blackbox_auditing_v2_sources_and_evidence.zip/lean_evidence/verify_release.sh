#!/usr/bin/env bash
# verify_release.sh — fail-closed gate for the 6-module MULTILINEAR_W10 release.
# Each module is checked independently (they share no imports; several redeclare the
# core vocabulary in bare namespace MultilinearW10, so they are NOT concatenable).
set -uo pipefail

echo "================================================================================"
echo "FAIL-CLOSED LEAN 4.36.0 GATE — MULTILINEAR_W10 Release (6 modules)"
echo "================================================================================"
lean --version
echo ""

compile_fail=0
token_fail=0
axiom_fail=0
debug_fail=0

check_module() {
  local f="$1"; shift
  local theorems=("$@")

  echo ""
  echo "--- Module: $f ---"
  sha256sum "$f" 2>/dev/null || shasum -a 256 "$f"

  # 0. Sources must be free of debug #print lines
  local nprint
  nprint=$(grep -c '^#print' "$f" || true)
  if [ "$nprint" -ne 0 ]; then
    echo "FAIL [debug]: $f still contains $nprint #print line(s)"
    debug_fail=$((debug_fail + 1))
  fi

  # 1. Forbidden tokens, scanned in CODE ONLY (comments stripped)
  local bad_tokens
  bad_tokens=$(python3 - "$f" << 'EOF'
import re, sys
s = open(sys.argv[1], encoding="utf-8").read()
s = re.sub(r"/-.*?-/", "", s, flags=re.S)
s = re.sub(r"--.*", "", s)
print(len(re.findall(r"\b(sorry|admit|native_decide|axiom)\b", s)))
EOF
)
  if [ "$bad_tokens" -ne 0 ]; then
    echo "FAIL [token]: $f contains $bad_tokens forbidden token(s)"
    token_fail=$((token_fail + 1))
  fi

  # 2. Compile
  if ! lean "$f"; then
    echo "FAIL [compile]: $f"
    compile_fail=$((compile_fail + 1))
    return
  fi

  # 3. Axiom audit on the declared roots, via an external probe (source stays clean)
  local tmp ax_out ax_rc
  tmp=$(mktemp /tmp/ax_XXXXXX.lean)
  cat "$f" > "$tmp"
  { for thm in "${theorems[@]}"; do echo "#print axioms $thm"; done; } >> "$tmp"
  ax_out=$(lean "$tmp" 2>&1); ax_rc=$?
  rm -f "$tmp"

  echo "$ax_out" | grep -E "axioms" || true
  if [ "$ax_rc" -ne 0 ]; then
    echo "FAIL [axioms-run]: $f"
    axiom_fail=$((axiom_fail + 1)); return
  fi
  if echo "$ax_out" | grep -qE '(sorryAx|ofReduceBool|Classical\.choice)'; then
    echo "FAIL [axioms-policy]: unexpected axiom in $f"
    axiom_fail=$((axiom_fail + 1)); return
  fi
  echo "OK: $f (0 errors, 0 forbidden tokens, axiom-clean)"
}

check_module F3Multilinear.lean \
  MultilinearW10.boolean_agreement MultilinearW10.multilinear_unique \
  MultilinearW10.hidden_row_decode_sum MultilinearW10.hidden_row_decode_unique

check_module HiddenRow.lean \
  MultilinearW10.exists_unqueried_word MultilinearW10.exists_unqueried_in_row \
  MultilinearW10.pointUpdate_preserves_queries MultilinearW10.pointUpdate_row_unique \
  MultilinearW10.pointUpdate_row_at_most_one

check_module AcyclicKernel.lean \
  MultilinearW10.encode_length MultilinearW10.decode_encode \
  MultilinearW10.decode_sound MultilinearW10.decode_strict_fuel \
  MultilinearW10.kernel_local

check_module OracleDiagonal.lean \
  MultilinearW10.stage_monotone MultilinearW10.globalOracle_agrees_stage \
  MultilinearW10.globalOracle_GI1 MultilinearW10.globalOracle_GI2 \
  MultilinearW10.globalOracle_defeats_all_P

check_module AsymmetricCollapse.lean \
  MultilinearW10.AsymmetricCollapse.diagLang_not_in_P \
  MultilinearW10.AsymmetricCollapse.diagLang_unique_witness \
  MultilinearW10.AsymmetricCollapse.P_strict_subset_UP \
  MultilinearW10.AsymmetricCollapse.kernelLang_unique_witness \
  MultilinearW10.AsymmetricCollapse.NP_reduces_to_kernelLang \
  MultilinearW10.AsymmetricCollapse.kernelLang_single_F3_query \
  MultilinearW10.AsymmetricCollapse.NP_in_P_F3 \
  MultilinearW10.AsymmetricCollapse.asymmetric_collapse_root

check_module ProfileTopology.lean \
  MultilinearW10.ProfileTopology.exactly_three_valid_profiles \
  MultilinearW10.ProfileTopology.profile_01_impossible \
  MultilinearW10.ProfileTopology.profile_order_from_monotonicity \
  MultilinearW10.ProfileTopology.nowhere_continuous_profile \
  MultilinearW10.ProfileTopology.tail_no_universal_pair

echo ""
echo "================================================================================"
echo "SUMMARY: compile_fail=$compile_fail token_fail=$token_fail axiom_fail=$axiom_fail debug_fail=$debug_fail"
echo "================================================================================"

if [ "$compile_fail" -ne 0 ]; then exit 1; fi
if [ "$token_fail" -ne 0 ]; then exit 2; fi
if [ "$axiom_fail" -ne 0 ]; then exit 3; fi
if [ "$debug_fail" -ne 0 ]; then exit 4; fi
exit 0
