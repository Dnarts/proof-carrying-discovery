/-
  AcyclicKernel.lean — v0.2 (0 external imports, Lean 4.36.0 target)
  Level 0/1 (Acyclic NP-Complete Kernel) for MULTILINEAR_W10 (c = 1).

  Implements concrete `encode` and `decode` for `encode(i, w, t) = 0^i 1 0^|w| 1 w 1^t`
  and proves:
  1. `encode_length`: |(i, w, t)| = i + 2*|w| + t + 2
  2. `decode_encode`: decode (encode z) = some z (`roundtrip`)
  3. `decode_sound`: decode x = some z → encode z = x (`sound`)
  4. `decode_strict_fuel`: decode x = some z → z.fuel < x.length (`strict_fuel`)
  5. `kernel_local`: A|_{<r} = B|_{<r} → K^A_r = K^B_r
-/

namespace MultilinearW10

abbrev Word := List Bool
abbrev Oracle := Word → Bool
abbrev Code := Nat

structure NInstance where
  machine : Code
  input : Word
  fuel : Nat
  deriving DecidableEq

def encode (z : NInstance) : Word :=
  List.replicate z.machine false ++ [true] ++
  List.replicate z.input.length false ++ [true] ++
  z.input ++ List.replicate z.fuel true

def splitLeadingFalse : Word → Nat × Word
  | false :: rest =>
    let (c, tail) := splitLeadingFalse rest
    (c + 1, tail)
  | w => (0, w)

def allTrue : Word → Bool
  | [] => true
  | true :: rest => allTrue rest
  | false :: _ => false

def decode (x : Word) : Option NInstance :=
  match splitLeadingFalse x with
  | (i, true :: rest1) =>
    match splitLeadingFalse rest1 with
    | (lenW, true :: rest2) =>
      if lenW ≤ rest2.length then
        let w := rest2.take lenW
        let tail := rest2.drop lenW
        if allTrue tail then
          some ⟨i, w, tail.length⟩
        else none
      else none
    | _ => none
  | _ => none

/-! ### 1. Helper lemmas for `splitLeadingFalse` and `allTrue` -/

theorem splitLeadingFalse_replicate (n : Nat) (rest : Word) :
    splitLeadingFalse (List.replicate n false ++ true :: rest) = (n, true :: rest) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [List.replicate_succ, List.cons_append, splitLeadingFalse, ih]

theorem splitLeadingFalse_sound (w : Word) (n : Nat) (rest : Word)
    (h : splitLeadingFalse w = (n, rest)) :
    w = List.replicate n false ++ rest := by
  induction w generalizing n rest with
  | nil =>
    simp only [splitLeadingFalse, Prod.mk.injEq] at h
    rcases h with ⟨rfl, rfl⟩
    rfl
  | cons b bs ih =>
    cases b
    · simp only [splitLeadingFalse] at h
      cases hsp : splitLeadingFalse bs with
      | mk c tail =>
        rw [hsp] at h
        simp only [Prod.mk.injEq] at h
        rcases h with ⟨rfl, rfl⟩
        rw [ih c tail hsp]
        rfl
    · simp only [splitLeadingFalse, Prod.mk.injEq] at h
      rcases h with ⟨rfl, rfl⟩
      rfl

theorem allTrue_replicate (t : Nat) : allTrue (List.replicate t true) = true := by
  induction t with
  | zero => rfl
  | succ t ih => simp only [List.replicate_succ, allTrue, ih]

theorem allTrue_eq_replicate (w : Word) (h : allTrue w = true) :
    w = List.replicate w.length true := by
  induction w with
  | nil => rfl
  | cons b bs ih =>
    cases b
    · simp [allTrue] at h
    · simp only [allTrue] at h
      simp only [List.length_cons, List.replicate_succ]
      exact congrArg (true :: ·) (ih h)

/-! ### 2. `encode_length`, `roundtrip`, `sound`, and `strict_fuel` -/

theorem encode_length (z : NInstance) :
    (encode z).length = z.machine + 2 * z.input.length + z.fuel + 2 := by
  simp only [encode, List.length_append, List.length_replicate, List.length_singleton]
  omega

theorem decode_encode (z : NInstance) : decode (encode z) = some z := by
  unfold decode encode
  have h1 :
      List.replicate z.machine false ++ [true] ++
      List.replicate z.input.length false ++ [true] ++
      z.input ++ List.replicate z.fuel true =
      List.replicate z.machine false ++
      true :: (List.replicate z.input.length false ++
               true :: (z.input ++ List.replicate z.fuel true)) := by
    simp [List.append_assoc]
  rw [h1, splitLeadingFalse_replicate]
  dsimp only
  rw [splitLeadingFalse_replicate]
  dsimp only
  have hle : z.input.length ≤ (z.input ++ List.replicate z.fuel true).length := by
    simp
  simp only [hle, ↓reduceIte]
  have htake : (z.input ++ List.replicate z.fuel true).take z.input.length = z.input := by
    rw [List.take_left]
  have hdrop : (z.input ++ List.replicate z.fuel true).drop z.input.length =
      List.replicate z.fuel true := by
    rw [List.drop_left]
  rw [htake, hdrop, allTrue_replicate]
  simp

theorem decode_sound (x : Word) (z : NInstance) (h : decode x = some z) :
    encode z = x := by
  unfold decode at h
  cases h1 : splitLeadingFalse x with
  | mk i tail1 =>
    rw [h1] at h
    cases tail1 with
    | nil => simp at h
    | cons b1 rest1 =>
      cases b1
      · simp at h
      · dsimp only at h
        cases h2 : splitLeadingFalse rest1 with
        | mk lenW tail2 =>
          rw [h2] at h
          cases tail2 with
          | nil => simp at h
          | cons b2 rest2 =>
            cases b2
            · simp at h
            · dsimp only at h
              split at h
              · rename_i hle
                split at h
                · rename_i hat
                  simp only [Option.some.injEq] at h
                  subst h
                  have hx := splitLeadingFalse_sound x i (true :: rest1) h1
                  have hr1 := splitLeadingFalse_sound rest1 lenW (true :: rest2) h2
                  have htail := allTrue_eq_replicate (rest2.drop lenW) hat
                  have hwlen : (rest2.take lenW).length = lenW := by
                    rw [List.length_take]; omega
                  unfold encode
                  rw [hwlen, ← htail, hx, hr1]
                  have hsplit : rest2.take lenW ++ rest2.drop lenW = rest2 :=
                    List.take_append_drop lenW rest2
                  simp [List.append_assoc, hsplit]
                · simp at h
              · simp at h

theorem decode_strict_fuel (x : Word) (z : NInstance) (h : decode x = some z) :
    z.fuel < x.length := by
  have heq := decode_sound x z h
  rw [← heq, encode_length]
  omega

/-! ### 3. Root lemma `kernel_local` -/

def kernelEval (runN : Code → Nat → Oracle → Word → Bool) (A : Oracle) (x : Word) : Bool :=
  match decode x with
  | none => false
  | some z => runN z.machine z.fuel A z.input

theorem kernel_local
    (runN : Code → Nat → Oracle → Word → Bool)
    (n_local : ∀ i fuel A B x, (∀ q : Word, q.length ≤ fuel → A q = B q) →
      runN i fuel A x = runN i fuel B x)
    (r : Nat) (A B : Oracle)
    (hagree : ∀ q : Word, q.length < r → A q = B q)
    (x : Word) (hx : x.length = r) :
    kernelEval runN A x = kernelEval runN B x := by
  unfold kernelEval
  cases hdec : decode x with
  | none => rfl
  | some z =>
    have hlt : z.fuel < r := by
      rw [← hx]; exact decode_strict_fuel x z hdec
    exact n_local z.machine z.fuel A B z.input (fun q hq => hagree q (Nat.lt_of_le_of_lt hq hlt))

end MultilinearW10
