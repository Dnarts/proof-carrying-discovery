/-
  ProfileTopology.lean — v0.1 (0 external imports, Lean 4.36.0 target)
  Profile Order, Minimal Multidegree (c_min = 1), Persistent Target Ambiguity,
  Nowhere-Continuity in the Finite-Observation Topology, and Tail Witness Gap.

  Proves constructively (without Classical.choice):
  1. `profile_order_from_monotonicity` / `profile_01_impossible` /
     `exactly_three_valid_profiles` (Gate 10: v ≤ u).
  2. `degree_zero_tally` / `degree_zero_no_intermediate_profile`
     (Gate 47: c = 0 forces tally oracles with P^{Ã} = P^A, hence u ↔ v).
  3. `splice_agrees_up_to` / `splice_agrees_above` /
     `persistent_target_ambiguity` / `nowhere_continuous_profile`
     (Gates 12–13: all 3 profiles dense in every finite-observation cylinder).
  4. `tail_finite_prefix_ambiguous` / `tail_no_universal_pair`
     (Gates 19–20 discrete core: finite-to-global witness gap).
-/

namespace MultilinearW10.ProfileTopology

abbrev Word := List Bool
abbrev Oracle := Word → Bool
abbrev F3 := Fin 3
abbrev F3Word := List F3

def boolToF3 (b : Bool) : F3 :=
  if b then 1 else 0

theorem boolToF3_inj (a b : Bool) (h : boolToF3 a = boolToF3 b) : a = b := by
  cases a <;> cases b
  · rfl
  · exfalso; exact absurd h (by decide)
  · exfalso; exact absurd h (by decide)
  · rfl

/-! ### 1. Profile Order `v ≤ u` and Exactly Three Valid Profiles (Gate 10) -/

structure Profile where
  u : Bool
  v : Bool
  deriving DecidableEq

def ValidProfile (p : Profile) : Prop :=
  p.v = true → p.u = true

theorem profile_order_from_monotonicity {α : Type}
    (PA PAtilde NPA NPAtilde : α → Prop)
    (hP : ∀ L, PA L → PAtilde L)
    (hNP : ∀ L, NPA L → NPAtilde L)
    (hv : ∀ L, NPAtilde L → PA L) :
    ∀ L, NPA L → PAtilde L :=
  fun L hL => hP L (hv L (hNP L hL))

theorem profile_01_impossible : ¬ ValidProfile ⟨false, true⟩ := by
  intro h
  have hft : false = true := h rfl
  cases hft

theorem exactly_three_valid_profiles (p : Profile) :
    ValidProfile p ↔
      p = ⟨false, false⟩ ∨ p = ⟨true, false⟩ ∨ p = ⟨true, true⟩ := by
  cases p with
  | mk u v =>
    cases u <;> cases v
    · constructor
      · intro _; exact Or.inl rfl
      · intro _ h; cases h
    · constructor
      · intro h; exfalso; exact profile_01_impossible h
      · rintro (h | h | h) <;> cases h
    · constructor
      · intro _; exact Or.inr (Or.inl rfl)
      · intro _ h; cases h
    · constructor
      · intro _; exact Or.inr (Or.inr rfl)
      · intro _ _; rfl

/-! ### 2. Minimal Multidegree `c_min(W_10) = 1` (Gate 47, Tally-Oracle Fix) -/

def AgreesBoolean (A : Oracle) (Atilde : F3Word → F3) : Prop :=
  ∀ w : Word, Atilde (w.map boolToF3) = boolToF3 (A w)

def IsDegreeZero (A : Oracle) (Atilde : F3Word → F3) : Prop :=
  ∀ (m : Nat) (z : F3Word), z.length = m →
    Atilde z = boolToF3 (A (List.replicate m false))

theorem degree_zero_tally (A : Oracle) (Atilde : F3Word → F3)
    (hagree : AgreesBoolean A Atilde)
    (hdeg0 : IsDegreeZero A Atilde) :
    ∀ w : Word, A w = A (List.replicate w.length false) := by
  intro w
  have h1 : Atilde (w.map boolToF3) = boolToF3 (A w) := hagree w
  have hlen : (w.map boolToF3).length = w.length := by simp only [List.length_map]
  have h2 : Atilde (w.map boolToF3) = boolToF3 (A (List.replicate w.length false)) :=
    hdeg0 w.length (w.map boolToF3) hlen
  exact boolToF3_inj _ _ (h1.symm.trans h2)

theorem degree_zero_no_intermediate_profile {α : Type}
    (PA PAtilde NPA NPAtilde : α → Prop)
    (hP_eq : ∀ L, PA L ↔ PAtilde L)
    (hNP_eq : ∀ L, NPA L ↔ NPAtilde L) :
    ((∀ L, NPA L → PAtilde L) ↔ (∀ L, NPAtilde L → PA L)) ∧
    ¬ ((∀ L, NPA L → PAtilde L) ∧ ¬ (∀ L, NPAtilde L → PA L)) := by
  have hiff : (∀ L, NPA L → PAtilde L) ↔ (∀ L, NPAtilde L → PA L) := by
    constructor
    · intro hu L hL
      exact (hP_eq L).mpr (hu L ((hNP_eq L).mpr hL))
    · intro hv L hL
      exact (hP_eq L).mp (hv L ((hNP_eq L).mp hL))
  refine ⟨hiff, ?_⟩
  rintro ⟨hu, hnv⟩
  exact hnv (hiff.mp hu)

/-! ### 3. Finite-Observation Topology and Persistent Target Ambiguity (Gates 12–13) -/

def AgreesUpTo (M : Nat) (A B : Oracle) : Prop :=
  ∀ w : Word, w.length ≤ M → A w = B w

def AgreesAbove (M : Nat) (A B : Oracle) : Prop :=
  ∀ w : Word, M < w.length → A w = B w

def splice (M : Nat) (A0 A1 : Oracle) : Oracle :=
  fun w => if w.length ≤ M then A0 w else A1 w

theorem splice_agrees_up_to (M : Nat) (A0 A1 : Oracle) :
    AgreesUpTo M (splice M A0 A1) A0 := by
  intro w hw
  unfold splice
  simp only [hw, ↓reduceIte]

theorem splice_agrees_above (M : Nat) (A0 A1 : Oracle) :
    AgreesAbove M (splice M A0 A1) A1 := by
  intro w hw
  unfold splice
  have hnot : ¬ (w.length ≤ M) := by omega
  simp only [hnot, ↓reduceIte]

structure TailInvariantProfile where
  eval : Oracle → Profile
  valid : ∀ A, ValidProfile (eval A)
  tail_inv : ∀ M A B, AgreesAbove M A B → eval A = eval B
  W00 : Oracle
  W10 : Oracle
  W11 : Oracle
  hW00 : eval W00 = ⟨false, false⟩
  hW10 : eval W10 = ⟨true, false⟩
  hW11 : eval W11 = ⟨true, true⟩

theorem persistent_target_ambiguity (P : TailInvariantProfile)
    (M : Nat) (A0 : Oracle) (p : Profile) (hp : ValidProfile p) :
    ∃ A' : Oracle, AgreesUpTo M A' A0 ∧ P.eval A' = p := by
  rcases (exactly_three_valid_profiles p).mp hp with rfl | rfl | rfl
  · refine ⟨splice M A0 P.W00, splice_agrees_up_to M A0 P.W00, ?_⟩
    rw [P.tail_inv M _ P.W00 (splice_agrees_above M A0 P.W00), P.hW00]
  · refine ⟨splice M A0 P.W10, splice_agrees_up_to M A0 P.W10, ?_⟩
    rw [P.tail_inv M _ P.W10 (splice_agrees_above M A0 P.W10), P.hW10]
  · refine ⟨splice M A0 P.W11, splice_agrees_up_to M A0 P.W11, ?_⟩
    rw [P.tail_inv M _ P.W11 (splice_agrees_above M A0 P.W11), P.hW11]

theorem nowhere_continuous_profile (P : TailInvariantProfile)
    (A0 : Oracle) (M : Nat) :
    ∃ A' : Oracle, AgreesUpTo M A' A0 ∧ P.eval A' ≠ P.eval A0 := by
  cases hA0 : P.eval A0 with
  | mk u v =>
    cases u
    · -- A0 has u = false, pick W11 with u = true
      refine ⟨splice M A0 P.W11, splice_agrees_up_to M A0 P.W11, ?_⟩
      rw [P.tail_inv M _ P.W11 (splice_agrees_above M A0 P.W11), P.hW11]
      intro heq
      cases heq
    · -- A0 has u = true, pick W00 with u = false
      refine ⟨splice M A0 P.W00, splice_agrees_up_to M A0 P.W00, ?_⟩
      rw [P.tail_inv M _ P.W00 (splice_agrees_above M A0 P.W00), P.hW00]
      intro heq
      cases heq

/-! ### 4. Discrete Finite-to-Global Witness Gap on Tail Sequences (Gates 19–20) -/

def EventuallyConst (x : Nat → Bool) (b : Bool) : Prop :=
  ∃ N : Nat, ∀ i : Nat, N ≤ i → x i = b

def listMax : List Nat → Nat
  | [] => 0
  | a :: as => max a (listMax as)

theorem le_listMax (xs : List Nat) (a : Nat) (h : a ∈ xs) : a ≤ listMax xs := by
  induction xs with
  | nil => cases h
  | cons b bs ih =>
    simp only [listMax]
    cases h with
    | head => exact Nat.le_max_left a (listMax bs)
    | tail _ h' => exact Nat.le_trans (ih h') (Nat.le_max_right b (listMax bs))

theorem tail_finite_prefix_ambiguous (Q : List Nat) (x0 : Nat → Bool) :
    ∃ xT xF : Nat → Bool,
      EventuallyConst xT true ∧
      EventuallyConst xF false ∧
      (∀ q ∈ Q, xT q = x0 q) ∧
      (∀ q ∈ Q, xF q = x0 q) := by
  let M := listMax Q
  refine ⟨fun i => if i ≤ M then x0 i else true,
          fun i => if i ≤ M then x0 i else false,
          ?_, ?_, ?_, ?_⟩
  · refine ⟨M + 1, ?_⟩
    intro i hi
    have hnot : ¬ (i ≤ M) := by omega
    simp only [hnot, ↓reduceIte]
  · refine ⟨M + 1, ?_⟩
    intro i hi
    have hnot : ¬ (i ≤ M) := by omega
    simp only [hnot, ↓reduceIte]
  · intro q hq
    have hle : q ≤ M := le_listMax Q q hq
    simp only [hle, ↓reduceIte]
  · intro q hq
    have hle : q ≤ M := le_listMax Q q hq
    simp only [hle, ↓reduceIte]

theorem tail_no_universal_pair (xT xF : Nat → Bool)
    (hT : EventuallyConst xT true)
    (hF : EventuallyConst xF false) :
    ∃ i : Nat, xT i = true ∧ xF i = false ∧ xT i ≠ xF i := by
  rcases hT with ⟨NT, hNT⟩
  rcases hF with ⟨NF, hNF⟩
  let i := max NT NF
  have h1 : xT i = true := hNT i (Nat.le_max_left NT NF)
  have h2 : xF i = false := hNF i (Nat.le_max_right NT NF)
  refine ⟨i, h1, h2, ?_⟩
  rw [h1, h2]
  decide

end MultilinearW10.ProfileTopology
