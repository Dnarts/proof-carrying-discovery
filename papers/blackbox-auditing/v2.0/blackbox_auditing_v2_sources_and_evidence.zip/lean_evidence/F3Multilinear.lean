/-
  F3Multilinear.lean — v0.4 (0 external imports, Lean 4.36.0 target)
  Level 0 (Unconditional Combinatorial-Algebraic Kernel) for MULTILINEAR_W10 (c = 1).

  Proves constructively (without Classical.choice):
  1. `boolean_agreement`: multilinear extension over F3 agrees with A on {0,1}^n.
  2. `multilinear_unique`: uniqueness of multilinear extension over F3^n.
  3. `hidden_row_decode_sum` / `hidden_row_decode_unique`: single-query F3 sum
     recovery at (x, 2, ..., 2) and exact witness detection for rows with ≤ 1 true entry.
-/

namespace MultilinearW10

abbrev Word := List Bool
abbrev Oracle := Word → Bool
abbrev F3 := Fin 3
abbrev F3Word := List F3

def boolToF3 (b : Bool) : F3 :=
  if b then 1 else 0

def f3Factor (b : Bool) (z : F3) : F3 :=
  if b then z else (1 : F3) - z

def powF3 (a : F3) : Nat → F3
  | 0 => 1
  | n + 1 => a * powF3 a n

def sumF3 : List F3 → F3
  | [] => 0
  | a :: as => a + sumF3 as

def allWords : Nat → List Word
  | 0 => [[]]
  | n + 1 => (allWords n).map (false :: ·) ++ (allWords n).map (true :: ·)

def delta : Word → F3Word → F3
  | [], [] => 1
  | b :: bs, z :: zs => f3Factor b z * delta bs zs
  | _, _ => 0

def mlEval (A : Oracle) (z : F3Word) : F3 :=
  sumF3 ((allWords z.length).map fun b => boolToF3 (A b) * delta b z)

/-! ### 1. Elementary F3 arithmetic (kernel-decidable over Fin 3) -/

theorem f3_add_comm (a b : F3) : a + b = b + a := by revert a b; decide
theorem f3_add_assoc (a b c : F3) : (a + b) + c = a + (b + c) := by revert a b c; decide
theorem f3_add_zero (a : F3) : a + 0 = a := by revert a; decide
theorem f3_zero_add (a : F3) : 0 + a = a := by revert a; decide
theorem f3_mul_comm (a b : F3) : a * b = b * a := by revert a b; decide
theorem f3_mul_assoc (a b c : F3) : (a * b) * c = a * (b * c) := by revert a b c; decide
theorem f3_mul_one (a : F3) : a * 1 = a := by revert a; decide
theorem f3_one_mul (a : F3) : 1 * a = a := by revert a; decide
theorem f3_mul_zero (a : F3) : a * 0 = 0 := by revert a; decide
theorem f3_zero_mul (a : F3) : 0 * a = 0 := by revert a; decide
theorem f3_left_distrib (a b c : F3) : a * (b + c) = a * b + a * c := by revert a b c; decide
theorem f3_right_distrib (a b c : F3) : (a + b) * c = a * c + b * c := by revert a b c; decide
theorem f3_two_mul_two : (2 : F3) * 2 = 1 := by decide
theorem f3_one_sub_two : (1 : F3) - 2 = 2 := by decide

theorem f3Factor_two (b : Bool) : f3Factor b 2 = 2 := by
  cases b <;> decide

theorem f3Factor_bool (b c : Bool) :
    f3Factor b (boolToF3 c) = if b == c then 1 else 0 := by
  cases b <;> cases c <;> decide

theorem f3Factor_affine (b : Bool) (z : F3) :
    f3Factor b z = ((1 : F3) - z) * f3Factor b 0 + z * f3Factor b 1 := by
  cases b <;> revert z <;> decide

theorem powF3_two_sq (k : Nat) : powF3 2 k * powF3 2 k = 1 := by
  induction k with
  | zero => decide
  | succ k ih =>
    simp only [powF3]
    calc
      (2 * powF3 2 k) * (2 * powF3 2 k)
          = (2 * 2) * (powF3 2 k * powF3 2 k) := by
              rw [f3_mul_assoc, ← f3_mul_assoc (powF3 2 k) 2, f3_mul_comm (powF3 2 k) 2,
                  f3_mul_assoc, ← f3_mul_assoc]
      _ = 1 * 1 := by rw [f3_two_mul_two, ih]
      _ = 1 := by decide

theorem powF3_two_ne_zero (k : Nat) : powF3 2 k ≠ 0 := by
  intro h
  have h1 := powF3_two_sq k
  rw [h, f3_zero_mul] at h1
  exact absurd h1 (by decide)

/-! ### 2. Properties of `sumF3` and `allWords` -/

theorem sumF3_append (xs ys : List F3) : sumF3 (xs ++ ys) = sumF3 xs + sumF3 ys := by
  induction xs with
  | nil => simp only [List.nil_append, sumF3, f3_zero_add]
  | cons a as ih => simp only [List.cons_append, sumF3, ih, f3_add_assoc]

theorem sumF3_map_add {α : Type} (xs : List α) (f g : α → F3) :
    sumF3 (xs.map fun x => f x + g x) = sumF3 (xs.map f) + sumF3 (xs.map g) := by
  induction xs with
  | nil => simp only [List.map_nil, sumF3, f3_add_zero]
  | cons a as ih =>
    simp only [List.map_cons, sumF3, ih]
    rw [f3_add_assoc, ← f3_add_assoc (g a), f3_add_comm (g a) (sumF3 (as.map f)),
        f3_add_assoc, ← f3_add_assoc]

theorem sumF3_map_mul_left {α : Type} (c : F3) (xs : List α) (f : α → F3) :
    sumF3 (xs.map fun x => c * f x) = c * sumF3 (xs.map f) := by
  induction xs with
  | nil => simp only [List.map_nil, sumF3, f3_mul_zero]
  | cons a as ih =>
    simp only [List.map_cons, sumF3, ih, f3_left_distrib]

theorem sumF3_map_zero {α : Type} (xs : List α) (f : α → F3)
    (h : ∀ x ∈ xs, f x = 0) : sumF3 (xs.map f) = 0 := by
  induction xs with
  | nil => rfl
  | cons a as ih =>
    simp only [List.map_cons, sumF3]
    rw [h a (List.Mem.head _), f3_zero_add]
    exact ih (fun x hx => h x (List.Mem.tail _ hx))

theorem sumF3_ne_zero_exists {α : Type} (xs : List α) (f : α → F3)
    (hne : sumF3 (xs.map f) ≠ 0) : ∃ x ∈ xs, f x ≠ 0 := by
  induction xs with
  | nil => exact absurd rfl hne
  | cons a as ih =>
    simp only [List.map_cons, sumF3] at hne
    if ha : f a = 0 then
      rw [ha, f3_zero_add] at hne
      rcases ih hne with ⟨x, hx, hfx⟩
      exact ⟨x, List.Mem.tail _ hx, hfx⟩
    else
      exact ⟨a, List.Mem.head _, ha⟩

theorem sumF3_eq_single {α : Type} [DecidableEq α] (xs : List α) (f : α → F3) (y : α)
    (hnd : xs.Nodup) (hmem : y ∈ xs) (hzero : ∀ x ∈ xs, x ≠ y → f x = 0) :
    sumF3 (xs.map f) = f y := by
  induction xs with
  | nil => cases hmem
  | cons a as ih =>
    have hnd' := List.nodup_cons.mp hnd
    simp only [List.map_cons, sumF3]
    if hay : a = y then
      subst hay
      have hrest : sumF3 (as.map f) = 0 :=
        sumF3_map_zero as f (fun x hx => hzero x (List.Mem.tail _ hx) (fun heq => hnd'.1 (heq ▸ hx)))
      rw [hrest, f3_add_zero]
    else
      have hy_as : y ∈ as := by
        cases hmem with
        | head => exact absurd rfl hay
        | tail _ h => exact h
      rw [hzero a (List.Mem.head _) hay, f3_zero_add]
      exact ih hnd'.2 hy_as (fun x hx hne => hzero x (List.Mem.tail _ hx) hne)

theorem nodup_map_of_inj {α β : Type} (f : α → β) (hf : ∀ a b, f a = f b → a = b)
    (xs : List α) (hnd : xs.Nodup) : (xs.map f).Nodup := by
  induction xs with
  | nil => simp
  | cons a as ih =>
    have hnd' := List.nodup_cons.mp hnd
    refine List.nodup_cons.mpr ⟨?_, ih hnd'.2⟩
    intro hmem
    rcases List.mem_map.mp hmem with ⟨x, hx, hfx⟩
    exact hnd'.1 (hf x a hfx ▸ hx)

theorem allWords_length (n : Nat) : (allWords n).length = 2 ^ n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [allWords, List.length_append, List.length_map, ih, Nat.pow_succ]
    omega

theorem mem_allWords (n : Nat) (w : Word) : w ∈ allWords n ↔ w.length = n := by
  induction n generalizing w with
  | zero =>
    simp only [allWords, List.mem_singleton, List.length_eq_zero_iff]
  | succ n ih =>
    simp only [allWords, List.mem_append, List.mem_map]
    constructor
    · rintro (⟨u, hu, rfl⟩ | ⟨u, hu, rfl⟩) <;> simp [(ih u).mp hu]
    · intro hlen
      cases w with
      | nil => simp only [List.length_nil] at hlen; omega
      | cons b u =>
        have hu : u ∈ allWords n := (ih u).mpr (by simpa using hlen)
        cases b
        · exact Or.inl ⟨u, hu, rfl⟩
        · exact Or.inr ⟨u, hu, rfl⟩

theorem allWords_nodup (n : Nat) : (allWords n).Nodup := by
  induction n with
  | zero => simp [allWords]
  | succ n ih =>
    simp only [allWords]
    refine List.nodup_append.mpr ⟨?_, ?_, ?_⟩
    · exact nodup_map_of_inj (false :: ·) (fun _ _ h => (List.cons.inj h).2) (allWords n) ih
    · exact nodup_map_of_inj (true :: ·) (fun _ _ h => (List.cons.inj h).2) (allWords n) ih
    · intro x hx y hy hxy
      simp only [List.mem_map] at hx hy
      rcases hx with ⟨u, _, rfl⟩
      rcases hy with ⟨v, _, rfl⟩
      cases hxy

/-! ### 3. Delta basis identities and `boolean_agreement` -/

theorem delta_bool (b w : Word) (hlen : b.length = w.length) :
    delta b (w.map boolToF3) = if b = w then 1 else 0 := by
  induction b generalizing w with
  | nil =>
    cases w with
    | nil => rfl
    | cons _ _ => simp only [List.length_nil, List.length_cons] at hlen; omega
  | cons b bs ih =>
    cases w with
    | nil => simp only [List.length_nil, List.length_cons] at hlen; omega
    | cons c cs =>
      simp only [List.map_cons, delta, f3Factor_bool]
      have hlen' : bs.length = cs.length := by simpa using hlen
      rw [ih cs hlen']
      if hbc : b = c then
        subst hbc
        simp only [beq_self_eq_true, ↓reduceIte, f3_one_mul]
        if hbs : bs = cs then
          subst hbs; simp
        else
          simp [hbs]
      else
        have hbeq : (b == c) = false := beq_false_of_ne hbc
        simp [hbeq, hbc, f3_zero_mul]

theorem boolean_agreement (A : Oracle) (w : Word) :
    mlEval A (w.map boolToF3) = boolToF3 (A w) := by
  unfold mlEval
  have hlen : (w.map boolToF3).length = w.length := by simp
  rw [hlen]
  have hmem : w ∈ allWords w.length := (mem_allWords w.length w).mpr rfl
  have hsingle := sumF3_eq_single (allWords w.length)
    (fun b => boolToF3 (A b) * delta b (w.map boolToF3)) w (allWords_nodup w.length) hmem
  rw [hsingle]
  · rw [delta_bool w w rfl]
    simp only [↓reduceIte, f3_mul_one]
  · intro b hb hne
    have hblen : b.length = w.length := (mem_allWords w.length b).mp hb
    rw [delta_bool b w hblen]
    simp only [hne, ↓reduceIte, f3_mul_zero]

/-! ### 4. Multilinearity and `multilinear_unique` -/

def IsMultilinear (n : Nat) (P : F3Word → F3) : Prop :=
  ∀ (u v : F3Word) (z : F3),
    u.length + 1 + v.length = n →
    P (u ++ z :: v) = ((1 : F3) - z) * P (u ++ (0 : F3) :: v) + z * P (u ++ (1 : F3) :: v)

theorem delta_append (b1 b2 : Word) (z1 z2 : F3Word) (h : b1.length = z1.length) :
    delta (b1 ++ b2) (z1 ++ z2) = delta b1 z1 * delta b2 z2 := by
  induction b1 generalizing z1 with
  | nil =>
    cases z1 with
    | nil => simp [delta, f3_one_mul]
    | cons _ _ => simp only [List.length_nil, List.length_cons] at h; omega
  | cons b bs ih =>
    cases z1 with
    | nil => simp only [List.length_nil, List.length_cons] at h; omega
    | cons z zs =>
      simp only [List.cons_append, delta]
      rw [ih zs (by simpa using h), f3_mul_assoc]

theorem delta_affine (b : Word) (u v : F3Word) (z : F3)
    (hlen : b.length = u.length + 1 + v.length) :
    delta b (u ++ z :: v) =
      ((1 : F3) - z) * delta b (u ++ (0 : F3) :: v) +
      z * delta b (u ++ (1 : F3) :: v) := by
  have hsplit : b = b.take u.length ++ b.drop u.length := (List.take_append_drop _ _).symm
  have htake_len : (b.take u.length).length = u.length := by
    rw [List.length_take]; omega
  have hdrop_len : (b.drop u.length).length = 1 + v.length := by
    rw [List.length_drop]; omega
  cases hdrop : b.drop u.length with
  | nil =>
    rw [hdrop, List.length_nil] at hdrop_len
    omega
  | cons bit rest =>
    rw [hsplit, hdrop]
    rw [delta_append _ _ _ _ htake_len, delta_append _ _ _ _ htake_len,
        delta_append _ _ _ _ htake_len]
    simp only [delta]
    rw [f3Factor_affine bit z, f3_right_distrib, f3_left_distrib]
    congr 1
    · rw [← f3_mul_assoc, ← f3_mul_assoc, f3_mul_comm (delta (b.take u.length) u) ((1 : F3) - z),
          f3_mul_assoc, f3_mul_assoc]
    · rw [← f3_mul_assoc, ← f3_mul_assoc, f3_mul_comm (delta (b.take u.length) u) z,
          f3_mul_assoc, f3_mul_assoc]

theorem mlEval_isMultilinear (A : Oracle) (n : Nat) : IsMultilinear n (mlEval A) := by
  intro u v z hlen
  unfold mlEval
  have h1 : (u ++ z :: v).length = n := by simp; omega
  have h2 : (u ++ (0 : F3) :: v).length = n := by simp; omega
  have h3 : (u ++ (1 : F3) :: v).length = n := by simp; omega
  rw [h1, h2, h3]
  have hmap :
      (allWords n).map (fun b => boolToF3 (A b) * delta b (u ++ z :: v)) =
      (allWords n).map (fun b =>
        ((1 : F3) - z) * (boolToF3 (A b) * delta b (u ++ (0 : F3) :: v)) +
        z * (boolToF3 (A b) * delta b (u ++ (1 : F3) :: v))) := by
    refine List.map_congr_left ?_
    intro b hb
    have hblen : b.length = u.length + 1 + v.length := by
      rw [(mem_allWords n b).mp hb, ← hlen]
    rw [delta_affine b u v z hblen, f3_left_distrib]
    congr 1
    · rw [← f3_mul_assoc, f3_mul_comm (boolToF3 (A b)) ((1 : F3) - z), f3_mul_assoc]
    · rw [← f3_mul_assoc, f3_mul_comm (boolToF3 (A b)) z, f3_mul_assoc]
  rw [hmap, sumF3_map_add, sumF3_map_mul_left, sumF3_map_mul_left]

theorem multilinear_eq_aux (n : Nat) (P Q : F3Word → F3)
    (hP : IsMultilinear n P) (hQ : IsMultilinear n Q)
    (hagree : ∀ w : Word, w.length = n → P (w.map boolToF3) = Q (w.map boolToF3)) :
    ∀ (k : Nat) (u : Word) (v : F3Word),
      u.length + v.length = n → v.length = k →
      P (u.map boolToF3 ++ v) = Q (u.map boolToF3 ++ v) := by
  intro k
  induction k with
  | zero =>
    intro u v hlen hv
    cases v with
    | nil =>
      simp only [List.append_nil]
      exact hagree u (by simpa using hlen)
    | cons _ _ => simp only [List.length_cons] at hv; omega
  | succ k ih =>
    intro u v hlen hv
    cases v with
    | nil => simp only [List.length_nil] at hv; omega
    | cons z vs =>
      have hlen' : (u.map boolToF3).length + 1 + vs.length = n := by
        simp only [List.length_map]; simp only [List.length_cons] at hlen; omega
      rw [hP (u.map boolToF3) vs z hlen', hQ (u.map boolToF3) vs z hlen']
      have h0 : u.map boolToF3 ++ (0 : F3) :: vs = (u ++ [false]).map boolToF3 ++ vs := by
        simp [boolToF3]
      have h1 : u.map boolToF3 ++ (1 : F3) :: vs = (u ++ [true]).map boolToF3 ++ vs := by
        simp [boolToF3]
      rw [h0, h1]
      have hvs : vs.length = k := by simpa using hv
      have hlen0 : (u ++ [false]).length + vs.length = n := by
        simp only [List.length_append, List.length_singleton]; simp only [List.length_cons] at hlen; omega
      have hlen1 : (u ++ [true]).length + vs.length = n := by
        simp only [List.length_append, List.length_singleton]; simp only [List.length_cons] at hlen; omega
      rw [ih (u ++ [false]) vs hlen0 hvs, ih (u ++ [true]) vs hlen1 hvs]

theorem multilinear_unique (n : Nat) (P Q : F3Word → F3)
    (hP : IsMultilinear n P) (hQ : IsMultilinear n Q)
    (hagree : ∀ w : Word, w.length = n → P (w.map boolToF3) = Q (w.map boolToF3))
    (z : F3Word) (hz : z.length = n) :
    P z = Q z := by
  have h := multilinear_eq_aux n P Q hP hQ hagree z.length [] z (by simpa using hz) rfl
  simpa using h

/-! ### 5. Single-query row-sum decoding at `(x, 2, ..., 2)` -/

theorem delta_replicate_two (y : Word) (k : Nat) (hy : y.length = k) :
    delta y (List.replicate k (2 : F3)) = powF3 2 k := by
  induction k generalizing y with
  | zero =>
    cases y with
    | nil => rfl
    | cons _ _ => simp only [List.length_cons] at hy; omega
  | succ k ih =>
    cases y with
    | nil => simp only [List.length_nil] at hy; omega
    | cons b bs =>
      simp only [List.replicate_succ, delta, f3Factor_two, powF3]
      rw [ih bs (by simpa using hy)]

def rowSumF3 (A : Oracle) (x : Word) (k : Nat) : F3 :=
  sumF3 ((allWords k).map fun y => boolToF3 (A (x ++ y)))

theorem sumF3_allWords_split (r k : Nat) (f : Word → F3) :
    sumF3 ((allWords (r + k)).map f) =
      sumF3 ((allWords r).map fun u => sumF3 ((allWords k).map fun v => f (u ++ v))) := by
  induction r generalizing f with
  | zero =>
    simp only [Nat.zero_add, allWords, List.map_cons, List.map_nil, List.nil_append, sumF3, f3_add_zero]
  | succ r ih =>
    have hadd : r + 1 + k = (r + k) + 1 := by omega
    rw [hadd]
    simp only [allWords, List.map_append, sumF3_append, List.map_map]
    rw [ih (f ∘ fun x => false :: x), ih (f ∘ fun x => true :: x)]
    rfl

theorem hidden_row_sum_identity (A : Oracle) (x : Word) (k : Nat) :
    mlEval A (x.map boolToF3 ++ List.replicate k (2 : F3)) =
      powF3 2 k * rowSumF3 A x k := by
  unfold mlEval rowSumF3
  have hlen : (x.map boolToF3 ++ List.replicate k (2 : F3)).length = x.length + k := by
    simp
  rw [hlen, sumF3_allWords_split x.length k]
  have hxmem : x ∈ allWords x.length := (mem_allWords x.length x).mpr rfl
  have hsingle := sumF3_eq_single (allWords x.length)
    (fun u => sumF3 ((allWords k).map fun v =>
      boolToF3 (A (u ++ v)) * delta (u ++ v) (x.map boolToF3 ++ List.replicate k (2 : F3))))
    x (allWords_nodup x.length) hxmem
  rw [hsingle]
  · have hinner :
        (allWords k).map (fun v =>
          boolToF3 (A (x ++ v)) * delta (x ++ v) (x.map boolToF3 ++ List.replicate k (2 : F3))) =
        (allWords k).map (fun v => powF3 2 k * boolToF3 (A (x ++ v))) := by
      refine List.map_congr_left ?_
      intro v hv
      have hvlen : v.length = k := (mem_allWords k v).mp hv
      rw [delta_append x v (x.map boolToF3) (List.replicate k 2) (by simp)]
      rw [delta_bool x x rfl]
      simp only [↓reduceIte, f3_one_mul]
      rw [delta_replicate_two v k hvlen, f3_mul_comm]
    rw [hinner, sumF3_map_mul_left]
  · intro u hu hne
    have hulen : u.length = x.length := (mem_allWords x.length u).mp hu
    refine sumF3_map_zero (allWords k) _ ?_
    intro v _
    rw [delta_append u v (x.map boolToF3) (List.replicate k 2) (by simp [hulen])]
    rw [delta_bool u x hulen]
    simp only [hne, ↓reduceIte, f3_zero_mul, f3_mul_zero]

theorem hidden_row_decode_sum (A : Oracle) (x : Word) (k : Nat) :
    powF3 2 k * mlEval A (x.map boolToF3 ++ List.replicate k (2 : F3)) =
      rowSumF3 A x k := by
  rw [hidden_row_sum_identity, ← f3_mul_assoc, powF3_two_sq, f3_one_mul]

theorem hidden_row_decode_unique (A : Oracle) (x : Word) (k : Nat)
    (hatmost : ∀ y1 y2, y1.length = k → y2.length = k →
      A (x ++ y1) = true → A (x ++ y2) = true → y1 = y2) :
    mlEval A (x.map boolToF3 ++ List.replicate k (2 : F3)) ≠ 0 ↔
      ∃ y, y.length = k ∧ A (x ++ y) = true := by
  rw [hidden_row_sum_identity]
  constructor
  · intro hne
    have hrow_ne : rowSumF3 A x k ≠ 0 := by
      intro hzero
      rw [hzero, f3_mul_zero] at hne
      exact hne rfl
    rcases sumF3_ne_zero_exists (allWords k) (fun y => boolToF3 (A (x ++ y))) hrow_ne with
      ⟨y, hymem, hyne⟩
    have hylen : y.length = k := (mem_allWords k y).mp hymem
    cases hAy : A (x ++ y)
    · rw [hAy] at hyne
      exact absurd rfl hyne
    · exact ⟨y, hylen, hAy⟩
  · rintro ⟨y, hylen, hAy⟩
    have hymem : y ∈ allWords k := (mem_allWords k y).mpr hylen
    have hsum : rowSumF3 A x k = 1 := by
      unfold rowSumF3
      rw [sumF3_eq_single (allWords k) (fun v => boolToF3 (A (x ++ v))) y
            (allWords_nodup k) hymem]
      · simp [hAy, boolToF3]
      · intro v hv hne
        have hvlen : v.length = k := (mem_allWords k v).mp hv
        cases hAv : A (x ++ v)
        · rfl
        · exact absurd (hatmost v y hvlen hylen hAv hAy) hne
    rw [hsum, f3_mul_one]
    exact powF3_two_ne_zero k

end MultilinearW10
