# Black-box auditing v2.0 — bilingual source and evidence bundle

The two LaTeX sources share `preamble.tex`. Run `xelatex blackbox_auditing_en.tex` twice and `xelatex blackbox_auditing_ru.tex` twice (XeLaTeX, Noto Serif, Noto Sans, DejaVu Sans Mono, standard LaTeX packages and Russian Babel required). No fonts are included.

`lean_evidence/` preserves the ten original release files under their manifest names, plus the original manifest. Their SHA-256 values were checked. These are the supplied component-build logs, not evidence of a new integrated Lean compilation. See section 5 of the revised manuscripts for the exact formal scope.

Changes: support-preserving aliasing, exact fiber factorization, nonlinear entropy strengthening, corrected asymptotic claim, explicit tail-game assumptions, complete analytical intermediate-oracle construction, clarified degree-zero scope, one-query existence versus witness retrieval, and separate proposed LLM evaluation. The two new entropy/factorization propositions are analytic, not Lean-verified. No external preregistration or empirical evaluation is claimed. Author field remains unspecified, as in the supplied blackboxauditingblindspotsru.pdf.
