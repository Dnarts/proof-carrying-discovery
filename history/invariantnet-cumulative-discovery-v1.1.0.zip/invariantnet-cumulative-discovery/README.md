# InvariantNet — Cumulative Discovery

**Certified invariant discovery, law-aware program synthesis, coalition-event replay, and bounded-state escalation under a fixed search engine.**

> Current release: **v1.1.0** (22 November 2026). The original four v1.0 files and their SHA-256 digests remain intact in [`legacy/`](legacy/). The v1.1 results are a post-audit correction, **not a preregistered experiment**.

**Read the paper first:** [Revised preprint (Russian)](PREPRINT_v1.1.ru.md) · [Corrections and evidence](FIXES.md) · [How to reproduce](#run--verify).

### What this repo demonstrates

1. Finite distinguishing suffixes certify that a trusted target cannot be recognized by **DFA with ≤5 states**; the engine then enters a **predefined** one-counter machine tier. No universal claim about unknown oracles is made.
2. A 12-cell deterministic one-counter program is synthesized from an empty transition table. Within a fixed **phase-linear template**, coefficients are derived from the selected transitions, and local inductive obligations are checked.
3. A learned slope used as **provisional** search pruning cuts a second synthesis task from 57 to 28 explored branches. A wrong slope is rejected and followed by an unrestricted certified search.
4. A separate Boolean experiment learns the NAND commutativity law, synthesizes an XOR macro, then derives XOR laws. All **eight event coalitions are replayed from the same initial library**, including acquisition work. Their fixed three-task curriculum is not a general model of open-ended discovery.
5. Shapley values are computed for an **explicitly declared work proxy** and player/coalition semantics. Normalization calls, law probes, certification probes, and candidate evaluations are individually reported. They are not wall-clock or energy measurements.

### Reproduced findings

| Scope | Observation |
|---|---|
| Tier escalation | T1: 26 search branches; T2: 57 without slope, 28 with slope |
| Bad transfer | Unsuccessful restricted search followed by certified unrestricted fallback |
| Regular negative control | Five-state DFA exactly equivalent to an explicit 5-state reference for `0+1+$` |
| Finite observations | No claim of equivalence to **arbitrary black-box teachers** |
| Boolean acquisition histories | All 8 coalitions replay e1 → e2 → e3; acquisition work paid once per coalition |
| Boolean suite, default proxy | `W(NAND_law)≈+0.546`, `W(XOR_macro)≈+1.925`, `W(XOR_laws)≈+0.442` nats |
| AND3, default proxy | `W(XOR_macro)≈−0.868` nats (utility problem) |

The default proxy charges each candidate evaluation, normalizer call, tested law identity, complete independent law-certificate comparison, and successful gate replay as **one modeled unit**. Weight sensitivity appears in the JSON. When no solution exists inside the fixed gate-depth class, the task is right-censored at 200,000 work units; this does not establish its actual time-to-solution.

### Run & verify

Python ≥3.10, standard library only. Run from the repository root:

```bash
python3 tests/audit_release.py
```

For individual fresh computations (stdout JSON):

```bash
python3 v1_1/dfa_to_1dca_v1_1.py > /tmp/dfa_v1_1_new.json
python3 v1_1/abc_historical_v1_1.py > /tmp/abc_v1_1_new.json
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

Fresh run files include timing/OS metadata and therefore need not have the same SHA-256 as the shipped result JSON. `tests/audit_release.py` compares **deterministic fields**, checks certificates, recomputes all tests and verifies immutable v1.0 source hashes.

### Repository layout

```text
legacy/                  Original v1.0 scripts, JSON and auditor review
v1_1/                   Revised Python experiments and their result JSON
  abc_historical_v1_1.py
  dfa_to_1dca_v1_1.py
  build_dfa_v1_1.py     Documented, repeatable transformation from legacy DCA
 tests/                  Independent reference/negative tests and release verifier
PREPRINT_v1.1.ru.md     Revised scientific text with scoped claims
FIXES.md                Traceability of every audit finding
MANIFEST.json           File identities, provenance, executable status
```

### What this is not

No claim of consciousness, human insight, universal invariant induction, arbitrary representation-independent bit count, full DOCA equivalence solver, or execution inside Rule 110. The phase-language and the two machine tiers are specified in advance. The acquisition-event replay is for a fixed three-event curriculum and does not infer the curriculum itself.

### Linked research

The connected Rule 110 work is a separate mathematical line: [rule110-dependency-fronts](https://github.com/Dnarts/rule110-dependency-fronts). Do not conflate bounded search engines in this repo with the cellular automaton's fixed local rule.

### Русский

**Исследование накопительного поиска:** программа выбирает переходы счётчикового автомата, получает фазовое равенство в заданном языке и проверяет его предпосылки; булев стенд отдельно различает макрос, закон переписывания и их измеренную полезность. [Полная статья](PREPRINT_v1.1.ru.md) · [Все исправления](FIXES.md).

**Publication:** draft/preprint only; no public DOI is claimed. Repository licensing remains to be chosen by the author.
